#!/usr/bin/env python3
"""يعدّل ملفات Android التي ينشئها `flutter create` ليعمل التطبيق:
- الأذونات (إنترنت، إشعارات)
- مستقبلات الإشعارات المجدولة
- desugaring (مطلوب لحزمة الإشعارات)
- minSdk = 24
"""
import pathlib
import re
import sys

ROOT = pathlib.Path("android")
APP = ROOT / "app"
MANIFEST = APP / "src" / "main" / "AndroidManifest.xml"

DESUGAR_VERSION = "2.1.4"
MIN_SDK = 24


def patch_gradle():
    kts = APP / "build.gradle.kts"
    groovy = APP / "build.gradle"
    if kts.exists():
        path, is_kts = kts, True
    elif groovy.exists():
        path, is_kts = groovy, False
    else:
        sys.exit("لم يتم العثور على android/app/build.gradle(.kts)")

    text = path.read_text(encoding="utf-8")

    if is_kts:
        if "isCoreLibraryDesugaringEnabled" not in text:
            text, n = re.subn(
                r"(compileOptions\s*\{)",
                r"\1\n        isCoreLibraryDesugaringEnabled = true",
                text,
                count=1,
            )
            if n == 0:
                sys.exit("لم يتم العثور على compileOptions في build.gradle.kts")
        text = re.sub(
            r"minSdk\s*=\s*flutter\.minSdkVersion", f"minSdk = {MIN_SDK}", text
        )
        dep = f'    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:{DESUGAR_VERSION}")'
    else:
        if "coreLibraryDesugaringEnabled" not in text:
            text, n = re.subn(
                r"(compileOptions\s*\{)",
                r"\1\n        coreLibraryDesugaringEnabled true",
                text,
                count=1,
            )
            if n == 0:
                sys.exit("لم يتم العثور على compileOptions في build.gradle")
        text = re.sub(
            r"minSdkVersion\s+flutter\.minSdkVersion", f"minSdkVersion {MIN_SDK}", text
        )
        dep = f"    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:{DESUGAR_VERSION}'"

    if "desugar_jdk_libs" not in text:
        if re.search(r"^dependencies\s*\{", text, flags=re.M):
            text = re.sub(
                r"^(dependencies\s*\{)", r"\1\n" + dep, text, count=1, flags=re.M
            )
        else:
            text += "\n\ndependencies {\n" + dep + "\n}\n"

    path.write_text(text, encoding="utf-8")
    print(f"patched {path}")


PERMISSIONS = """
    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>
    <uses-permission android:name="android.permission.VIBRATE"/>
"""

RECEIVERS = """
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" />
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED"/>
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>
                <action android:name="android.intent.action.QUICKBOOT_POWERON" />
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>
            </intent-filter>
        </receiver>
"""


TTS_QUERY = (
    '<intent><action android:name="android.intent.action.TTS_SERVICE"/></intent>'
)


def patch_manifest():
    if not MANIFEST.exists():
        sys.exit("لم يتم العثور على AndroidManifest.xml")
    text = MANIFEST.read_text(encoding="utf-8")

    if "POST_NOTIFICATIONS" not in text:
        text, n = re.subn(r"(<manifest[^>]*>)", r"\1" + PERMISSIONS, text, count=1)
        if n == 0:
            sys.exit("تعذّر العثور على وسم manifest")

    if "ScheduledNotificationReceiver" not in text:
        text = text.replace("</application>", RECEIVERS + "    </application>", 1)

    if "TTS_SERVICE" not in text:
        if "<queries>" in text:
            text = text.replace("<queries>", "<queries>\n    " + TTS_QUERY, 1)
        else:
            text = text.replace(
                "<application", "<queries>\n    " + TTS_QUERY + "\n    </queries>\n    <application", 1
            )

    text = re.sub(r'android:label="[^"]*"', 'android:label="Wordia"', text, count=1)
    MANIFEST.write_text(text, encoding="utf-8")
    print(f"patched {MANIFEST}")


if __name__ == "__main__":
    patch_gradle()
    patch_manifest()
