import 'dart:async';

import 'package:flutter/material.dart';

import '../store.dart';
import '../theme.dart';
import 'home_shell.dart';

Route<void> _fade(Widget page) => PageRouteBuilder<void>(
      transitionDuration: const Duration(milliseconds: 450),
      pageBuilder: (_, __, ___) => page,
      transitionsBuilder: (_, a, __, child) =>
          FadeTransition(opacity: a, child: child),
    );

/// شاشة الافتتاح المتحركة، ثم الجولة التعريفية (أول تشغيل فقط)، ثم التطبيق.
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1300))
    ..forward();
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _t = Timer(const Duration(milliseconds: 2300), _go);
  }

  void _go() {
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
        _fade(app.s.seenWelcome ? const HomeShell() : const WelcomeScreen()));
  }

  @override
  void dispose() {
    _t?.cancel();
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final dark = isDark(context);
    final logoScale = CurvedAnimation(parent: _c, curve: Curves.elasticOut);
    final textFade = CurvedAnimation(
        parent: _c, curve: const Interval(0.5, 1, curve: Curves.easeOut));
    return Scaffold(
      backgroundColor: dark ? C.darkBg : C.mint,
      body: Stack(children: [
        Positioned(
            left: -90,
            bottom: -70,
            child: _blob(300, C.pink.withValues(alpha: dark ? 0.35 : 1))),
        Positioned(
            right: -80,
            top: -60,
            child: _blob(260, C.blue.withValues(alpha: dark ? 0.35 : 1))),
        Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            ScaleTransition(
              scale: logoScale,
              child: Image.asset('assets/icon/logo.png', width: 170, height: 170),
            ),
            const SizedBox(height: 18),
            FadeTransition(
              opacity: textFade,
              child: SlideTransition(
                position: Tween(begin: const Offset(0, 0.25), end: Offset.zero)
                    .animate(textFade),
                child: Column(children: [
                  Text('Wordia',
                      style: heading(56, color: dark ? Colors.white : C.ink)),
                  const SizedBox(height: 4),
                  Text('تعلّم المفردات بمتعة',
                      style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w800,
                          color: dark ? Colors.white70 : C.ink)),
                ]),
              ),
            ),
          ]),
        ),
      ]),
    );
  }

  Widget _blob(double s, Color c) => Container(
      width: s, height: s, decoration: BoxDecoration(color: c, shape: BoxShape.circle));
}

/// جولة تعريفية من 3 صفحات تظهر مرة واحدة.
class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key});

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  final _pc = PageController();
  int _i = 0;

  static const _pages = [
    ('📚', 'أهلاً بك في Wordia', 'أضف كلماتك بلغات متعددة، واحصل على الترجمة والأمثلة تلقائياً مع نطق واضح.', C.yellow),
    ('🧠', 'راجع والعب', 'مراجعة متباعدة ذكية وخمس ألعاب وقصص بكلماتك، مع إحصائيات وسلسلة أيام.', C.pink),
    ('📺', 'تعلّم من يوتيوب', 'الصق رابط أي فيديو فيه ترجمة، فتحصل على ملخص وكلمات مفيدة تضيفها بنقرة.', C.blue),
  ];

  Future<void> _finish() async {
    app.s.seenWelcome = true;
    app.saveSettings();
    if (!mounted) return;
    Navigator.of(context).pushReplacement(_fade(const HomeShell()));
  }

  @override
  void dispose() {
    _pc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final dark = isDark(context);
    final last = _i == _pages.length - 1;
    return Scaffold(
      backgroundColor: dark ? C.darkBg : _pages[_i].$4,
      body: SafeArea(
        child: Column(children: [
          Align(
            alignment: AlignmentDirectional.centerEnd,
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: TextButton(
                  onPressed: _finish,
                  child: Text(last ? '' : 'تخطّي',
                      style: TextStyle(
                          fontWeight: FontWeight.w900,
                          color: dark ? Colors.white : C.ink))),
            ),
          ),
          Expanded(
            child: PageView.builder(
              controller: _pc,
              itemCount: _pages.length,
              onPageChanged: (v) => setState(() => _i = v),
              itemBuilder: (_, k) {
                final p = _pages[k];
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Center(
                    child: NeoCard(
                      color: dark ? null : Colors.white,
                      padding: const EdgeInsets.fromLTRB(24, 32, 24, 32),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Text(p.$1, style: const TextStyle(fontSize: 84)),
                        const SizedBox(height: 18),
                        Text(p.$2,
                            textAlign: TextAlign.center,
                            style: heading(30, color: dark ? Colors.white : C.ink)),
                        const SizedBox(height: 12),
                        Text(p.$3,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontSize: 17,
                                height: 1.6,
                                fontWeight: FontWeight.w600,
                                color: dark ? Colors.white70 : Colors.black87)),
                      ]),
                    ),
                  ),
                );
              },
            ),
          ),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            for (var k = 0; k < _pages.length; k++)
              AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                margin: const EdgeInsets.symmetric(horizontal: 4),
                width: k == _i ? 26 : 10,
                height: 10,
                decoration: BoxDecoration(
                  color: k == _i ? C.coral : (dark ? Colors.white24 : Colors.white),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: dark ? Colors.white54 : C.ink, width: 2),
                ),
              ),
          ]),
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 20, 24, 24),
            child: NeoButton(
              label: last ? 'ابدأ الآن' : 'التالي',
              icon: last ? Icons.rocket_launch : Icons.arrow_back,
              color: C.coral,
              onPressed: last
                  ? _finish
                  : () => _pc.nextPage(
                      duration: const Duration(milliseconds: 300),
                      curve: Curves.easeOut),
            ),
          ),
        ]),
      ),
    );
  }
}
