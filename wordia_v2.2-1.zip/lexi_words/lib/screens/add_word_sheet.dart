import 'dart:async';

import 'package:flutter/material.dart';

import '../models.dart';
import '../services/ai_service.dart';
import '../services/ocr_service.dart';
import '../store.dart';
import '../theme.dart';

Future<void> showAddWordSheet(BuildContext context, {Word? edit}) {
  return showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    backgroundColor: isDark(context) ? C.darkBg : C.cream,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      side: BorderSide(color: C.ink, width: 2),
    ),
    builder: (c) => _AddWordSheet(edit: edit),
  );
}

class _AddWordSheet extends StatefulWidget {
  final Word? edit;
  const _AddWordSheet({this.edit});

  @override
  State<_AddWordSheet> createState() => _AddWordSheetState();
}

class _AddWordSheetState extends State<_AddWordSheet>
    with SingleTickerProviderStateMixin {
  late final TextEditingController _word;
  late final TextEditingController _trans;
  late final TextEditingController _note;
  final _bulk = TextEditingController();
  late final TabController _tabs;
  late String _lang;
  bool _daily = false;
  String? _msg;
  Timer? _msgTimer;

  bool _filling = false; // تعبئة تلقائية جارية
  bool _bulkBusy = false;
  bool _autoTranslate = true;
  Example? _pendingExample;

  bool get editing => widget.edit != null;

  @override
  void initState() {
    super.initState();
    final e = widget.edit;
    _word = TextEditingController(text: e?.word ?? '');
    _trans = TextEditingController(text: e?.translation ?? '');
    _note = TextEditingController(text: e?.note ?? '');
    _lang = e?.lang ?? app.s.defaultLang;
    _daily = e?.daily ?? false;
    _tabs = TabController(length: editing ? 1 : 2, vsync: this);
  }

  void _say(String m) {
    if (!mounted) return;
    setState(() => _msg = m);
    _msgTimer?.cancel();
    _msgTimer = Timer(const Duration(seconds: 3), () {
      if (mounted) setState(() => _msg = null);
    });
  }

  @override
  void dispose() {
    _msgTimer?.cancel();
    _word.dispose();
    _trans.dispose();
    _note.dispose();
    _bulk.dispose();
    _tabs.dispose();
    super.dispose();
  }

  // ---------- تعبئة تلقائية ----------
  Future<void> _autoFill() async {
    final w = _word.text.trim();
    if (w.isEmpty) {
      _say('اكتب الكلمة أولاً');
      return;
    }
    if (_filling) return;
    setState(() => _filling = true);
    try {
      final r = await ai.autoFill(w, _lang, app.s);
      if (!mounted) return;
      setState(() {
        if (_trans.text.trim().isEmpty) _trans.text = r.translation;
        if (_note.text.trim().isEmpty) _note.text = r.pos;
        if (r.example.isNotEmpty) {
          _pendingExample = Example(r.example, r.exampleTr);
        }
      });
    } catch (e) {
      if (mounted) _say('تعذّرت التعبئة التلقائية، تحقق من الإنترنت');
    } finally {
      if (mounted) setState(() => _filling = false);
    }
  }

  void _saveOne() {
    final w = _word.text.trim();
    final t = _trans.text.trim();
    if (w.isEmpty || t.isEmpty) {
      _say('أدخل الكلمة وترجمتها (أو اضغط «تعبئة تلقائية»)');
      return;
    }
    final e = widget.edit;
    if (e != null) {
      if (app.exists(w, _lang, exceptId: e.id)) {
        _say('هذه الكلمة موجودة مسبقاً');
        return;
      }
      if (e.word != w || e.lang != _lang) e.examples = [];
      e.word = w;
      e.translation = t;
      e.lang = _lang;
      e.note = _note.text.trim();
      e.daily = _daily;
      app.updateWord(e);
      Navigator.pop(context);
      return;
    }
    final ok = app.addWord(Word(
      id: app.newId(),
      word: w,
      translation: t,
      lang: _lang,
      note: _note.text.trim(),
      daily: _daily,
      examples: _pendingExample == null ? null : [_pendingExample!],
    ));
    if (!ok) {
      _say('هذه الكلمة موجودة مسبقاً');
      return;
    }
    // نبقى في النافذة لإضافة المزيد بسرعة
    _word.clear();
    _trans.clear();
    _note.clear();
    setState(() => _pendingExample = null);
    _say('تمت إضافة "$w"');
  }

  // ---------- عدة كلمات ----------
  Future<void> _saveBulk() async {
    final text = _bulk.text;
    final pairs = AppState.parseBulk(text);
    final onlyWords = _autoTranslate ? AppState.parseWordsOnly(text) : <String>[];
    if (pairs.isEmpty && onlyWords.isEmpty) {
      _say('اكتب كل سطر هكذا: كلمة, ترجمة');
      return;
    }
    var added = 0, skipped = 0, failed = 0;
    setState(() => _bulkBusy = true);
    try {
      final r = app.addPairs(pairs, _lang, daily: _daily);
      added += r.added;
      skipped += r.skipped;

      if (onlyWords.isNotEmpty) {
        final fresh = onlyWords.where((w) => !app.exists(w, _lang)).toList();
        skipped += onlyWords.length - fresh.length;
        if (fresh.isNotEmpty) {
          try {
            final tr = await ai.translateWords(fresh, _lang, app.s);
            final out = <List<String>>[];
            for (final w in fresh) {
              final hit = tr[w.toLowerCase()];
              if (hit == null) {
                failed++;
              } else {
                out.add([w, hit[0], hit[1]]);
              }
            }
            added += app.addPairs(out, _lang, daily: _daily).added;
          } catch (_) {
            failed += fresh.length;
          }
        }
      }
    } finally {
      if (mounted) setState(() => _bulkBusy = false);
    }
    if (!mounted) return;
    if (added == 0 && failed > 0) {
      _say('تعذّرت الترجمة التلقائية، تحقق من الإنترنت');
      return;
    }
    Navigator.pop(context);
    final extra = [
      if (skipped > 0) '$skipped مكررة',
      if (failed > 0) '$failed بلا ترجمة',
    ];
    toast(context,
        'تمت إضافة $added كلمة${extra.isEmpty ? '' : ' (${extra.join('، ')})'}');
  }

  // ---------- مسح من صورة ----------
  Future<void> _scan() async {
    final camera = await showModalBottomSheet<bool>(
      context: context,
      builder: (c) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            leading: const Icon(Icons.photo_camera),
            title: const Text('التقاط صورة'),
            onTap: () => Navigator.pop(c, true),
          ),
          ListTile(
            leading: const Icon(Icons.photo_library),
            title: const Text('اختيار من المعرض'),
            onTap: () => Navigator.pop(c, false),
          ),
        ]),
      ),
    );
    if (camera == null || !mounted) return;
    List<String>? words;
    try {
      words = await ocr.scan(camera: camera);
    } catch (e) {
      _say('تعذّرت قراءة الصورة');
      return;
    }
    if (words == null || !mounted) return;
    if (words.isEmpty) {
      _say('لم أجد كلمات في الصورة');
      return;
    }
    final picked = await _pickWords(words);
    if (picked == null || picked.isEmpty || !mounted) return;
    setState(() {
      final cur = _bulk.text.trim();
      _bulk.text = (cur.isEmpty ? '' : '$cur\n') + picked.join('\n');
      _autoTranslate = true;
    });
    if (!editing) _tabs.animateTo(1);
  }

  Future<List<String>?> _pickWords(List<String> words) {
    final sel = <String>{...words.take(40)};
    return showDialog<List<String>>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, set) => AlertDialog(
          title: Text('وجدت ${words.length} كلمة'),
          content: SizedBox(
            width: double.maxFinite,
            height: 360,
            child: ListView(children: [
              Wrap(spacing: 6, runSpacing: 4, children: [
                for (final w in words)
                  FilterChip(
                    label: Text(w),
                    selected: sel.contains(w),
                    onSelected: (v) =>
                        set(() => v ? sel.add(w) : sel.remove(w)),
                  ),
              ]),
            ]),
          ),
          actions: [
            TextButton(
                onPressed: () => set(() {
                      if (sel.length == words.length) {
                        sel.clear();
                      } else {
                        sel.addAll(words);
                      }
                    }),
                child: const Text('الكل / لا شيء')),
            TextButton(
                onPressed: () => Navigator.pop(c),
                child: const Text('إلغاء')),
            TextButton(
                onPressed: () => Navigator.pop(
                    c, words.where(sel.contains).toList()),
                child: Text('إضافة (${sel.length})')),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final l = langOf(_lang);
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const SizedBox(height: 10),
          if (_msg != null)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: NeoCard(
                color: C.yellow,
                radius: 14,
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                child: Text(_msg!,
                    style: const TextStyle(fontWeight: FontWeight.w900)),
              ),
            ),
          Container(
            width: 48,
            height: 5,
            decoration: BoxDecoration(
                color: isDark(context) ? Colors.white70 : C.ink,
                borderRadius: BorderRadius.circular(3)),
          ),
          const SizedBox(height: 6),
          TabBar(
            controller: _tabs,
            labelColor: isDark(context) ? Colors.white : C.ink,
            unselectedLabelColor: isDark(context) ? Colors.white60 : Colors.black54,
            indicatorColor: C.coral,
            labelStyle: const TextStyle(fontWeight: FontWeight.w900),
            tabs: [
              Tab(text: editing ? 'تعديل الكلمة' : 'كلمة واحدة'),
              if (!editing) const Tab(text: 'عدة كلمات'),
            ],
          ),
          Flexible(
            child: SizedBox(
              height: 520,
              child: TabBarView(
                controller: _tabs,
                children: [
                  _single(l),
                  if (!editing) _multi(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _single(Lang l) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        TextField(
          controller: _word,
          textDirection: langDir(l),
          textInputAction: TextInputAction.next,
          onSubmitted: (_) {
            if (_trans.text.trim().isEmpty) _autoFill();
          },
          decoration: InputDecoration(labelText: 'الكلمة (${l.name})'),
        ),
        const SizedBox(height: 10),
        NeoButton(
          label: 'تعبئة تلقائية (ترجمة + نوع + مثال)',
          icon: Icons.auto_awesome,
          color: C.yellow,
          busy: _filling,
          onPressed: _autoFill,
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _trans,
          decoration: const InputDecoration(labelText: 'الترجمة'),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _note,
          decoration:
              const InputDecoration(labelText: 'ملاحظة (اختياري، مثل: noun)'),
        ),
        if (_pendingExample != null) ...[
          const SizedBox(height: 12),
          NeoCard(
            color: C.mint,
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('مثال سيُحفظ مع الكلمة',
                    style: TextStyle(fontWeight: FontWeight.w900)),
                const SizedBox(height: 4),
                Directionality(
                  textDirection: langDir(l),
                  child: Text(_pendingExample!.text,
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                ),
                Text(_pendingExample!.translation),
              ],
            ),
          ),
        ],
        const SizedBox(height: 12),
        LangDropdown(value: _lang, onChanged: (v) => setState(() => _lang = v)),
        CheckboxListTile(
          contentPadding: EdgeInsets.zero,
          value: _daily,
          onChanged: (v) => setState(() => _daily = v ?? false),
          title: const Text('أرسلها كإشعار يومي'),
        ),
        const SizedBox(height: 4),
        NeoButton(
          label: widget.edit == null ? 'إضافة' : 'حفظ التعديل',
          icon: Icons.check,
          onPressed: _saveOne,
        ),
      ],
    );
  }

  Widget _multi() {
    final pairs = AppState.parseBulk(_bulk.text).length;
    final only =
        _autoTranslate ? AppState.parseWordsOnly(_bulk.text).length : 0;
    final n = pairs + only;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
            'اكتب كل كلمة وترجمتها مفصولتين بفاصلة، سطر لكل زوج. '
            'أو اكتب الكلمة وحدها وسأترجمها لك.',
            style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        TextField(
          controller: _bulk,
          minLines: 6,
          maxLines: 6,
          onChanged: (_) => setState(() {}),
          textDirection: TextDirection.ltr,
          decoration: const InputDecoration(
              hintText: 'apple, تفاحة\nbook\nwater'),
        ),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(
            child: NeoButton(
              label: 'مسح من صورة',
              icon: Icons.document_scanner_outlined,
              color: C.blue,
              onPressed: _scan,
            ),
          ),
        ]),
        const SizedBox(height: 8),
        CheckboxListTile(
          contentPadding: EdgeInsets.zero,
          value: _autoTranslate,
          onChanged: (v) => setState(() => _autoTranslate = v ?? true),
          title: const Text('ترجمة الكلمات التي بلا ترجمة تلقائياً'),
        ),
        LangDropdown(value: _lang, onChanged: (v) => setState(() => _lang = v)),
        CheckboxListTile(
          contentPadding: EdgeInsets.zero,
          value: _daily,
          onChanged: (v) => setState(() => _daily = v ?? false),
          title: const Text('أرسلها كلها كإشعار يومي'),
        ),
        NeoButton(
          label: n == 0 ? 'إضافة الكل' : 'إضافة $n كلمة',
          icon: Icons.playlist_add,
          busy: _bulkBusy,
          onPressed: n == 0 ? null : _saveBulk,
        ),
      ],
    );
  }
}
