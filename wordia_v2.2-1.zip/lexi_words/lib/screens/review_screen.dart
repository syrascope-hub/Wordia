import 'dart:math';

import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';
import '../theme.dart';
import 'stats_screen.dart';

class ReviewScreen extends StatefulWidget {
  const ReviewScreen({super.key});

  @override
  State<ReviewScreen> createState() => _ReviewScreenState();
}

class _ReviewScreenState extends State<ReviewScreen> {
  int _source = 0; // 0 المستحقة، 1 المفضلة، 2 اليومية، 3 الكل
  bool _reverse = false;

  List<Word>? _queue;
  int _i = 0;
  bool _flipped = false;
  int _ok = 0;
  int _no = 0;

  List<Word> _pool() {
    switch (_source) {
      case 1:
        return app.words.where((w) => w.favorite).toList();
      case 2:
        return app.words.where((w) => w.daily).toList();
      case 3:
        return [...app.words];
      default:
        return app.words.where(app.isDue).toList();
    }
  }

  void _start() {
    var p = _pool();
    if (p.isEmpty) {
      toast(context, 'لا توجد كلمات في هذا الاختيار');
      return;
    }
    // المستحقة: الأكثر تأخراً أولاً (بدل عيّنة عشوائية تُهمل المتأخرة جداً)،
    // ثم نخلط الجلسة حتى لا يكون الترتيب متوقعاً.
    if (_source == 0) {
      p.sort((a, b) => a.nextReview.compareTo(b.nextReview));
    } else {
      p.shuffle(Random());
    }
    p = p.take(20).toList()..shuffle(Random());
    setState(() {
      _queue = p;
      _i = 0;
      _ok = 0;
      _no = 0;
      _flipped = false;
    });
  }

  void _answer(bool ok) {
    final w = _queue![_i];
    app.review(w, ok);
    setState(() {
      if (ok) {
        _ok++;
      } else {
        _no++;
      }
      _i++;
      _flipped = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        return Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            title: const Text('مراجعة البطاقات'),
            actions: [
              if (_queue == null)
                IconButton(
                  tooltip: 'إحصائياتي',
                  icon: const Icon(Icons.bar_chart_rounded),
                  onPressed: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const StatsScreen())),
                ),
              if (_queue != null)
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () => setState(() => _queue = null),
                ),
            ],
          ),
          body: _queue == null
              ? _menu()
              : (_i >= _queue!.length ? _summary() : _card()),
        );
      },
    );
  }

  Widget _menu() {
    final due = app.dueCount;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        NeoCard(
          color: C.yellow,
          padding: const EdgeInsets.all(16),
          onTap: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const StatsScreen())),
          child: Row(children: [
            TweenAnimationBuilder<double>(
              tween: Tween(
                  begin: 0,
                  end: app.s.dailyGoal == 0
                      ? 0
                      : app.todayCount / app.s.dailyGoal),
              duration: const Duration(milliseconds: 900),
              curve: Curves.easeOutCubic,
              builder: (_, v, child) => GoalRing(size: 84, value: v, child: child!),
              child: Text('${app.todayCount}', style: heading(24, color: C.ink)),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('هدف اليوم', style: heading(22, color: C.ink)),
                  Text(app.todayCount >= app.s.dailyGoal
                      ? 'أنجزته! 🎉'
                      : '${app.todayCount} من ${app.s.dailyGoal} إجابة'),
                  const Text('اضغط لعرض إحصائياتك',
                      style: TextStyle(fontSize: 12)),
                ],
              ),
            ),
            const Icon(Icons.chevron_left),
          ]),
        ),
        const SizedBox(height: 14),
        NeoCard(
          color: C.pink,
          padding: const EdgeInsets.all(20),
          child: Column(children: [
            const PopIn(child: Text('🧠', style: TextStyle(fontSize: 48))),
            const SizedBox(height: 8),
            Text('$due كلمة مستحقة للمراجعة',
                textAlign: TextAlign.center, style: heading(26, color: C.ink)),
            const SizedBox(height: 4),
            Text('إجمالي كلماتك: ${app.words.length}'),
          ]),
        ),
        const SizedBox(height: 20),
        const Text('ماذا تريد أن تراجع؟',
            style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
        const SizedBox(height: 8),
        Wrap(spacing: 8, children: [
          for (final e in ['المستحقة', 'المفضلة', 'اليومية', 'الكل']
              .asMap()
              .entries)
            ChoiceChip(
              label: Text(e.value),
              selected: _source == e.key,
              onSelected: (_) => setState(() => _source = e.key),
            ),
        ]),
        const SizedBox(height: 12),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          value: _reverse,
          onChanged: (v) => setState(() => _reverse = v),
          title: const Text('اعرض الترجمة أولاً'),
          subtitle: const Text('تدرّب على استحضار الكلمة بدل المعنى'),
        ),
        const SizedBox(height: 12),
        NeoButton(
          label: 'ابدأ المراجعة',
          icon: Icons.play_arrow_rounded,
          onPressed: app.words.isEmpty ? null : _start,
        ),
        if (app.words.isEmpty)
          const Padding(
            padding: EdgeInsets.only(top: 12),
            child: Text('أضف بعض الكلمات أولاً من تبويب «الكلمات».'),
          ),
      ],
    );
  }

  Widget _card() {
    final q = _queue!;
    final w = q[_i];
    final l = w.language;
    final showWordFront = !_reverse;
    final front = showWordFront ? w.word : w.translation;
    final back = showWordFront ? w.translation : w.word;
    final frontDir = showWordFront ? langDir(l) : TextDirection.rtl;
    final backDir = showWordFront ? TextDirection.rtl : langDir(l);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      child: Column(children: [
        Row(children: [
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                value: _i / q.length,
                minHeight: 10,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Text('${_i + 1} / ${q.length}',
              style: const TextStyle(fontWeight: FontWeight.w900)),
        ]),
        const SizedBox(height: 16),
        Expanded(
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 320),
            switchInCurve: Curves.easeOutCubic,
            transitionBuilder: (child, anim) => FadeTransition(
              opacity: anim,
              child: SlideTransition(
                position: Tween<Offset>(
                        begin: const Offset(0.15, 0), end: Offset.zero)
                    .animate(anim),
                child: child,
              ),
            ),
            child: KeyedSubtree(
              key: ValueKey(_i),
              child: TweenAnimationBuilder<Color?>(
                tween: ColorTween(end: _flipped ? C.mint : C.pink),
                duration: const Duration(milliseconds: 260),
                builder: (context, bg, child) => NeoCard(
                  color: bg,
                  padding: const EdgeInsets.all(20),
                  onTap: () => setState(() => _flipped = true),
                  child: child!,
                ),
                child: SizedBox(
              width: double.infinity,
              child: SingleChildScrollView(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const SizedBox(height: 24),
                    Text('${l.flag} ${l.name}'),
                    const SizedBox(height: 16),
                    Text(front,
                        textAlign: TextAlign.center,
                        textDirection: frontDir,
                        style: heading(46, color: C.ink)),
                    if (showWordFront) ...[
                      const SizedBox(height: 12),
                      SpeakButton(text: w.word, lang: l, size: 52),
                    ],
                    if (_flipped) ...[
                      const Divider(height: 40, thickness: 2, color: C.ink),
                      Text(back,
                          textAlign: TextAlign.center,
                          textDirection: backDir,
                          style: const TextStyle(
                              fontSize: 32, fontWeight: FontWeight.w900)),
                      if (!showWordFront) ...[
                        const SizedBox(height: 12),
                        SpeakButton(text: w.word, lang: l, size: 52),
                      ],
                      if (w.examples.isNotEmpty) ...[
                        const SizedBox(height: 16),
                        Directionality(
                          textDirection: langDir(l),
                          child: Text.rich(
                            TextSpan(
                                children: highlightSpans(
                                    w.examples.first.text,
                                    w.word,
                                    const TextStyle(
                                        fontSize: 17,
                                        fontWeight: FontWeight.w700,
                                        color: C.ink))),
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ],
                    ] else ...[
                      const SizedBox(height: 28),
                      const Text('اضغط لإظهار الإجابة',
                          style: TextStyle(fontWeight: FontWeight.w700)),
                    ],
                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
                ),
              ),
            ),
          ),
        const SizedBox(height: 16),
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 220),
          child: KeyedSubtree(
            key: ValueKey(_flipped),
            child: _actions(),
          ),
        ),
      ]),
    );
  }

  Widget _actions() {
    return Column(mainAxisSize: MainAxisSize.min, children: [
        if (!_flipped)
          NeoButton(
            label: 'إظهار الإجابة',
            icon: Icons.visibility,
            color: C.yellow,
            onPressed: () => setState(() => _flipped = true),
          )
        else
          Row(children: [
            Expanded(
              child: NeoButton(
                label: 'لم أعرفها',
                icon: Icons.close,
                color: C.coral,
                onPressed: () => _answer(false),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: NeoButton(
                label: 'عرفتها',
                icon: Icons.check,
                color: C.mint,
                onPressed: () => _answer(true),
              ),
            ),
          ]),
    ]);
  }

  Widget _summary() {
    final total = _ok + _no;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        NeoCard(
          color: C.yellow,
          padding: const EdgeInsets.all(24),
          child: Column(children: [
            PopIn(
                child: Text(_ok >= _no ? '🎉' : '💪',
                    style: const TextStyle(fontSize: 56))),
            const SizedBox(height: 8),
            const Text('انتهت الجلسة',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            Text('عرفت $_ok من $total',
                style:
                    const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
          ]),
        ),
        const SizedBox(height: 20),
        NeoButton(
          label: 'جلسة جديدة',
          icon: Icons.refresh,
          onPressed: _start,
        ),
        const SizedBox(height: 12),
        NeoButton(
          label: 'رجوع',
          color: C.blue,
          onPressed: () => setState(() => _queue = null),
        ),
      ],
    );
  }
}
