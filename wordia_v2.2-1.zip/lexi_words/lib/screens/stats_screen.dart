import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';
import '../theme.dart';
import 'word_detail.dart';

class StatsScreen extends StatelessWidget {
  const StatsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final goal = app.s.dailyGoal;
        final today = app.todayCount;
        final words = app.words;
        final mastered = words.where((w) => w.box >= 4).length;
        final learning = words.where((w) => w.box > 0 && w.box < 4).length;
        final fresh = words.where((w) => w.box == 0).length;
        final total = words.fold<int>(0, (a, w) => a + w.correct + w.wrong);
        final right = words.fold<int>(0, (a, w) => a + w.correct);
        final acc = total == 0 ? 0 : (right * 100 / total).round();
        final hard = [...words.where((w) => w.wrong > 0)]
          ..sort((a, b) => b.wrong.compareTo(a.wrong));

        final byLang = <String, int>{};
        for (final w in words) {
          byLang[w.lang] = (byLang[w.lang] ?? 0) + 1;
        }
        final langs = byLang.entries.toList()
          ..sort((a, b) => b.value.compareTo(a.value));

        return Scaffold(
          backgroundColor: isDark(context) ? C.darkBg : C.blue,
          appBar: AppBar(title: const Text('إحصائياتي')),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
            children: [
              NeoCard(
                color: C.yellow,
                padding: const EdgeInsets.all(18),
                child: Row(children: [
                  GoalRing(
                    value: goal == 0 ? 0 : today / goal,
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      Text('$today', style: heading(30, color: C.ink)),
                      Text('من $goal',
                          style: const TextStyle(fontWeight: FontWeight.w800)),
                    ]),
                  ),
                  const SizedBox(width: 18),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(today >= goal ? 'أنجزت هدف اليوم! 🎉' : 'هدف اليوم',
                            style: heading(24, color: C.ink)),
                        const SizedBox(height: 4),
                        Text(today >= goal
                            ? 'كل إجابة إضافية تقوّي ذاكرتك.'
                            : 'تبقّى ${goal - today} إجابة لتحقيق هدفك.'),
                        const SizedBox(height: 8),
                        Row(children: [
                          for (final g in [5, 10, 20, 30])
                            Padding(
                              padding: const EdgeInsetsDirectional.only(end: 6),
                              child: GestureDetector(
                                onTap: () {
                                  app.s.dailyGoal = g;
                                  app.saveSettings();
                                },
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 9, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: goal == g ? C.ink : Colors.white,
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(color: C.ink, width: 2),
                                  ),
                                  child: Text('$g',
                                      style: TextStyle(
                                          fontWeight: FontWeight.w900,
                                          color: goal == g ? Colors.white : C.ink)),
                                ),
                              ),
                            ),
                        ]),
                      ],
                    ),
                  ),
                ]),
              ),
              const SizedBox(height: 16),
              Row(children: [
                Expanded(child: _num('🔥', '${app.streak}', 'أيام متتالية', C.coral)),
                const SizedBox(width: 12),
                Expanded(child: _num('📚', '${words.length}', 'كلمة', C.mint)),
                const SizedBox(width: 12),
                Expanded(child: _num('🎯', '$acc٪', 'دقة الإجابات', C.pink)),
              ]),
              const SizedBox(height: 16),
              NeoCard(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('نشاط آخر 17 أسبوعاً', style: heading(22)),
                    const SizedBox(height: 12),
                    _Heatmap(goal: goal),
                    const SizedBox(height: 8),
                    Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                      const Text('أقل ', style: TextStyle(fontSize: 12)),
                      for (final c in _levels)
                        Container(
                          width: 14,
                          height: 14,
                          margin: const EdgeInsets.symmetric(horizontal: 2),
                          decoration: BoxDecoration(
                              color: c, borderRadius: BorderRadius.circular(4)),
                        ),
                      const Text(' أكثر', style: TextStyle(fontSize: 12)),
                    ]),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              NeoCard(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('مستوى الحفظ', style: heading(22)),
                    const SizedBox(height: 12),
                    _bar('جديدة / للإعادة', fresh, words.length, C.blue),
                    _bar('قيد التعلّم', learning, words.length, C.yellow),
                    _bar('محفوظة', mastered, words.length, C.mint),
                  ],
                ),
              ),
              if (langs.isNotEmpty) ...[
                const SizedBox(height: 16),
                NeoCard(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('اللغات', style: heading(22)),
                      const SizedBox(height: 12),
                      for (final e in langs)
                        _bar('${langOf(e.key).flag} ${langOf(e.key).name}',
                            e.value, words.length, C.pink),
                    ],
                  ),
                ),
              ],
              if (hard.isNotEmpty) ...[
                const SizedBox(height: 16),
                NeoCard(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('أصعب كلماتك', style: heading(22)),
                      const SizedBox(height: 8),
                      for (final w in hard.take(6))
                        ListTile(
                          contentPadding: EdgeInsets.zero,
                          dense: true,
                          onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => WordDetail(word: w))),
                          leading: Text(w.language.flag,
                              style: const TextStyle(fontSize: 22)),
                          title: Text(w.word,
                              textDirection: langDir(w.language),
                              style: const TextStyle(fontWeight: FontWeight.w900)),
                          subtitle: Text(w.translation),
                          trailing: Text('✗ ${w.wrong}',
                              style: const TextStyle(fontWeight: FontWeight.w900)),
                        ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        );
      },
    );
  }

  static const _levels = [
    Color(0x1F000000),
    Color(0xFFCDEFE8),
    Color(0xFF8DD9C9),
    C.coral,
  ];

  Widget _num(String emoji, String v, String label, Color color) {
    return NeoCard(
      color: color,
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
      child: Column(children: [
        Text(emoji, style: const TextStyle(fontSize: 26)),
        Text(v, style: heading(28, color: C.ink)),
        Text(label,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800)),
      ]),
    );
  }

  Widget _bar(String label, int n, int total, Color color) {
    final f = total == 0 ? 0.0 : n / total;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(
              child: Text(label,
                  style: const TextStyle(fontWeight: FontWeight.w800))),
          Text('$n', style: const TextStyle(fontWeight: FontWeight.w900)),
        ]),
        const SizedBox(height: 4),
        Container(
          height: 14,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: C.ink, width: 2),
          ),
          child: Align(
            alignment: AlignmentDirectional.centerStart,
            child: FractionallySizedBox(
              widthFactor: f.clamp(0.0, 1.0).toDouble(),
              child: Container(
                  decoration: BoxDecoration(
                      color: color, borderRadius: BorderRadius.circular(5))),
            ),
          ),
        ),
      ]),
    );
  }
}

/// خريطة حرارية: عمود لكل أسبوع وصفّ لكل يوم (السبت أولاً).
class _Heatmap extends StatelessWidget {
  final int goal;
  const _Heatmap({required this.goal});

  Color _color(int n) {
    if (n <= 0) return StatsScreen._levels[0];
    final g = goal <= 0 ? 10 : goal;
    if (n < g * 0.5) return StatsScreen._levels[1];
    if (n < g) return StatsScreen._levels[2];
    return StatsScreen._levels[3];
  }

  @override
  Widget build(BuildContext context) {
    const weeks = 17;
    final today = app.todayNo;
    // 1970-01-01 كان يوم خميس: (day + 5) % 7 => 0 للسبت
    int row(int day) => (day + 5) % 7;
    final start = today - row(today) - (weeks - 1) * 7;
    return Directionality(
      textDirection: TextDirection.ltr,
      child: LayoutBuilder(builder: (context, box) {
        final cell =
            ((box.maxWidth - (weeks - 1) * 3) / weeks).clamp(8.0, 18.0).toDouble();
        return Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            for (var c = 0; c < weeks; c++)
              Padding(
                padding: EdgeInsets.only(right: c == weeks - 1 ? 0 : 3),
                child: Column(children: [
                  for (var r = 0; r < 7; r++)
                    Builder(builder: (_) {
                      final day = start + c * 7 + r;
                      if (day > today) {
                        return SizedBox(width: cell, height: cell + 3);
                      }
                      return Container(
                        width: cell,
                        height: cell,
                        margin: const EdgeInsets.only(bottom: 3),
                        decoration: BoxDecoration(
                          color: _color(app.history[day] ?? 0),
                          borderRadius: BorderRadius.circular(4),
                          border: day == today
                              ? Border.all(color: C.ink, width: 1.5)
                              : null,
                        ),
                      );
                    }),
                ]),
              ),
          ],
        );
      }),
    );
  }
}
