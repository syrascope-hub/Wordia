import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:printing/printing.dart';

import '../models.dart';
import '../services/ai_service.dart';
import '../services/ocr_service.dart';
import '../services/worksheet_service.dart';
import '../store.dart';
import '../theme.dart';
import 'settings_screen.dart';
import 'study_widgets.dart';

const Color _kOk = Color(0xFF7ED9A8);

/// يفتح نافذة خيارات ثم معاينة طباعة/حفظ PDF لورقة العمل.
Future<void> exportWorksheet(BuildContext context, QuizSet qs) async {
  var key = true;
  final ok = await showDialog<bool>(
    context: context,
    builder: (c) => StatefulBuilder(
      builder: (c, setD) => AlertDialog(
        title: const Text('ورقة عمل'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('ستُفتح معاينة يمكنك منها الطباعة أو الحفظ كملف PDF أو المشاركة.'),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: key,
            onChanged: (v) => setD(() => key = v),
            title: const Text('أضف صفحة الإجابات'),
          ),
        ]),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c, false),
              child: const Text('إلغاء')),
          TextButton(
              onPressed: () => Navigator.pop(c, true),
              child: const Text('إنشاء')),
        ],
      ),
    ),
  );
  if (ok != true) return;
  final html = buildWorksheetHtml(qs, answerKey: key);
  try {
    await Printing.layoutPdf(
      name: 'worksheet',
      onLayout: (format) => Printing.convertHtml(format: format, html: html),
    );
  } catch (_) {
    if (context.mounted) toast(context, 'تعذّر إنشاء الورقة');
  }
}

String _titleOf(String t) {
  final first = t.split(RegExp(r'[\r\n]+')).first.trim();
  if (first.isEmpty) return 'اختبار';
  return first.length > 50 ? '${first.substring(0, 50)}…' : first;
}

/// تبويب الاختبارات: حوّل نصاً أو صورة إلى اختبار، أو حلّ مسائل، أو اشرح نصاً.
class QuizScreen extends StatefulWidget {
  const QuizScreen({super.key});

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  final _text = TextEditingController();
  final _picker = ImagePicker();

  String _mode = 'mcq'; // mcq | solve | explain
  int _count = 10;
  String _level = 'متوسط';
  bool _qAr = false;
  bool _busy = false;
  bool _reading = false;
  String? _error;
  String? _explain;

  static const _modes = {
    'mcq': '📝 اختبار',
    'solve': '🧮 حل مسائل',
    'explain': '💡 شرح',
  };

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  Future<void> _paste() async {
    final d = await Clipboard.getData(Clipboard.kTextPlain);
    final t = d?.text ?? '';
    if (t.trim().isEmpty) {
      if (mounted) toast(context, 'الحافظة فارغة');
      return;
    }
    setState(() => _text.text = t);
  }

  Future<void> _pickFile() async {
    setState(() => _reading = true);
    try {
      final res = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: const ['txt'],
        withData: true,
      );
      if (res == null || res.files.isEmpty) return;
      final f = res.files.first;
      final bytes = f.bytes ?? await File(f.path!).readAsBytes();
      final t = utf8.decode(bytes, allowMalformed: true);
      if (mounted) setState(() => _text.text = t.trim());
    } catch (_) {
      if (mounted) toast(context, 'تعذّر قراءة الملف');
    } finally {
      if (mounted) setState(() => _reading = false);
    }
  }

  /// صورة ← نص: أولاً بنموذج رؤية (يدعم العربية والمعادلات)، ثم OCR محلي احتياطي.
  Future<void> _fromImage(bool camera) async {
    setState(() {
      _reading = true;
      _error = null;
    });
    try {
      final x = await _picker.pickImage(
        source: camera ? ImageSource.camera : ImageSource.gallery,
        maxWidth: 1800,
        imageQuality: 85,
      );
      if (x == null) return;
      var t = '';
      try {
        t = await ai.imageToText(await x.readAsBytes(), app.s);
      } catch (_) {}
      if (t.trim().length < 15) {
        try {
          t = await ocr.readFile(x.path);
        } catch (_) {}
      }
      if (!mounted) return;
      if (t.trim().isEmpty) {
        toast(context, 'لم أستطع قراءة نص من الصورة');
        return;
      }
      setState(() => _text.text = t.trim());
    } catch (_) {
      if (mounted) toast(context, 'تعذّر فتح الصورة');
    } finally {
      if (mounted) setState(() => _reading = false);
    }
  }

  Future<void> _run() async {
    FocusScope.of(context).unfocus();
    final t = _text.text.trim();
    if (t.length < 30) {
      setState(() => _error = 'النص قصير. الصق نصاً أو صوّر صفحة (30 حرفاً على الأقل).');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
      _explain = null;
    });
    try {
      if (_mode == 'mcq') {
        final items = await ai.makeQuiz(t,
            count: _count, level: _level, arabicQ: _qAr, s: app.s);
        final qs = QuizSet(
            id: app.newId(),
            ts: DateTime.now().millisecondsSinceEpoch,
            title: _titleOf(t),
            mode: 'mcq',
            items: items);
        app.addQuiz(qs);
        if (!mounted) return;
        await Navigator.push(context,
            MaterialPageRoute(builder: (_) => QuizPlayPage(qs: qs)));
      } else if (_mode == 'solve') {
        final solves = await ai.solveProblems(t, app.s);
        final qs = QuizSet(
            id: app.newId(),
            ts: DateTime.now().millisecondsSinceEpoch,
            title: _titleOf(t),
            mode: 'solve',
            solves: solves);
        app.addQuiz(qs);
        if (!mounted) return;
        await Navigator.push(
            context, MaterialPageRoute(builder: (_) => SolvePage(qs: qs)));
      } else {
        final ex = await ai.explainText(t, app.s);
        if (mounted) setState(() => _explain = ex);
      }
    } catch (e) {
      if (mounted) {
        final msg = e.toString().replaceFirst('Exception: ', '');
        setState(() => _error = msg.startsWith('لم ')
            ? msg
            : 'تعذّرت العملية. تحقق من الإنترنت وأعد المحاولة.');
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _open(QuizSet q) {
    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (_) =>
              q.mode == 'mcq' ? QuizPlayPage(qs: q) : SolvePage(qs: q)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final dark = isDark(context);
    final fg = dark ? Colors.white : C.ink;
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final hist = app.quizHistory;
        return Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            title: const Text('اختبار سريع'),
            actions: [
              IconButton(
                tooltip: 'الإعدادات',
                icon: const Icon(Icons.settings_outlined),
                onPressed: () => openSettings(context),
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
            children: [
              const AiKeyBanner(),
              NeoCard(
                color: C.yellow,
                padding: const EdgeInsets.all(16),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('ماذا تريد؟', style: heading(22, color: C.ink)),
                      const SizedBox(height: 8),
                      Wrap(spacing: 8, runSpacing: 4, children: [
                        for (final e in _modes.entries)
                          ChoiceChip(
                            label: Text(e.value),
                            selected: _mode == e.key,
                            onSelected: _busy
                                ? null
                                : (_) => setState(() => _mode = e.key),
                          ),
                      ]),
                      const SizedBox(height: 10),
                      TextField(
                        controller: _text,
                        enabled: !_busy,
                        minLines: 5,
                        maxLines: 10,
                        textDirection: autoDir(_text.text),
                        style: const TextStyle(color: C.ink),
                        onChanged: (_) => setState(() {}),
                        decoration: InputDecoration(
                            hintText: switch (_mode) {
                          'solve' => 'الصق المسائل أو صوّرها…',
                          'explain' => 'الصق النص الذي تريد شرحه…',
                          _ => 'الصق النص الذي تريد أن يتحوّل لاختبار…',
                        }),
                      ),
                      const SizedBox(height: 10),
                      Row(children: [
                        Expanded(
                            child: NeoButton(
                                label: 'لصق',
                                icon: Icons.content_paste,
                                color: C.blue,
                                onPressed: _busy || _reading ? null : _paste)),
                        const SizedBox(width: 8),
                        Expanded(
                            child: NeoButton(
                                label: 'كاميرا',
                                icon: Icons.photo_camera,
                                color: C.pink,
                                busy: _reading,
                                onPressed: _busy || _reading
                                    ? null
                                    : () => _fromImage(true))),
                      ]),
                      const SizedBox(height: 8),
                      Row(children: [
                        Expanded(
                            child: NeoButton(
                                label: 'صورة',
                                icon: Icons.image,
                                color: C.pink,
                                onPressed: _busy || _reading
                                    ? null
                                    : () => _fromImage(false))),
                        const SizedBox(width: 8),
                        Expanded(
                            child: NeoButton(
                                label: 'ملف txt',
                                icon: Icons.description,
                                color: C.mint,
                                onPressed:
                                    _busy || _reading ? null : _pickFile)),
                      ]),
                      const SizedBox(height: 6),
                      const Text(
                          'الصور تُقرأ بالذكاء الاصطناعي (تدعم العربية والمعادلات) '
                          'وإن تعذّر فبقارئ محلي للحروف اللاتينية.',
                          style: TextStyle(fontSize: 12)),
                    ]),
              ),
              if (_mode == 'mcq') ...[
                const SizedBox(height: 14),
                NeoCard(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('عدد الأسئلة',
                            style: TextStyle(fontWeight: FontWeight.w900)),
                        const SizedBox(height: 6),
                        Wrap(spacing: 8, children: [
                          for (final n in const [5, 10, 15])
                            ChoiceChip(
                              label: Text('$n'),
                              selected: _count == n,
                              onSelected:
                                  _busy ? null : (_) => setState(() => _count = n),
                            ),
                        ]),
                        const SizedBox(height: 10),
                        const Text('المستوى',
                            style: TextStyle(fontWeight: FontWeight.w900)),
                        const SizedBox(height: 6),
                        Wrap(spacing: 8, children: [
                          for (final l in const ['سهل', 'متوسط', 'صعب'])
                            ChoiceChip(
                              label: Text(l),
                              selected: _level == l,
                              onSelected:
                                  _busy ? null : (_) => setState(() => _level = l),
                            ),
                        ]),
                        SwitchListTile(
                          contentPadding: EdgeInsets.zero,
                          value: _qAr,
                          onChanged: _busy ? null : (v) => setState(() => _qAr = v),
                          title: const Text('الأسئلة بالعربية'),
                          subtitle: const Text('وإلا فبلغة النص نفسها'),
                        ),
                      ]),
                ),
              ],
              const SizedBox(height: 14),
              NeoButton(
                label: switch (_mode) {
                  'solve' => 'حلّ المسائل',
                  'explain' => 'اشرح النص',
                  _ => 'أنشئ الاختبار',
                },
                icon: Icons.auto_awesome,
                color: C.coral,
                busy: _busy,
                onPressed: _run,
              ),
              if (_error != null)
                Padding(
                  padding: const EdgeInsets.only(top: 12),
                  child: NeoCard(
                    color: const Color(0xFFFFC9C0),
                    child: Text(_error!,
                        style: const TextStyle(fontWeight: FontWeight.w800)),
                  ),
                ),
              if (_explain != null && !_busy) ...[
                const SizedBox(height: 14),
                NeoCard(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Directionality(
                          textDirection: autoDir(_explain!),
                          child: SelectableText.rich(
                            TextSpan(
                                children: mdSpans(
                                    _explain!,
                                    TextStyle(
                                        fontSize: 16,
                                        height: 1.6,
                                        color: fg))),
                          ),
                        ),
                        const SizedBox(height: 10),
                        Row(children: [
                          Expanded(
                            child: NeoButton(
                              label: 'نسخ',
                              icon: Icons.copy,
                              color: C.blue,
                              onPressed: () {
                                Clipboard.setData(ClipboardData(text: _explain!));
                                toast(context, 'تم النسخ');
                              },
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: NeoButton(
                              label: 'حوّله لاختبار',
                              icon: Icons.quiz,
                              color: C.mint,
                              onPressed: () {
                                setState(() => _mode = 'mcq');
                                _run();
                              },
                            ),
                          ),
                        ]),
                      ]),
                ),
              ],
              if (hist.isNotEmpty) ...[
                const SizedBox(height: 20),
                Text('السجل', style: heading(22, color: fg)),
                const SizedBox(height: 8),
                for (final q in hist)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: NeoCard(
                      padding: const EdgeInsets.all(12),
                      onTap: () => _open(q),
                      child: Row(children: [
                        Text(q.mode == 'mcq' ? '📝' : '🧮',
                            style: const TextStyle(fontSize: 26)),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(q.title,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w800)),
                                Text(
                                    q.mode == 'mcq'
                                        ? '${q.items.length} سؤال'
                                            '${q.lastScore >= 0 ? ' • آخر نتيجة ${q.lastScore}٪' : ''}'
                                        : '${q.solves.length} مسألة',
                                    style: const TextStyle(fontSize: 12.5)),
                              ]),
                        ),
                        IconButton(
                          tooltip: 'ورقة عمل',
                          icon: const Icon(Icons.print_outlined),
                          onPressed: () => exportWorksheet(context, q),
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete_outline),
                          onPressed: () => app.removeQuiz(q.id),
                        ),
                      ]),
                    ),
                  ),
              ],
            ],
          ),
        );
      },
    );
  }
}

// ======================= حلّ الاختبار =======================

class QuizPlayPage extends StatefulWidget {
  final QuizSet qs;
  const QuizPlayPage({super.key, required this.qs});

  @override
  State<QuizPlayPage> createState() => _QuizPlayPageState();
}

class _QuizPlayPageState extends State<QuizPlayPage> {
  late List<QuizItem> _qs;
  int _i = 0;
  int _score = 0;
  int? _picked;
  final List<QuizItem> _wrong = [];
  String? _more;
  bool _moreBusy = false;

  @override
  void initState() {
    super.initState();
    _qs = [...widget.qs.items]..shuffle();
  }

  void _pick(int k) {
    if (_picked != null) return;
    final q = _qs[_i];
    setState(() {
      _picked = k;
      if (k == q.answer) {
        _score++;
      } else {
        _wrong.add(q);
      }
    });
  }

  void _next() {
    setState(() {
      _i++;
      _picked = null;
      _more = null;
    });
    if (_i >= _qs.length) {
      widget.qs.lastScore = (_score * 100 / _qs.length).round();
      app.updateQuiz(widget.qs);
    }
  }

  void _again() {
    setState(() {
      _qs = [...widget.qs.items]..shuffle();
      _i = 0;
      _score = 0;
      _picked = null;
      _more = null;
      _wrong.clear();
    });
  }

  Future<void> _explainMore() async {
    final q = _qs[_i];
    setState(() => _moreBusy = true);
    try {
      final t = await ai.explainAnswer(
          q, _picked == null ? '' : q.options[_picked!], app.s);
      if (mounted) setState(() => _more = t);
    } catch (_) {
      if (mounted) toast(context, 'تعذّر الشرح، حاول لاحقاً');
    } finally {
      if (mounted) setState(() => _moreBusy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final done = _i >= _qs.length;
    return Scaffold(
      backgroundColor: isDark(context) ? C.darkBg : const Color(0xFFD9C8FF),
      appBar: AppBar(
        title: const Text('اختبار'),
        actions: [
          if (!done)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Center(
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    color: C.cream,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: C.ink, width: 2),
                  ),
                  child: Text('${_i + 1} / ${_qs.length}',
                      style: const TextStyle(
                          fontWeight: FontWeight.w900, color: C.ink)),
                ),
              ),
            ),
        ],
      ),
      body: done ? _result() : _question(),
    );
  }

  Widget _question() {
    final q = _qs[_i];
    final dark = isDark(context);
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 28),
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: LinearProgressIndicator(value: _i / _qs.length, minHeight: 10),
        ),
        const SizedBox(height: 14),
        NeoCard(
          color: C.yellow,
          padding: const EdgeInsets.all(20),
          child: SizedBox(
            width: double.infinity,
            child: Text(q.q,
                textDirection: autoDir(q.q),
                style: const TextStyle(
                    fontSize: 20, height: 1.5, fontWeight: FontWeight.w900)),
          ),
        ),
        const SizedBox(height: 16),
        for (var k = 0; k < q.options.length; k++)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: NeoCard(
              color: _picked == null
                  ? null
                  : (k == q.answer
                      ? _kOk
                      : (k == _picked ? C.coral : null)),
              onTap: _picked == null ? () => _pick(k) : null,
              padding: const EdgeInsets.all(16),
              child: SizedBox(
                width: double.infinity,
                child: Text(q.options[k],
                    textDirection: autoDir(q.options[k]),
                    style: const TextStyle(
                        fontSize: 17, fontWeight: FontWeight.w800)),
              ),
            ),
          ),
        if (_picked != null) ...[
          NeoCard(
            color: _picked == q.answer ? _kOk : const Color(0xFFFFC9C0),
            padding: const EdgeInsets.all(14),
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(_picked == q.answer ? 'إجابة صحيحة ✓' : 'إجابة خاطئة ✗',
                      style: heading(20, color: C.ink)),
                  if (_picked != q.answer) ...[
                    const SizedBox(height: 4),
                    Text('الصحيحة: ${q.options[q.answer]}',
                        textDirection: autoDir(q.options[q.answer]),
                        style: const TextStyle(fontWeight: FontWeight.w900)),
                  ],
                  if (q.explanation.isNotEmpty) ...[
                    const SizedBox(height: 6),
                    Text(q.explanation, style: const TextStyle(height: 1.5)),
                  ],
                  if (_more != null) ...[
                    const Divider(height: 20, thickness: 2, color: C.ink),
                    SelectableText.rich(TextSpan(
                        children: mdSpans(
                            _more!,
                            const TextStyle(
                                fontSize: 15, height: 1.55, color: C.ink)))),
                  ],
                ]),
          ),
          const SizedBox(height: 12),
          if (_more == null)
            NeoButton(
              label: 'فسّر أكثر',
              icon: Icons.lightbulb_outline,
              color: dark ? C.blue : Colors.white,
              busy: _moreBusy,
              onPressed: _explainMore,
            ),
          const SizedBox(height: 12),
          NeoButton(
            label: _i + 1 >= _qs.length ? 'عرض النتيجة' : 'التالي',
            icon: Icons.arrow_back,
            color: C.mint,
            onPressed: _next,
          ),
        ],
      ],
    );
  }

  Widget _result() {
    final total = _qs.length;
    final pct = (_score * 100 / total).round();
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        NeoCard(
          color: C.yellow,
          padding: const EdgeInsets.all(24),
          child: Column(children: [
            Text(pct >= 70 ? '🏆' : '💪', style: const TextStyle(fontSize: 60)),
            const SizedBox(height: 8),
            Text('$_score / $total',
                style:
                    const TextStyle(fontSize: 34, fontWeight: FontWeight.w900)),
            Text('$pct٪ إجابات صحيحة'),
          ]),
        ),
        if (_wrong.isNotEmpty) ...[
          const SizedBox(height: 18),
          Text('راجع أخطاءك',
              style: heading(22, color: isDark(context) ? Colors.white : C.ink)),
          const SizedBox(height: 8),
          for (final q in _wrong)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: NeoCard(
                padding: const EdgeInsets.all(14),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(q.q,
                          textDirection: autoDir(q.q),
                          style: const TextStyle(fontWeight: FontWeight.w900)),
                      const SizedBox(height: 4),
                      Text('✓ ${q.options[q.answer]}',
                          textDirection: autoDir(q.options[q.answer]),
                          style: const TextStyle(
                              color: Color(0xFF1B8A6B),
                              fontWeight: FontWeight.w800)),
                      if (q.explanation.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Text(q.explanation,
                              style: const TextStyle(height: 1.5)),
                        ),
                    ]),
              ),
            ),
        ],
        const SizedBox(height: 14),
        NeoButton(
            label: 'أعد الاختبار',
            icon: Icons.refresh,
            color: C.coral,
            onPressed: _again),
        const SizedBox(height: 10),
        NeoButton(
            label: 'حوّله إلى ورقة عمل',
            icon: Icons.print_outlined,
            color: C.mint,
            onPressed: () => exportWorksheet(context, widget.qs)),
        const SizedBox(height: 10),
        NeoButton(
            label: 'رجوع',
            color: C.blue,
            onPressed: () => Navigator.pop(context)),
      ],
    );
  }
}

// ======================= حلّ المسائل =======================

class SolvePage extends StatelessWidget {
  final QuizSet qs;
  const SolvePage({super.key, required this.qs});

  String _asText() {
    final b = StringBuffer();
    for (var i = 0; i < qs.solves.length; i++) {
      final s = qs.solves[i];
      b.writeln('${i + 1}. ${s.problem}');
      for (var k = 0; k < s.steps.length; k++) {
        b.writeln('   ${k + 1}) ${s.steps[k]}');
      }
      b.writeln('   الجواب: ${s.answer}\n');
    }
    return b.toString();
  }

  @override
  Widget build(BuildContext context) {
    final dark = isDark(context);
    return Scaffold(
      backgroundColor: dark ? C.darkBg : const Color(0xFFD9C8FF),
      appBar: AppBar(title: const Text('حلّ المسائل')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 28),
        children: [
          NeoCard(
            color: C.yellow,
            padding: const EdgeInsets.all(12),
            child: const Text(
                'حاول الحل بنفسك أولاً ثم افتح المسألة لترى الخطوات. '
                'قد يخطئ الذكاء الاصطناعي في الحسابات، فراجع الحلول المهمة.',
                style: TextStyle(fontWeight: FontWeight.w700, height: 1.5)),
          ),
          const SizedBox(height: 12),
          for (var i = 0; i < qs.solves.length; i++)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: NeoCard(
                padding: EdgeInsets.zero,
                child: Theme(
                  data: Theme.of(context)
                      .copyWith(dividerColor: Colors.transparent),
                  child: ExpansionTile(
                    tilePadding:
                        const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                    childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
                    expandedCrossAxisAlignment: CrossAxisAlignment.start,
                    title: Text('${i + 1}. ${qs.solves[i].problem}',
                        textDirection: autoDir(qs.solves[i].problem),
                        style: const TextStyle(
                            fontWeight: FontWeight.w900, height: 1.4)),
                    children: [
                      for (var k = 0; k < qs.solves[i].steps.length; k++)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 6),
                          child: SelectableText(
                              '${k + 1}) ${qs.solves[i].steps[k]}',
                              style: const TextStyle(height: 1.5)),
                        ),
                      const SizedBox(height: 6),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: _kOk,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: C.ink, width: 2),
                        ),
                        child: SelectableText('الجواب: ${qs.solves[i].answer}',
                            style: const TextStyle(
                                color: C.ink, fontWeight: FontWeight.w900)),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          const SizedBox(height: 6),
          NeoButton(
              label: 'حوّلها إلى ورقة عمل',
              icon: Icons.print_outlined,
              color: C.mint,
              onPressed: () => exportWorksheet(context, qs)),
          const SizedBox(height: 10),
          NeoButton(
              label: 'نسخ الحلول',
              icon: Icons.copy,
              color: C.blue,
              onPressed: () {
                Clipboard.setData(ClipboardData(text: _asText()));
                toast(context, 'تم النسخ');
              }),
        ],
      ),
    );
  }
}
