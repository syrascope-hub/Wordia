import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models.dart';
import '../services/ai_service.dart';
import '../services/ocr_service.dart';
import '../store.dart';
import '../theme.dart';
import 'summary_widgets.dart';

/// تلخيص نص ملصوق، أو صورة (OCR)، أو ملف .txt، واستخراج كلمات للتعلّم.
class TextSummaryScreen extends StatefulWidget {
  const TextSummaryScreen({super.key});

  @override
  State<TextSummaryScreen> createState() => _TextSummaryScreenState();
}

class _TextSummaryScreenState extends State<TextSummaryScreen> {
  final _text = TextEditingController();
  late String _lang = app.s.defaultLang;
  String _style = 'points';
  String _out = 'ar'; // ar | src
  String _source = 'text';
  bool _busy = false;
  bool _reading = false;
  String? _error;

  SummaryResult? _sum;
  String _shownTitle = '';
  String _shownLang = 'en';
  bool _shownSrc = false;

  static const _styles = {
    'short': 'قصير',
    'points': 'نقاط رئيسية',
    'detailed': 'مفصّل',
  };
  static const _maxChars = 40000; // ≈ 6 آلاف كلمة

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  Future<void> _paste() async {
    final d = await Clipboard.getData(Clipboard.kTextPlain);
    final t = d?.text ?? '';
    if (t.trim().isEmpty) {
      if (mounted) toast(context, 'الحافظة فارغة');
      return;
    }
    setState(() {
      _text.text = t;
      _source = 'text';
    });
  }

  Future<void> _scan(bool camera) async {
    setState(() => _reading = true);
    try {
      final t = await ocr.scanText(camera: camera);
      if (t == null) return;
      if (t.trim().isEmpty) {
        if (mounted) toast(context, 'لم يُعثر على نص في الصورة');
        return;
      }
      if (mounted) {
        setState(() {
          _text.text = t.trim();
          _source = 'image';
        });
      }
    } catch (_) {
      if (mounted) toast(context, 'تعذّر قراءة الصورة');
    } finally {
      if (mounted) setState(() => _reading = false);
    }
  }

  Future<void> _pickFile() async {
    setState(() => _reading = true);
    try {
      final res = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: const ['txt'],
        withData: true,
      );
      if (res == null || res.files.isEmpty) return;
      final f = res.files.first;
      final bytes = f.bytes ?? await File(f.path!).readAsBytes();
      final t = utf8.decode(bytes, allowMalformed: true);
      if (mounted) {
        setState(() {
          _text.text = t.trim();
          _source = 'file';
        });
      }
    } catch (_) {
      if (mounted) toast(context, 'تعذّر قراءة الملف');
    } finally {
      if (mounted) setState(() => _reading = false);
    }
  }

  Future<void> _run() async {
    FocusScope.of(context).unfocus();
    var t = _text.text.trim();
    if (t.length < 80) {
      setState(() => _error = 'النص قصير جداً. الصق نصاً أطول (80 حرفاً على الأقل).');
      return;
    }
    var note = '';
    if (t.length > _maxChars) {
      t = t.substring(0, _maxChars);
      note = 'تم تلخيص أول ${_maxChars ~/ 6} كلمة تقريباً.';
    }
    setState(() {
      _busy = true;
      _error = null;
      _sum = null;
    });
    try {
      final r = await ai.summarizeText(t, _lang, _style, '', app.s, outLang: _out);
      if (!mounted) return;
      final firstLine = t.split(RegExp(r'[\r\n]+')).first.trim();
      final title = firstLine.length > 50 ? '${firstLine.substring(0, 50)}…' : firstLine;
      setState(() {
        _sum = r;
        _shownTitle = title;
        _shownLang = _lang;
        _shownSrc = _out == 'src';
        if (note.isNotEmpty) _error = note;
      });
      app.addSummary(recFrom(r, title: title, lang: _lang, source: _source));
    } catch (_) {
      if (mounted) {
        setState(() => _error = 'تعذّر التلخيص. تحقق من الإنترنت وأعد المحاولة.');
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _open(SummaryRec r) {
    setState(() {
      _sum = resultFrom(r);
      _shownTitle = r.title;
      _shownLang = r.lang;
      _shownSrc = false;
      _error = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final dark = isDark(context);
    final hist = app.sumHistory;
    return Scaffold(
      backgroundColor: dark ? C.darkBg : C.mint,
      appBar: AppBar(title: const Text('تلخيص نص')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
        children: [
          NeoCard(
            color: C.yellow,
            padding: const EdgeInsets.all(16),
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('النص', style: heading(22, color: C.ink)),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _text,
                    enabled: !_busy,
                    minLines: 5,
                    maxLines: 10,
                    textDirection: autoDir(_text.text),
                    style: const TextStyle(color: C.ink),
                    onChanged: (_) => setState(() => _source = 'text'),
                    decoration:
                        const InputDecoration(hintText: 'الصق نصاً أو اكتبه هنا…'),
                  ),
                  const SizedBox(height: 10),
                  Row(children: [
                    Expanded(
                        child: NeoButton(
                            label: 'لصق',
                            icon: Icons.content_paste,
                            color: C.blue,
                            onPressed: _busy || _reading ? null : _paste)),
                    const SizedBox(width: 8),
                    Expanded(
                        child: NeoButton(
                            label: 'كاميرا',
                            icon: Icons.photo_camera,
                            color: C.pink,
                            onPressed:
                                _busy || _reading ? null : () => _scan(true))),
                  ]),
                  const SizedBox(height: 8),
                  Row(children: [
                    Expanded(
                        child: NeoButton(
                            label: 'صورة',
                            icon: Icons.image,
                            color: C.pink,
                            onPressed:
                                _busy || _reading ? null : () => _scan(false))),
                    const SizedBox(width: 8),
                    Expanded(
                        child: NeoButton(
                            label: 'ملف txt',
                            icon: Icons.description,
                            color: C.mint,
                            busy: _reading,
                            onPressed: _busy || _reading ? null : _pickFile)),
                  ]),
                  const SizedBox(height: 6),
                  const Text('قراءة الصور (OCR) تدعم الحروف اللاتينية فقط.',
                      style: TextStyle(fontSize: 12)),
                ]),
          ),
          const SizedBox(height: 14),
          NeoCard(
            padding: const EdgeInsets.all(16),
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('لغة النص',
                      style: TextStyle(fontWeight: FontWeight.w900)),
                  const SizedBox(height: 6),
                  InputDecorator(
                    decoration: const InputDecoration(
                        contentPadding:
                            EdgeInsets.symmetric(horizontal: 12, vertical: 2)),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        value: _lang,
                        isExpanded: true,
                        items: [
                          for (final l in kLangs)
                            DropdownMenuItem(
                                value: l.code,
                                child: Text('${l.flag}  ${l.name}')),
                        ],
                        onChanged:
                            _busy ? null : (v) => setState(() => _lang = v ?? _lang),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Wrap(spacing: 8, children: [
                    for (final e in _styles.entries)
                      ChoiceChip(
                        label: Text(e.value),
                        selected: _style == e.key,
                        onSelected:
                            _busy ? null : (_) => setState(() => _style = e.key),
                      ),
                  ]),
                  const SizedBox(height: 8),
                  Wrap(spacing: 8, children: [
                    ChoiceChip(
                      label: const Text('ملخص بالعربية'),
                      selected: _out == 'ar',
                      onSelected: _busy ? null : (_) => setState(() => _out = 'ar'),
                    ),
                    ChoiceChip(
                      label: const Text('بلغة النص (للتدرّب)'),
                      selected: _out == 'src',
                      onSelected:
                          _busy ? null : (_) => setState(() => _out = 'src'),
                    ),
                  ]),
                ]),
          ),
          const SizedBox(height: 14),
          NeoButton(
            label: 'لخّص النص',
            icon: Icons.auto_awesome,
            color: C.coral,
            busy: _busy,
            onPressed: _run,
          ),
          if (_error != null)
            Padding(
              padding: const EdgeInsets.only(top: 12),
              child: NeoCard(
                color: const Color(0xFFFFC9C0),
                child: Text(_error!,
                    style: const TextStyle(fontWeight: FontWeight.w800)),
              ),
            ),
          if (_sum != null && !_busy)
            SummaryResultView(
              key: ValueKey(_sum.hashCode),
              title: _shownTitle,
              subtitle: 'لغة النص: ${langOf(_shownLang).name}',
              langCode: _shownLang,
              summaryInSourceLang: _shownSrc,
              summary: _sum!.summary,
              points: _sum!.points,
              words: _sum!.words,
              chatContext: 'لخّصت نصاً. الملخص: ${_sum!.summary}',
            ),
          if (hist.isNotEmpty) ...[
            const SizedBox(height: 20),
            Text('آخر الملخصات', style: heading(22, color: dark ? Colors.white : C.ink)),
            const SizedBox(height: 8),
            for (final r in hist)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: NeoCard(
                  padding: const EdgeInsets.all(12),
                  onTap: () => _open(r),
                  child: Row(children: [
                    Text(switch (r.source) {
                      'youtube' => '📺',
                      'image' => '🖼️',
                      'file' => '📄',
                      _ => '📝',
                    }, style: const TextStyle(fontSize: 26)),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(r.title.isEmpty ? r.summary : r.title,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontWeight: FontWeight.w800)),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () {
                        app.removeSummary(r.id);
                        setState(() {});
                      },
                    ),
                  ]),
                ),
              ),
          ],
        ],
      ),
    );
  }
}
