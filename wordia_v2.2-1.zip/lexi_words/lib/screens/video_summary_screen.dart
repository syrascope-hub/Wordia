import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models.dart';
import '../services/ai_service.dart';
import '../services/youtube_service.dart';
import '../store.dart';
import '../theme.dart';
import 'summary_widgets.dart';

/// تلخيص فيديو يوتيوب من رابطه + استخراج كلمات للتعلّم.
class VideoSummaryScreen extends StatefulWidget {
  const VideoSummaryScreen({super.key});

  @override
  State<VideoSummaryScreen> createState() => _VideoSummaryScreenState();
}

class _VideoSummaryScreenState extends State<VideoSummaryScreen> {
  final _url = TextEditingController();
  String _style = 'points';
  bool _busy = false;
  String _stage = '';
  String? _error;

  YtTranscript? _tr;
  SummaryResult? _sum;

  static const _styles = {
    'short': 'قصير',
    'points': 'نقاط رئيسية',
    'detailed': 'مفصّل',
  };

  @override
  void dispose() {
    _url.dispose();
    super.dispose();
  }

  Future<void> _paste() async {
    final d = await Clipboard.getData(Clipboard.kTextPlain);
    final t = d?.text?.trim() ?? '';
    if (t.isEmpty) {
      if (mounted) toast(context, 'الحافظة فارغة');
      return;
    }
    setState(() => _url.text = t);
  }

  Future<void> _run() async {
    FocusScope.of(context).unfocus();
    if (YoutubeService.extractId(_url.text) == null) {
      setState(() => _error = 'الرابط غير صحيح. الصق رابط فيديو يوتيوب.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
      _stage = 'جاري جلب نص الفيديو…';
      _sum = null;
      _tr = null;
    });
    try {
      final tr = await youtube.fetch(_url.text, preferLang: app.s.defaultLang);
      if (!mounted) return;
      setState(() => _stage = 'جاري التلخيص بالذكاء الاصطناعي…');
      final sum = await ai.summarizeVideo(
          tr.text, tr.langCode, _style, tr.title, app.s);
      if (!mounted) return;
      setState(() {
        _tr = tr;
        _sum = sum;
      });
      app.addSummary(recFrom(sum,
          title: tr.title.isEmpty ? 'فيديو يوتيوب' : tr.title,
          lang: tr.langCode,
          source: 'youtube'));
    } on YtException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } catch (_) {
      if (mounted) {
        setState(() =>
            _error = 'تعذّر إكمال التلخيص. تحقق من الإنترنت وأعد المحاولة.');
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final dark = isDark(context);
    return Scaffold(
      backgroundColor: dark ? C.darkBg : C.pink,
      appBar: AppBar(title: const Text('تلخيص يوتيوب')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
        children: [
          NeoCard(
            color: C.coral,
            padding: const EdgeInsets.all(16),
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('رابط الفيديو', style: heading(22, color: C.ink)),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _url,
                    enabled: !_busy,
                    keyboardType: TextInputType.url,
                    textDirection: TextDirection.ltr,
                    autocorrect: false,
                    enableSuggestions: false,
                    style: const TextStyle(color: C.ink),
                    decoration: InputDecoration(
                      hintText: 'https://youtu.be/…',
                      suffixIcon: IconButton(
                        tooltip: 'لصق',
                        icon: const Icon(Icons.content_paste, color: C.ink),
                        onPressed: _busy ? null : _paste,
                      ),
                    ),
                    onSubmitted: (_) => _busy ? null : _run(),
                  ),
                  const SizedBox(height: 12),
                  Wrap(spacing: 8, children: [
                    for (final e in _styles.entries)
                      ChoiceChip(
                        label: Text(e.value),
                        selected: _style == e.key,
                        onSelected:
                            _busy ? null : (_) => setState(() => _style = e.key),
                      ),
                  ]),
                ]),
          ),
          const SizedBox(height: 14),
          NeoButton(
            label: _busy ? _stage : 'لخّص الفيديو',
            icon: Icons.smart_display,
            color: C.yellow,
            busy: _busy,
            onPressed: _run,
          ),
          if (_error != null)
            Padding(
              padding: const EdgeInsets.only(top: 12),
              child: NeoCard(
                color: const Color(0xFFFFC9C0),
                child: Text(_error!,
                    style: const TextStyle(fontWeight: FontWeight.w800)),
              ),
            ),
          if (_sum != null && _tr != null && !_busy)
            SummaryResultView(
              key: ValueKey(_tr!.videoId + _style),
              title: _tr!.title,
              subtitle:
                  '${_tr!.author.isEmpty ? '' : '${_tr!.author} • '}لغة النص: ${kLangs.any((l) => l.code == _tr!.langCode) ? langOf(_tr!.langCode).name : _tr!.langCode}${_tr!.autoGenerated ? ' • ترجمة تلقائية (قد تحتوي أخطاء)' : ''}',
              langCode: _tr!.langCode,
              summary: _sum!.summary,
              points: _sum!.points,
              words: _sum!.words,
              chatContext:
                  'لخّصت فيديو "${_tr!.title}". الملخص: ${_sum!.summary}',
            ),
          if (_sum == null && !_busy && _error == null)
            const Padding(
              padding: EdgeInsets.only(top: 16),
              child: Text(
                'يعمل مع الفيديوهات التي فيها ترجمة أو تسميات توضيحية (تلقائية أو يدوية). '
                'الفيديوهات الطويلة تُلخَّص على أجزاء وقد تستغرق وقتاً أطول.',
                style: TextStyle(height: 1.6),
              ),
            ),
        ],
      ),
    );
  }
}
