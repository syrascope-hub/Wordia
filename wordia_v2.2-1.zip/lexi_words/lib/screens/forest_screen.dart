import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';
import '../theme.dart';
import 'tree_painter.dart';

DateTime _day(int ts) {
  final d = DateTime.fromMillisecondsSinceEpoch(ts);
  return DateTime(d.year, d.month, d.day);
}

/// غابتك: كل أشجارك (الحية والذابلة) مع إحصاءات وتقويم لأيام التركيز.
class ForestScreen extends StatelessWidget {
  const ForestScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final dark = isDark(context);
    final fg = dark ? Colors.white : C.ink;
    final trees = app.forest;
    final alive = trees.where((t) => t.alive).toList();
    final totalMin = alive.fold<int>(0, (a, t) => a + t.minutes);
    final today = DateTime.now();
    final todayD = DateTime(today.year, today.month, today.day);
    final byDay = <DateTime, int>{};
    for (final t in alive) {
      final d = _day(t.ts);
      byDay[d] = (byDay[d] ?? 0) + t.minutes;
    }
    final todayMin = byDay[todayD] ?? 0;
    final days = [
      for (var i = 34; i >= 0; i--) todayD.subtract(Duration(days: i))
    ];
    Color cell(int m) {
      if (m == 0) return dark ? Colors.white12 : const Color(0xFFE9E4D8);
      if (m < 30) return const Color(0xFFBFE9D3);
      if (m < 60) return const Color(0xFF7ED9A8);
      return const Color(0xFF3AA37C);
    }

    return Scaffold(
      backgroundColor: dark ? C.darkBg : C.mint,
      appBar: AppBar(title: const Text('غابتي')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
        children: [
          Row(children: [
            _stat('🌳', '${alive.length}', 'أشجار حيّة', C.yellow),
            const SizedBox(width: 10),
            _stat('⏱️', '$totalMin', 'دقيقة تركيز', C.pink),
            const SizedBox(width: 10),
            _stat('📅', '$todayMin', 'دقيقة اليوم', C.blue),
          ]),
          const SizedBox(height: 16),
          NeoCard(
            padding: const EdgeInsets.all(14),
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('أيام التركيز', style: heading(20, color: fg)),
                  const SizedBox(height: 10),
                  Directionality(
                    textDirection: TextDirection.ltr,
                    child: Wrap(spacing: 6, runSpacing: 6, children: [
                      for (final d in days)
                        Tooltip(
                          message: '${d.day}/${d.month}: ${byDay[d] ?? 0} د',
                          child: Container(
                            width: 30,
                            height: 30,
                            decoration: BoxDecoration(
                              color: cell(byDay[d] ?? 0),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                  color: d == todayD ? C.coral : fg.withValues(alpha: 0.35),
                                  width: d == todayD ? 2.5 : 1.2),
                            ),
                          ),
                        ),
                    ]),
                  ),
                ]),
          ),
          const SizedBox(height: 16),
          NeoCard(
            color: const Color(0xFFD7F5EE),
            padding: const EdgeInsets.all(14),
            child: trees.isEmpty
                ? const Padding(
                    padding: EdgeInsets.all(24),
                    child: Center(
                        child: Text('غابتك فارغة. ابدأ جلسة تركيز لتزرع أول شجرة 🌱',
                            textAlign: TextAlign.center,
                            style: TextStyle(fontWeight: FontWeight.w800))),
                  )
                : Wrap(spacing: 4, runSpacing: 8, children: [
                    for (final t in trees.take(150))
                      Tooltip(
                        message: '${t.minutes} د${t.alive ? '' : ' (ذبلت)'}',
                        child: TreeView(
                            kindId: t.kind, dead: !t.alive, size: 62),
                      ),
                  ]),
          ),
        ],
      ),
    );
  }

  Widget _stat(String e, String v, String l, Color c) => Expanded(
        child: NeoCard(
          color: c,
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 6),
          child: Column(children: [
            Text(e, style: const TextStyle(fontSize: 24)),
            Text(v, style: heading(26, color: C.ink)),
            Text(l,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800)),
          ]),
        ),
      );
}

/// متجر الأشجار: تشتري أنواعاً جديدة بالعملات التي تكسبها من التركيز.
class ShopScreen extends StatefulWidget {
  const ShopScreen({super.key});

  @override
  State<ShopScreen> createState() => _ShopScreenState();
}

class _ShopScreenState extends State<ShopScreen> {
  @override
  Widget build(BuildContext context) {
    final dark = isDark(context);
    return Scaffold(
      backgroundColor: dark ? C.darkBg : C.yellow,
      appBar: AppBar(
        title: const Text('المتجر'),
        actions: [
          Center(
              child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Text('🪙 ${app.coins}',
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    color: dark ? Colors.white : C.ink)),
          )),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
        children: [
          for (final k in kTrees)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: NeoCard(
                color: const Color(0xFFD7F5EE),
                padding: const EdgeInsets.all(12),
                child: Row(children: [
                  TreeView(kindId: k.id, size: 78),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(k.name, style: heading(24, color: C.ink)),
                  ),
                  SizedBox(
                    width: 120,
                    child: _action(k),
                  ),
                ]),
              ),
            ),
        ],
      ),
    );
  }

  Widget _action(TreeKind k) {
    final owned = app.ownedTrees.contains(k.id);
    if (owned) {
      final sel = app.selectedTree == k.id;
      return NeoButton(
        label: sel ? 'مُستخدمة' : 'استخدم',
        color: sel ? C.mint : C.blue,
        onPressed: sel
            ? null
            : () {
                app.selectedTree = k.id;
                app.saveForest();
                setState(() {});
              },
      );
    }
    final can = app.coins >= k.price;
    return NeoButton(
      label: '🪙 ${k.price}',
      color: C.yellow,
      onPressed: can
          ? () {
              app.buyTree(k.id, k.price);
              toast(context, 'اشتريت شجرة ${k.name}');
              setState(() {});
            }
          : null,
    );
  }
}
