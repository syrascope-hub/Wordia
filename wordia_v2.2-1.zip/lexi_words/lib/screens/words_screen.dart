import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';
import '../theme.dart';
import 'add_word_sheet.dart';
import 'settings_screen.dart';
import 'stats_screen.dart';
import 'word_detail.dart';

const List<List<String>> kSample = [
  ['apple', 'تفاحة'],
  ['book', 'كتاب'],
  ['water', 'ماء'],
  ['house', 'منزل'],
  ['friend', 'صديق'],
  ['dog', 'كلب'],
  ['park', 'حديقة'],
  ['school', 'مدرسة'],
  ['happy', 'سعيد'],
  ['quickly', 'بسرعة'],
  ['beautiful', 'جميل'],
  ['learn', 'يتعلّم'],
];

class WordsScreen extends StatefulWidget {
  const WordsScreen({super.key});

  @override
  State<WordsScreen> createState() => _WordsScreenState();
}

class _WordsScreenState extends State<WordsScreen> {
  final _search = TextEditingController();
  int _filter = 0; // 0 الكل، 1 المفضلة، 2 اليومية

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  List<Word> _visible() {
    final q = _search.text.trim().toLowerCase();
    return app.words.where((w) {
      if (_filter == 1 && !w.favorite) return false;
      if (_filter == 2 && !w.daily) return false;
      if (q.isEmpty) return true;
      return w.word.toLowerCase().contains(q) ||
          w.translation.toLowerCase().contains(q);
    }).toList();
  }

  void _menu(Word w) {
    showModalBottomSheet(
      context: context,
      builder: (c) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            leading: const Icon(Icons.edit),
            title: const Text('تعديل'),
            onTap: () {
              Navigator.pop(c);
              showAddWordSheet(context, edit: w);
            },
          ),
          ListTile(
            leading: const Icon(Icons.delete_outline),
            title: const Text('حذف'),
            onTap: () async {
              Navigator.pop(c);
              if (await confirm(context, 'حذف الكلمة', 'حذف "${w.word}"؟',
                  ok: 'حذف')) {
                app.removeWord(w);
              }
            },
          ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final list = _visible();
        final dailyCount = app.words.where((w) => w.daily).length;
        return Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            title: const Text('كلماتي'),
            actions: [
              if (app.streak > 0)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: Chip(label: Text('🔥 ${app.streak}')),
                ),
              IconButton(
                tooltip: 'الإعدادات',
                icon: const Icon(Icons.settings_outlined),
                onPressed: () => openSettings(context),
              ),
              IconButton(
                tooltip: 'إحصائياتي',
                icon: const Icon(Icons.bar_chart_rounded),
                onPressed: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const StatsScreen())),
              ),
              PopupMenuButton<String>(
                onSelected: (v) {
                  if (v == 'all') app.setDailyFor(app.words, true);
                  if (v == 'none') app.setDailyFor(app.words, false);
                  if (v == 'shown') {
                    app.setDailyFor(app.words, false);
                    app.setDailyFor(list, true);
                  }
                },
                itemBuilder: (c) => const [
                  PopupMenuItem(
                      value: 'all', child: Text('تحديد الكل للإرسال اليومي')),
                  PopupMenuItem(
                      value: 'shown',
                      child: Text('تحديد المعروضة فقط للإرسال اليومي')),
                  PopupMenuItem(value: 'none', child: Text('إلغاء تحديد الكل')),
                ],
              ),
            ],
          ),
          floatingActionButton: FloatingActionButton.extended(
            backgroundColor: C.coral,
            foregroundColor: C.ink,
            onPressed: () => showAddWordSheet(context),
            icon: const Icon(Icons.add),
            label: const Text('إضافة',
                style: TextStyle(fontWeight: FontWeight.w900)),
          ),
          body: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
                child: TextField(
                  controller: _search,
                  onChanged: (_) => setState(() {}),
                  decoration: InputDecoration(
                    hintText: 'ابحث عن كلمة أو ترجمة…',
                    prefixIcon: const Icon(Icons.search),
                    isDense: true,
                    suffixIcon: _search.text.isEmpty
                        ? null
                        : IconButton(
                            icon: const Icon(Icons.close),
                            onPressed: () => setState(_search.clear)),
                  ),
                ),
              ),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(children: [
                  for (final e in [
                    'الكل (${app.words.length})',
                    'المفضلة',
                    'اليومية ($dailyCount)',
                  ].asMap().entries)
                    Padding(
                      padding: const EdgeInsetsDirectional.only(end: 8),
                      child: ChoiceChip(
                        label: Text(e.value),
                        selected: _filter == e.key,
                        onSelected: (_) => setState(() => _filter = e.key),
                      ),
                    ),
                ]),
              ),
              const SizedBox(height: 8),
              Expanded(
                child: list.isEmpty ? _empty() : _listView(list),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _empty() {
    if (app.words.isNotEmpty) {
      return const Center(child: Text('لا توجد نتائج'));
    }
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('📚', style: TextStyle(fontSize: 64)),
          const SizedBox(height: 12),
          const Text('ابدأ بإضافة أول كلماتك',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
          const SizedBox(height: 16),
          NeoButton(
            label: 'إضافة كلمة',
            icon: Icons.add,
            onPressed: () => showAddWordSheet(context),
          ),
          const SizedBox(height: 12),
          NeoButton(
            label: 'إضافة 12 كلمة تجريبية',
            icon: Icons.auto_awesome,
            color: C.mint,
            onPressed: () {
              final text = kSample.map((p) => '${p[0]}, ${p[1]}').join('\n');
              app.addBulk(text, 'en');
            },
          ),
        ]),
      ),
    );
  }

  Widget _listView(List<Word> list) {
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 96),
      itemCount: list.length,
      itemBuilder: (c, i) {
        final w = list[i];
        final l = w.language;
        return NeoCard(
          margin: const EdgeInsets.only(bottom: 14),
          padding: const EdgeInsets.fromLTRB(14, 10, 8, 10),
          onTap: () => Navigator.push(
              context, MaterialPageRoute(builder: (_) => WordDetail(word: w))),
          onLongPress: () => _menu(w),
          child: Row(children: [
            Text(l.flag, style: const TextStyle(fontSize: 26)),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(w.word,
                      textDirection: langDir(l),
                      style: const TextStyle(
                          fontSize: 20, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 2),
                  Text(w.translation,
                      style: TextStyle(
                          fontSize: 14,
                          color: isDark(context)
                              ? Colors.white70
                              : Colors.black54)),
                ],
              ),
            ),
            IconButton(
              tooltip: 'إرسالها يومياً',
              icon: Icon(
                  w.daily
                      ? Icons.notifications_active
                      : Icons.notifications_none,
                  color: w.daily ? C.coral : null),
              onPressed: () => app.setDaily(w, !w.daily),
            ),
            SpeakButton(text: w.word, lang: l, size: 40),
          ]),
        );
      },
    );
  }
}
