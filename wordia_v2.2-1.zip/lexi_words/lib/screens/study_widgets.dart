import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';

import '../services/ai_service.dart';
import '../services/ocr_service.dart';
import '../store.dart';
import '../theme.dart';
import 'settings_screen.dart';

/// أزرار إدخال النص: لصق، كاميرا، صورة، ملف txt.
/// تعيد النص المقروء عبر [onText] (والمستدعي يقرّر هل يستبدل أو يضيف).
class SourceBar extends StatefulWidget {
  final ValueChanged<String> onText;
  final bool disabled;
  const SourceBar({super.key, required this.onText, this.disabled = false});

  @override
  State<SourceBar> createState() => _SourceBarState();
}

class _SourceBarState extends State<SourceBar> {
  final _picker = ImagePicker();
  bool _reading = false;

  bool get _off => widget.disabled || _reading;

  Future<void> _paste() async {
    final d = await Clipboard.getData(Clipboard.kTextPlain);
    final t = d?.text ?? '';
    if (!mounted) return;
    if (t.trim().isEmpty) {
      toast(context, 'الحافظة فارغة');
      return;
    }
    widget.onText(t.trim());
  }

  Future<void> _pickFile() async {
    setState(() => _reading = true);
    try {
      final res = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: const ['txt'],
        withData: true,
      );
      if (res == null || res.files.isEmpty) return;
      final f = res.files.first;
      final bytes = f.bytes ?? await File(f.path!).readAsBytes();
      final t = utf8.decode(bytes, allowMalformed: true).trim();
      if (mounted && t.isNotEmpty) widget.onText(t);
    } catch (_) {
      if (mounted) toast(context, 'تعذّر قراءة الملف');
    } finally {
      if (mounted) setState(() => _reading = false);
    }
  }

  /// صورة ← نص: أولاً بنموذج رؤية (يدعم العربية والمعادلات)، ثم OCR محلي احتياطي.
  Future<void> _fromImage(bool camera) async {
    setState(() => _reading = true);
    try {
      final x = await _picker.pickImage(
        source: camera ? ImageSource.camera : ImageSource.gallery,
        maxWidth: 1800,
        imageQuality: 85,
      );
      if (x == null) return;
      var t = '';
      try {
        t = await ai.imageToText(await x.readAsBytes(), app.s);
      } catch (_) {}
      if (t.trim().length < 15) {
        try {
          t = await ocr.readFile(x.path);
        } catch (_) {}
      }
      if (!mounted) return;
      if (t.trim().isEmpty) {
        toast(context, 'لم أستطع قراءة نص من الصورة');
        return;
      }
      widget.onText(t.trim());
    } catch (_) {
      if (mounted) toast(context, 'تعذّر فتح الصورة');
    } finally {
      if (mounted) setState(() => _reading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Expanded(
            child: NeoButton(
                label: 'لصق',
                icon: Icons.content_paste,
                color: C.blue,
                onPressed: _off ? null : _paste)),
        const SizedBox(width: 8),
        Expanded(
            child: NeoButton(
                label: 'كاميرا',
                icon: Icons.photo_camera,
                color: C.pink,
                busy: _reading,
                onPressed: _off ? null : () => _fromImage(true))),
      ]),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(
            child: NeoButton(
                label: 'صورة',
                icon: Icons.image,
                color: C.pink,
                onPressed: _off ? null : () => _fromImage(false))),
        const SizedBox(width: 8),
        Expanded(
            child: NeoButton(
                label: 'ملف txt',
                icon: Icons.description,
                color: C.mint,
                onPressed: _off ? null : _pickFile)),
      ]),
      const SizedBox(height: 6),
      const Text(
          'الصور تُقرأ بالذكاء الاصطناعي (تدعم العربية والمعادلات) '
          'وإن تعذّر فبقارئ محلي للحروف اللاتينية.',
          style: TextStyle(fontSize: 12)),
    ]);
  }
}

/// شريط يظهر فقط عندما لا يوجد مفتاح ذكاء اصطناعي، ويفتح الإعدادات.
class AiKeyBanner extends StatelessWidget {
  const AiKeyBanner({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) => AnimatedSize(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
        alignment: Alignment.topCenter,
        child: ai.hasKey(app.s)
            ? const SizedBox(width: double.infinity)
            : Padding(
                padding: const EdgeInsets.only(bottom: 14),
                child: NeoCard(
                  color: C.yellow,
                  onTap: () => openSettings(context),
                  child: Row(children: [
                    const Text('🔑', style: TextStyle(fontSize: 28)),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('لم تضف مفتاح الذكاء الاصطناعي بعد',
                              style: TextStyle(fontWeight: FontWeight.w900)),
                          SizedBox(height: 2),
                          Text(
                              'يعمل التطبيق الآن بمزوّد مجاني احتياطي. '
                              'أضف مفتاحك من الإعدادات لجودة وسرعة أفضل.',
                              style: TextStyle(fontSize: 12.5, height: 1.4)),
                        ],
                      ),
                    ),
                    const Icon(Icons.chevron_left),
                  ]),
                ),
              ),
      ),
    );
  }
}
