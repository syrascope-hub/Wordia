import 'dart:math';

import 'package:flutter/material.dart';

enum TreeShape { round, cone, palm, cactus }

class TreeKind {
  final String id;
  final String name;
  final int price;
  final TreeShape shape;
  final Color c1;
  final Color c2;
  final Color trunk;
  const TreeKind(this.id, this.name, this.price, this.shape, this.c1, this.c2,
      this.trunk);
}

/// أنواع الأشجار (رسم أصلي بالكود بألوان باستيل).
const List<TreeKind> kTrees = [
  TreeKind('oak', 'سنديان', 0, TreeShape.round, Color(0xFF7ED9A8),
      Color(0xFF4FB985), Color(0xFFB07A4F)),
  TreeKind('pine', 'صنوبر', 40, TreeShape.cone, Color(0xFF5CC49A),
      Color(0xFF3AA37C), Color(0xFF9A6A44)),
  TreeKind('cherry', 'كرز', 80, TreeShape.round, Color(0xFFFF8FB8),
      Color(0xFFFF6FA0), Color(0xFF9A6A44)),
  TreeKind('palm', 'نخيل', 120, TreeShape.palm, Color(0xFF6FD08C),
      Color(0xFF45B36A), Color(0xFFC49A62)),
  TreeKind('cactus', 'صبار', 120, TreeShape.cactus, Color(0xFF8ED9A0),
      Color(0xFF5BBF7D), Color(0xFF5BBF7D)),
  TreeKind('maple', 'قيقب', 160, TreeShape.round, Color(0xFFFF7A59),
      Color(0xFFE85E3D), Color(0xFF9A6A44)),
  TreeKind('mimosa', 'ميموزا', 200, TreeShape.round, Color(0xFFFFE08A),
      Color(0xFFFFCB4D), Color(0xFFB07A4F)),
  TreeKind('frost', 'صنوبر الجليد', 240, TreeShape.cone, Color(0xFF9CC8FA),
      Color(0xFF6FA8F5), Color(0xFF8A7A6A)),
];

TreeKind treeKind(String id) =>
    kTrees.firstWhere((k) => k.id == id, orElse: () => kTrees.first);

const _ink = Color(0xFF1A1A1A);
const _deadLeaf = Color(0xFFC9B79A);
const _deadTrunk = Color(0xFF8A7458);

/// يرسم شجرة تنمو بحسب [progress] من 0 إلى 1 (بذرة ← نبتة ← شجيرة ← شجرة).
/// عند [dead] تُرسم ذابلة.
class TreePainter extends CustomPainter {
  final TreeKind kind;
  final double progress;
  final bool dead;
  TreePainter(this.kind, this.progress, {this.dead = false});

  Paint _fill(Color c) => Paint()..color = c;
  Paint _line(double w) => Paint()
    ..color = _ink
    ..style = PaintingStyle.stroke
    ..strokeWidth = w
    ..strokeJoin = StrokeJoin.round
    ..strokeCap = StrokeCap.round;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    final sw = max(2.0, w * 0.018);
    final gy = h * 0.88;
    final cx = w / 2;
    final p = progress.clamp(0.0, 1.0);

    // التربة
    final mound = Rect.fromCenter(
        center: Offset(cx, gy), width: w * 0.62, height: h * 0.14);
    canvas.drawOval(mound, _fill(const Color(0xFFC89B6D)));
    canvas.drawOval(mound, _line(sw));

    final c1 = dead ? _deadLeaf : kind.c1;
    final c2 = dead ? _deadLeaf : kind.c2;
    final trunkC = dead ? _deadTrunk : kind.trunk;

    // مرحلة البذرة
    if (p < 0.12 && !dead) {
      final r = w * 0.035;
      canvas.drawOval(Rect.fromCenter(center: Offset(cx, gy - r), width: r * 2.2, height: r * 1.6),
          _fill(const Color(0xFF8A5A33)));
      return;
    }

    // مرحلة النبتة
    if (p < 0.4 && !dead) {
      final k = (p - 0.12) / 0.28;
      final stem = h * (0.08 + 0.14 * k);
      canvas.drawLine(Offset(cx, gy), Offset(cx, gy - stem), _line(sw * 2.4));
      canvas.drawLine(Offset(cx, gy), Offset(cx, gy - stem), _fill(c2).toStroke(sw * 1.2));
      final leaf = w * (0.07 + 0.05 * k);
      for (final s in [-1, 1]) {
        final path = Path()
          ..moveTo(cx, gy - stem)
          ..quadraticBezierTo(cx + s * leaf * 1.6, gy - stem - leaf * 1.4,
              cx + s * leaf * 2.2, gy - stem - leaf * 0.3)
          ..quadraticBezierTo(cx + s * leaf * 1.2, gy - stem + leaf * 0.2, cx, gy - stem);
        canvas.drawPath(path, _fill(c1));
        canvas.drawPath(path, _line(sw));
      }
      return;
    }

    // شجيرة ثم شجرة: مقياس النمو 0.35..1
    final g = dead ? 1.0 : (0.35 + 0.65 * ((p - 0.4) / 0.6)).clamp(0.35, 1.0);
    switch (kind.shape) {
      case TreeShape.round:
        _round(canvas, w, h, cx, gy, g, c1, c2, trunkC, sw);
      case TreeShape.cone:
        _cone(canvas, w, h, cx, gy, g, c1, c2, trunkC, sw);
      case TreeShape.palm:
        _palm(canvas, w, h, cx, gy, g, c1, c2, trunkC, sw);
      case TreeShape.cactus:
        _cactus(canvas, w, h, cx, gy, g, c1, c2, sw);
    }
  }

  void _trunk(Canvas c, double cx, double gy, double tw, double th, Color col, double sw) {
    final r = RRect.fromRectAndRadius(
        Rect.fromLTWH(cx - tw / 2, gy - th, tw, th + 2), Radius.circular(tw / 3));
    c.drawRRect(r, _fill(col));
    c.drawRRect(r, _line(sw));
  }

  void _blob(Canvas c, Offset o, double r, Color fill, double sw) {
    c.drawCircle(o, r, _fill(fill));
    c.drawCircle(o, r, _line(sw));
  }

  void _round(Canvas c, double w, double h, double cx, double gy, double g,
      Color c1, Color c2, Color tr, double sw) {
    final th = h * 0.34 * g;
    _trunk(c, cx, gy, w * 0.11 * (0.6 + 0.4 * g), th, tr, sw);
    final top = gy - th;
    final r = w * 0.2 * g;
    if (dead) {
      final br = _line(sw * 1.6);
      c.drawLine(Offset(cx, top), Offset(cx - r * 1.1, top - r * 1.1), br);
      c.drawLine(Offset(cx, top), Offset(cx + r * 1.1, top - r * 1.3), br);
      c.drawLine(Offset(cx, top + th * 0.3), Offset(cx + r * 0.9, top - r * 0.1), br);
      return;
    }
    _blob(c, Offset(cx - r * 0.85, top - r * 0.2), r * 0.95, c2, sw);
    _blob(c, Offset(cx + r * 0.85, top - r * 0.2), r * 0.95, c2, sw);
    _blob(c, Offset(cx, top - r * 0.9), r * 1.15, c1, sw);
  }

  void _cone(Canvas c, double w, double h, double cx, double gy, double g,
      Color c1, Color c2, Color tr, double sw) {
    final th = h * 0.16 * g;
    _trunk(c, cx, gy, w * 0.1 * (0.6 + 0.4 * g), th, tr, sw);
    final tw = w * 0.5 * g;
    final layerH = h * 0.26 * g;
    var y = gy - th + layerH * 0.25;
    for (var i = 0; i < 3; i++) {
      final k = 1 - i * 0.22;
      final path = Path()
        ..moveTo(cx, y - layerH * 1.05)
        ..lineTo(cx + tw * k / 2, y)
        ..lineTo(cx - tw * k / 2, y)
        ..close();
      c.drawPath(path, _fill(i.isEven ? c1 : c2));
      c.drawPath(path, _line(sw));
      y -= layerH * 0.62;
    }
  }

  void _palm(Canvas c, double w, double h, double cx, double gy, double g,
      Color c1, Color c2, Color tr, double sw) {
    final th = h * 0.5 * g;
    final topX = cx + w * 0.08 * g;
    final topY = gy - th;
    final path = Path()
      ..moveTo(cx - w * 0.04, gy)
      ..quadraticBezierTo(cx - w * 0.02, gy - th * 0.55, topX - w * 0.03, topY)
      ..lineTo(topX + w * 0.03, topY)
      ..quadraticBezierTo(cx + w * 0.06, gy - th * 0.55, cx + w * 0.05, gy)
      ..close();
    c.drawPath(path, _fill(tr));
    c.drawPath(path, _line(sw));
    final len = w * 0.3 * g;
    final angles = dead ? [-2.6, -2.0, -1.1, -0.5] : [-2.9, -2.3, -1.57, -0.85, -0.25];
    for (var i = 0; i < angles.length; i++) {
      c.save();
      c.translate(topX, topY);
      c.rotate(angles[i]);
      final leaf = Path()
        ..moveTo(0, 0)
        ..quadraticBezierTo(len * 0.5, -len * 0.3, len, dead ? len * 0.35 : 0)
        ..quadraticBezierTo(len * 0.5, len * 0.12, 0, 0);
      c.drawPath(leaf, _fill(i.isEven ? c1 : c2));
      c.drawPath(leaf, _line(sw));
      c.restore();
    }
    if (!dead) _blob(c, Offset(topX, topY), w * 0.03, const Color(0xFF9A6A44), sw);
  }

  void _cactus(Canvas c, double w, double h, double cx, double gy, double g,
      Color c1, Color c2, double sw) {
    final bh = h * 0.5 * g;
    final bw = w * 0.2 * (0.7 + 0.3 * g);
    final body = RRect.fromRectAndRadius(
        Rect.fromLTWH(cx - bw / 2, gy - bh, bw, bh + 2), Radius.circular(bw / 2));
    final armW = bw * 0.55;
    void arm(int s, double hh) {
      final ax = cx + s * (bw / 2 + armW * 0.35);
      final r = RRect.fromRectAndRadius(
          Rect.fromLTWH(ax - armW / 2, gy - bh * hh - bh * 0.28, armW, bh * 0.3),
          Radius.circular(armW / 2));
      c.drawRRect(r, _fill(c2));
      c.drawRRect(r, _line(sw));
    }

    if (g > 0.6) {
      arm(-1, 0.55);
      arm(1, 0.7);
    }
    c.drawRRect(body, _fill(c1));
    c.drawRRect(body, _line(sw));
    if (!dead && g > 0.9) {
      _blob(c, Offset(cx, gy - bh - bw * 0.05), bw * 0.22, const Color(0xFFFF8FB8), sw);
    }
  }

  @override
  bool shouldRepaint(TreePainter o) =>
      o.progress != progress || o.dead != dead || o.kind.id != kind.id;
}

extension on Paint {
  Paint toStroke(double w) => Paint()
    ..color = color
    ..style = PaintingStyle.stroke
    ..strokeWidth = w
    ..strokeCap = StrokeCap.round;
}

class TreeView extends StatelessWidget {
  final String kindId;
  final double progress;
  final bool dead;
  final double size;
  const TreeView(
      {super.key,
      required this.kindId,
      this.progress = 1,
      this.dead = false,
      this.size = 80});

  @override
  Widget build(BuildContext context) => SizedBox(
        width: size,
        height: size,
        child: CustomPaint(
            painter: TreePainter(treeKind(kindId), progress, dead: dead)),
      );
}
