import 'package:flutter/material.dart';

import '../models.dart';
import '../services/ai_service.dart';
import '../store.dart';
import '../theme.dart';
import 'add_word_sheet.dart';

class WordDetail extends StatefulWidget {
  final Word word;
  const WordDetail({super.key, required this.word});

  @override
  State<WordDetail> createState() => _WordDetailState();
}

class _WordDetailState extends State<WordDetail> {
  bool _loading = false;
  String? _error;

  Word get w => widget.word;

  @override
  void initState() {
    super.initState();
    if (w.examples.isEmpty && app.s.autoExamples) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _generate());
    }
  }

  Future<void> _generate() async {
    if (_loading) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final list = await ai.examples(w, app.s);
      w.examples = list;
      app.updateWord(w);
    } catch (e) {
      _error = 'تعذّر توليد الأمثلة. تحقق من الإنترنت وأعد المحاولة.';
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _askAi() {
    app.chatPrefill =
        'اشرح لي الكلمة "${w.word}" (${w.translation}) مع فروقها واستخداماتها الشائعة.';
    app.tab.value = kTabChat;
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final l = w.language;
        final base = TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.w800,
          height: 1.4,
          color: isDark(context) ? Colors.white : C.ink,
        );
        return Scaffold(
          appBar: AppBar(
            actions: [
              IconButton(
                icon: Icon(w.favorite ? Icons.star : Icons.star_border,
                    color: w.favorite ? C.coral : null),
                onPressed: () => app.toggleFavorite(w),
              ),
              IconButton(
                icon: const Icon(Icons.edit),
                onPressed: () => showAddWordSheet(context, edit: w),
              ),
              IconButton(
                icon: const Icon(Icons.delete_outline),
                onPressed: () async {
                  if (await confirm(context, 'حذف الكلمة', 'حذف "${w.word}"؟',
                      ok: 'حذف')) {
                    app.removeWord(w);
                    if (context.mounted) Navigator.pop(context);
                  }
                },
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 32),
            children: [
              NeoCard(
                color: C.pink,
                padding: const EdgeInsets.all(20),
                child: Column(children: [
                  Text('${l.flag}  ${l.name}',
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 10),
                  Text(w.word,
                      textAlign: TextAlign.center,
                      textDirection: langDir(l),
                      style: heading(48, color: C.ink)),
                  if (w.note.isNotEmpty) ...[
                    const SizedBox(height: 4),
                    Text(w.note,
                        style: const TextStyle(fontWeight: FontWeight.w600)),
                  ],
                  const SizedBox(height: 14),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Waveform(color: C.coral),
                      const SizedBox(width: 6),
                      SpeakButton(text: w.word, lang: l, size: 72),
                      const SizedBox(width: 6),
                      const Waveform(mirrored: true, color: C.coral),
                    ],
                  ),
                ]),
              ),
              const SizedBox(height: 16),
              NeoCard(
                color: C.mint,
                padding: const EdgeInsets.all(18),
                child: Center(
                  child: Text(w.translation,
                      textAlign: TextAlign.center,
                      style: heading(30, color: C.ink)),
                ),
              ),
              const SizedBox(height: 12),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                value: w.daily,
                onChanged: (v) => app.setDaily(w, v),
                title: const Text('إرسالها كإشعار يومي'),
              ),
              if (w.note.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: Text('${l.flag} ${w.word} • ${w.note}',
                      style: const TextStyle(fontWeight: FontWeight.w800)),
                ),
              Text('✓ ${w.correct}   ✗ ${w.wrong}   • المستوى ${w.box + 1}/5',
                  style: TextStyle(
                      color: isDark(context) ? Colors.white60 : Colors.black54)),
              const SizedBox(height: 20),
              Row(children: [
                const Expanded(
                  child: Text('أمثلة في سياق', style: TextStyle(fontSize: 26, fontFamily: 'LilitaOne', fontFamilyFallback: ['Lalezar'])),
                ),
                SizedBox(
                  width: 190,
                  child: NeoButton(
                    label: w.examples.isEmpty
                        ? 'توليد بالذكاء الاصطناعي'
                        : 'أمثلة جديدة',
                    icon: Icons.auto_awesome,
                    color: C.yellow,
                    busy: _loading,
                    onPressed: _generate,
                  ),
                ),
              ]),
              const SizedBox(height: 12),
              if (_error != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Text(_error!,
                      style: const TextStyle(color: Colors.redAccent)),
                ),
              if (_loading && w.examples.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(24),
                  child: Center(child: Text('…يكتب الذكاء الاصطناعي أمثلة')),
                ),
              for (final ex in w.examples)
                NeoCard(
                  margin: const EdgeInsets.only(bottom: 14),
                  child: Row(children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Directionality(
                            textDirection: langDir(l),
                            child: Text.rich(TextSpan(
                                children: highlightSpans(ex.text, w.word,
                                    base.copyWith(fontSize: 24)))),
                          ),
                          if (ex.translation.isNotEmpty) ...[
                            const SizedBox(height: 6),
                            Text(ex.translation,
                                style: TextStyle(
                                    fontSize: 15,
                                    color: isDark(context)
                                        ? Colors.white70
                                        : Colors.black54)),
                          ],
                        ],
                      ),
                    ),
                    const SizedBox(width: 10),
                    SpeakButton(text: ex.text, lang: l, size: 42),
                  ]),
                ),
              const SizedBox(height: 8),
              NeoButton(
                label: 'اسأل الذكاء الاصطناعي عن هذه الكلمة',
                icon: Icons.chat_bubble_outline,
                color: C.blue,
                onPressed: _askAi,
              ),
            ],
          ),
        );
      },
    );
  }
}
