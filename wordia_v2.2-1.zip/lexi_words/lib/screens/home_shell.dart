import 'package:flutter/material.dart';

import '../services/notify_service.dart';
import '../store.dart';
import '../theme.dart';
import 'chat_screen.dart';
import 'focus_screen.dart';
import 'hub.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!app.s.askedNotifPermission) {
        app.s.askedNotifPermission = true;
        app.saveSettings();
        await notifier.requestPermission();
        app.scheduleNotifications();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: app.tab,
      builder: (context, i, _) => TweenAnimationBuilder<Color?>(
        tween: ColorTween(
            end: isDark(context) ? C.darkBg : kTabColors[i]),
        duration: const Duration(milliseconds: 350),
        builder: (context, bg, child) =>
            Scaffold(backgroundColor: bg, body: child, bottomNavigationBar: _nav(context, i)),
        child: SafeArea(
          bottom: false,
          child: IndexedStack(
            index: i,
            children: const [
              FlashcardsHub(), // kTabFlash
              StudyHub(), // kTabStudy
              ChatScreen(), // kTabChat
              FocusScreen(), // kTabFocus
            ],
          ),
        )
      ),
    );
  }

  Widget _nav(BuildContext context, int i) {
    return Container(
          decoration: BoxDecoration(
            border: Border(
                top: BorderSide(
                    color: isDark(context) ? Colors.white54 : C.ink, width: 2)),
          ),
          child: NavigationBar(
          selectedIndex: i,
          onDestinationSelected: (v) => app.tab.value = v,
          destinations: const [
            NavigationDestination(
                icon: Icon(Icons.style_outlined),
                selectedIcon: Icon(Icons.style),
                label: 'Flashcards'),
            NavigationDestination(
                icon: Icon(Icons.school_outlined),
                selectedIcon: Icon(Icons.school),
                label: 'Study'),
            NavigationDestination(
                icon: Icon(Icons.chat_bubble_outline),
                selectedIcon: Icon(Icons.chat_bubble),
                label: 'المحادثة'),
            NavigationDestination(
                icon: Icon(Icons.forest_outlined),
                selectedIcon: Icon(Icons.forest),
                label: 'تركيز'),
          ],
        ),
        );
  }
}
