import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models.dart';
import '../services/ai_service.dart';
import '../services/anki_service.dart';
import '../services/notify_service.dart';
import '../services/tts_service.dart';
import '../store.dart';
import '../theme.dart';

/// الإعدادات تُفتح كصفحة (خرجت من الشريط السفلي ليتّسع لتبويب الاختبارات).
void openSettings(BuildContext context) {
  Navigator.push(
    context,
    MaterialPageRoute(
      builder: (c) => Container(
        color: isDark(c) ? C.darkBg : C.mint,
        child: const SettingsScreen(),
      ),
    ),
  );
}

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final TextEditingController _token;
  late final TextEditingController _m1;
  late final TextEditingController _m2;
  bool _testingAi = false;
  bool _hideToken = true;

  @override
  void initState() {
    super.initState();
    _token = TextEditingController(text: app.s.hfToken);
    _m1 = TextEditingController(text: app.s.hfModel);
    _m2 = TextEditingController(text: app.s.hfModel2);
  }

  @override
  void dispose() {
    _token.dispose();
    _m1.dispose();
    _m2.dispose();
    super.dispose();
  }

  Future<void> _pickTime() async {
    final t = await showTimePicker(
      context: context,
      initialTime: TimeOfDay(hour: app.s.notifyHour, minute: app.s.notifyMinute),
    );
    if (t == null) return;
    app.s.notifyHour = t.hour;
    app.s.notifyMinute = t.minute;
    app.saveSettings(reschedule: true);
  }

  Future<void> _testAi() async {
    if (!ai.hasKey(app.s)) {
      toast(context, 'أضف المفتاح أولاً — سيجرَّب المزوّد المجاني فقط');
    }
    setState(() => _testingAi = true);
    try {
      final r = await ai.chat([
        {'role': 'user', 'content': 'Reply with one word: OK'}
      ], s: app.s, maxTokens: 20);
      if (mounted) toast(context, 'يعمل ✓  المزوّد: ${r.provider}');
    } catch (e) {
      if (mounted) toast(context, 'فشلت كل المحاولات: $e');
    } finally {
      if (mounted) setState(() => _testingAi = false);
    }
  }

  Future<void> _import() async {
    final ctrl = TextEditingController();
    final text = await showDialog<String>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('استيراد نسخة احتياطية'),
        content: TextField(
          controller: ctrl,
          maxLines: 8,
          textDirection: TextDirection.ltr,
          decoration: const InputDecoration(hintText: 'الصق نص JSON هنا'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c), child: const Text('إلغاء')),
          TextButton(
              onPressed: () => Navigator.pop(c, ctrl.text),
              child: const Text('استيراد')),
        ],
      ),
    );
    if (text == null || text.trim().isEmpty) return;
    try {
      final n = app.importJson(text);
      if (mounted) toast(context, 'تم استيراد $n كلمة');
    } catch (_) {
      if (mounted) toast(context, 'نص غير صالح');
    }
  }

  Future<void> _importAnki() async {
    AnkiImport? res;
    try {
      res = await anki.pickAndParse();
    } catch (e) {
      if (mounted) {
        toast(context, e.toString().replaceFirst('Exception: ', ''));
      }
      return;
    }
    if (res == null || !mounted) return;
    var lang = app.s.defaultLang;
    var swap = false;
    final pairs = res.pairs;
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, set) => AlertDialog(
          title: Text('استيراد ${pairs.length} بطاقة'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text('مثال: ${swap ? pairs.first[1] : pairs.first[0]}  =  '
                  '${swap ? pairs.first[0] : pairs.first[1]}'),
              const SizedBox(height: 12),
              LangDropdown(
                  label: 'لغة الكلمات',
                  value: lang,
                  onChanged: (v) => set(() => lang = v)),
              CheckboxListTile(
                contentPadding: EdgeInsets.zero,
                value: swap,
                onChanged: (v) => set(() => swap = v ?? false),
                title: const Text('عكس الوجهين (الكلمة في الخلف)'),
              ),
            ]),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(c, false),
                child: const Text('إلغاء')),
            TextButton(
                onPressed: () => Navigator.pop(c, true),
                child: const Text('استيراد')),
          ],
        ),
      ),
    );
    if (ok != true || !mounted) return;
    final out = swap ? [for (final p in pairs) [p[1], p[0]]] : pairs;
    final r = app.addPairs(out, lang);
    toast(context,
        'تمت إضافة ${r.added} كلمة${r.skipped > 0 ? ' (${r.skipped} مكررة)' : ''}');
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([app, tts]),
      builder: (context, _) {
        final s = app.s;
        final pool = app.dailyPool;
        final selected = app.words.where((w) => w.daily).length;
        return Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(title: const Text('الإعدادات')),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 32),
            children: [
              _section('الذكاء الاصطناعي', [
                AnimatedSwitcher(
                  duration: const Duration(milliseconds: 250),
                  child: Text(
                      ai.hasKey(s)
                          ? (s.hfToken.trim().isNotEmpty
                              ? '✓ مفتاحك الخاص مُفعَّل'
                              : '✓ يوجد مفتاح مدمج وقت البناء')
                          : 'لا يوجد مفتاح. يُستخدم مزوّد مجاني احتياطي (أبطأ وأقل دقة).',
                      key: ValueKey(ai.hasKey(s) ? s.hfToken.trim().isEmpty : null),
                      style: const TextStyle(fontWeight: FontWeight.w800)),
                ),
                const SizedBox(height: 4),
                const Text(
                    'يُستخدم لتوليد الاختبارات في Study وللمحادثة والأمثلة والملخصات. '
                    'يُحفظ على جهازك فقط. مفتاح Hugging Face يبدأ بـ hf_',
                    style: TextStyle(fontSize: 12.5, height: 1.5)),
                const SizedBox(height: 10),
                TextField(
                  controller: _token,
                  obscureText: _hideToken,
                  autocorrect: false,
                  enableSuggestions: false,
                  textDirection: TextDirection.ltr,
                  onChanged: (v) {
                    s.hfToken = v.trim();
                    app.saveSettings();
                  },
                  decoration: InputDecoration(
                    labelText: 'مفتاح الذكاء الاصطناعي (API key)',
                    hintText: 'hf_xxxxxxxxxxxxxxxx',
                    suffixIcon: Row(mainAxisSize: MainAxisSize.min, children: [
                      IconButton(
                        tooltip: _hideToken ? 'إظهار' : 'إخفاء',
                        icon: Icon(_hideToken
                            ? Icons.visibility_outlined
                            : Icons.visibility_off_outlined),
                        onPressed: () => setState(() => _hideToken = !_hideToken),
                      ),
                      IconButton(
                        tooltip: 'لصق',
                        icon: const Icon(Icons.content_paste),
                        onPressed: () async {
                          final d = await Clipboard.getData(Clipboard.kTextPlain);
                          final t = (d?.text ?? '').trim();
                          if (t.isEmpty) return;
                          _token.text = t;
                          s.hfToken = t;
                          app.saveSettings();
                        },
                      ),
                    ]),
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _m1,
                  textDirection: TextDirection.ltr,
                  onChanged: (v) {
                    s.hfModel = v.trim();
                    app.saveSettings();
                  },
                  decoration: const InputDecoration(labelText: 'النموذج الأساسي'),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _m2,
                  textDirection: TextDirection.ltr,
                  onChanged: (v) {
                    s.hfModel2 = v.trim();
                    app.saveSettings();
                  },
                  decoration: const InputDecoration(labelText: 'النموذج الاحتياطي'),
                ),
                const SizedBox(height: 12),
                NeoButton(
                  label: 'اختبار الاتصال',
                  icon: Icons.wifi_tethering,
                  color: C.blue,
                  busy: _testingAi,
                  onPressed: _testAi,
                ),
              ]),
              _section('المظهر والتعلّم', [
                SegmentedButton<int>(
                  segments: const [
                    ButtonSegment(value: 0, label: Text('تلقائي')),
                    ButtonSegment(value: 1, label: Text('فاتح')),
                    ButtonSegment(value: 2, label: Text('داكن')),
                  ],
                  selected: {s.themeMode},
                  onSelectionChanged: (v) {
                    s.themeMode = v.first;
                    app.saveSettings();
                  },
                ),
                const SizedBox(height: 12),
                LangDropdown(
                  label: 'لغة الكلمات الافتراضية',
                  value: s.defaultLang,
                  onChanged: (v) {
                    s.defaultLang = v;
                    app.saveSettings();
                  },
                ),
                Text('الهدف اليومي: ${s.dailyGoal} إجابة'),
                Slider(
                  min: 5,
                  max: 60,
                  divisions: 11,
                  value: s.dailyGoal.clamp(5, 60).toDouble(),
                  onChanged: (v) {
                    s.dailyGoal = v.round();
                    app.saveSettings();
                  },
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  value: s.autoExamples,
                  onChanged: (v) {
                    s.autoExamples = v;
                    app.saveSettings();
                  },
                  title: const Text('توليد الأمثلة تلقائياً'),
                  subtitle: const Text('عند فتح بطاقة لا تحتوي على أمثلة'),
                ),
              ]),
              _section('الصوت', [
                const Text('محرك النطق',
                    style: TextStyle(fontWeight: FontWeight.w900)),
                const SizedBox(height: 6),
                Wrap(spacing: 8, runSpacing: 4, children: [
                  for (final e in const [
                    'تلقائي (موصى به)',
                    'Google',
                    'ResponsiveVoice',
                    'صوت الجهاز',
                  ].asMap().entries)
                    ChoiceChip(
                      label: Text(e.value),
                      selected: s.ttsEngine == e.key,
                      onSelected: (_) {
                        s.ttsEngine = e.key;
                        app.saveSettings();
                      },
                    ),
                ]),
                const SizedBox(height: 6),
                const Text(
                    'التلقائي يجرّب Google ثم ResponsiveVoice ثم صوت الجهاز. '
                    'أصوات Google تُحفظ على الجهاز فتعمل الكلمات المتكررة فوراً.',
                    style: TextStyle(fontSize: 13)),
                const SizedBox(height: 10),
                Text('Google: ${tts.googleStatus}',
                    style: const TextStyle(fontWeight: FontWeight.w700)),
                Text('ResponsiveVoice: ${tts.status}',
                    style: const TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                Text('سرعة النطق: ${s.rate.toStringAsFixed(2)}'),
                Slider(
                  min: 0.5,
                  max: 1.2,
                  divisions: 14,
                  value: s.rate.clamp(0.5, 1.2).toDouble(),
                  onChanged: (v) {
                    s.rate = v;
                    app.saveSettings();
                  },
                ),
                Row(children: [
                  Expanded(
                    child: NeoButton(
                      label: 'اختبار الصوت',
                      icon: Icons.volume_up,
                      color: C.mint,
                      onPressed: () => speakText(
                          'Hello! Welcome to Wordia.', langOf('en')),
                    ),
                  ),
                ]),
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(
                    child: NeoButton(
                      label: 'فحص Google',
                      icon: Icons.fact_check_outlined,
                      color: C.blue,
                      onPressed: () async {
                        final ok = await tts.testGoogle();
                        if (mounted) {
                          toast(context,
                              ok ? 'Google يعمل ✓' : 'Google لا يعمل هنا');
                        }
                      },
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: NeoButton(
                      label: 'فحص ResponsiveVoice',
                      icon: Icons.fact_check_outlined,
                      color: C.yellow,
                      onPressed: () async {
                        final ok = await tts.testRv();
                        if (mounted) {
                          toast(context,
                              ok ? 'ResponsiveVoice يعمل ✓' : 'لا يعمل هنا');
                        }
                      },
                    ),
                  ),
                ]),
              ]),
              _section('الإشعارات اليومية', [
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  value: s.notifyOn,
                  onChanged: (v) async {
                    s.notifyOn = v;
                    if (v) await notifier.requestPermission();
                    app.saveSettings(reschedule: true);
                  },
                  title: const Text('إرسال كلمة كل يوم'),
                ),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('وقت الإشعار'),
                  trailing: Text(
                    TimeOfDay(hour: s.notifyHour, minute: s.notifyMinute)
                        .format(context),
                    style: const TextStyle(
                        fontWeight: FontWeight.w900, fontSize: 16),
                  ),
                  onTap: _pickTime,
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  value: s.hideTranslation,
                  onChanged: (v) {
                    s.hideTranslation = v;
                    app.saveSettings(reschedule: true);
                  },
                  title: const Text('إخفاء الترجمة في الإشعار'),
                  subtitle: const Text('لتحاول تذكّر المعنى أولاً'),
                ),
                Text(selected > 0
                    ? 'الكلمات المحددة للإرسال: $selected'
                    : 'لم تحدد كلمات، سيتم الاختيار من كل كلماتك (${pool.length}).'),
                const SizedBox(height: 10),
                NeoButton(
                  label: 'إرسال إشعار تجريبي',
                  icon: Icons.notifications_active,
                  color: C.pink,
                  onPressed: () async {
                    await notifier.requestPermission();
                    final ok = await notifier.showTest(
                        pool.isEmpty ? null : pool.first, s.hideTranslation);
                    if (mounted) {
                      toast(context,
                          ok ? 'تم الإرسال' : 'تعذّر إرسال الإشعار، تحقق من الأذونات');
                    }
                  },
                ),
              ]),
              _section('البيانات', [
                NeoButton(
                  label: 'نسخ نسخة احتياطية (JSON)',
                  icon: Icons.copy,
                  color: C.mint,
                  onPressed: () {
                    Clipboard.setData(ClipboardData(text: app.exportJson()));
                    toast(context, 'تم النسخ إلى الحافظة');
                  },
                ),
                const SizedBox(height: 10),
                NeoButton(
                  label: 'استيراد من Anki (.apkg / نص)',
                  icon: Icons.file_open,
                  color: C.blue,
                  onPressed: _importAnki,
                ),
                const SizedBox(height: 10),
                NeoButton(
                  label: 'استيراد من الحافظة',
                  icon: Icons.paste,
                  color: C.yellow,
                  onPressed: _import,
                ),
                const SizedBox(height: 10),
                NeoButton(
                  label: 'حذف كل البيانات',
                  icon: Icons.delete_forever,
                  color: C.coral,
                  onPressed: () async {
                    if (await confirm(context, 'حذف كل البيانات',
                        'سيتم حذف كل الكلمات والمحادثة والملخصات والإحصائيات '
                        'والغابة نهائياً. انسخ نسخة احتياطية أولاً إن أردت.',
                        ok: 'حذف')) {
                      app.clearAll();
                    }
                  },
                ),
              ]),
              const SizedBox(height: 8),
              const Center(child: Text('Wordia • الإصدار $kAppVersion')),
            ],
          ),
        );
      },
    );
  }

  Widget _section(String title, List<Widget> children) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 18),
      child: NeoCard(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title,
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
            const SizedBox(height: 12),
            ...children,
          ],
        ),
      ),
    );
  }
}
