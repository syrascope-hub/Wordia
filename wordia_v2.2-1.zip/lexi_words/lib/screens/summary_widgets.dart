import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models.dart';
import '../services/ai_service.dart';
import '../store.dart';
import '../theme.dart';

/// عرض نتيجة التلخيص (ملخص + نقاط + كلمات قابلة للإضافة). يُستخدم للنص وليوتيوب.
class SummaryResultView extends StatefulWidget {
  final String title;
  final String subtitle;
  final String langCode; // لغة النص الأصلي (للكلمات)
  final bool summaryInSourceLang;
  final String summary;
  final List<String> points;
  final List<SumWord> words;
  final String chatContext;

  const SummaryResultView({
    super.key,
    required this.title,
    required this.subtitle,
    required this.langCode,
    required this.summary,
    required this.points,
    required this.words,
    required this.chatContext,
    this.summaryInSourceLang = false,
  });

  @override
  State<SummaryResultView> createState() => _SummaryResultViewState();
}

class _SummaryResultViewState extends State<SummaryResultView> {
  late Set<int> _picked;

  @override
  void initState() {
    super.initState();
    _picked = {for (var i = 0; i < widget.words.length; i++) i};
  }

  bool get _langKnown => kLangs.any((l) => l.code == widget.langCode);

  void _addWords() {
    final w = widget.words;
    final pairs = [
      for (final i in _picked) [w[i].word, w[i].translation, w[i].pos]
    ];
    final r = app.addPairs(pairs, widget.langCode);
    toast(context,
        'أُضيفت ${r.added} كلمة${r.skipped > 0 ? ' (تخطّي ${r.skipped} مكررة)' : ''}');
  }

  void _askChat() {
    app.chatPrefill = '${widget.chatContext}\n\nأريد أن أسأل عن هذا النص: ';
    app.tab.value = kTabChat;
    Navigator.of(context).popUntil((r) => r.isFirst);
  }

  @override
  Widget build(BuildContext context) {
    final dark = isDark(context);
    final l = langOf(widget.langCode);
    final sumDir = widget.summaryInSourceLang ? langDir(l) : TextDirection.rtl;
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const SizedBox(height: 16),
      NeoCard(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          if (widget.title.isNotEmpty)
            Text(widget.title,
                style: heading(22, color: dark ? Colors.white : C.ink)),
          if (widget.subtitle.isNotEmpty) ...[
            const SizedBox(height: 4),
            Text(widget.subtitle, style: const TextStyle(fontSize: 12.5)),
          ],
          const Divider(height: 24, thickness: 2),
          Directionality(
            textDirection: sumDir,
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Expanded(
                      child: SelectableText(widget.summary,
                          style: const TextStyle(
                              fontSize: 17,
                              height: 1.7,
                              fontWeight: FontWeight.w600)),
                    ),
                    if (widget.summaryInSourceLang && _langKnown)
                      SpeakButton(text: widget.summary, lang: l, size: 38),
                  ]),
                  if (widget.points.isNotEmpty) ...[
                    const SizedBox(height: 14),
                    for (final p in widget.points)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('•  ',
                                  style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.w900)),
                              Expanded(
                                  child: SelectableText(p,
                                      style: const TextStyle(
                                          fontSize: 16, height: 1.6))),
                            ]),
                      ),
                  ],
                ]),
          ),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
              child: NeoButton(
                label: 'نسخ',
                icon: Icons.copy,
                color: C.blue,
                onPressed: () {
                  final b = StringBuffer(widget.summary);
                  for (final p in widget.points) {
                    b.write('\n• $p');
                  }
                  Clipboard.setData(ClipboardData(text: b.toString()));
                  toast(context, 'تم النسخ');
                },
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: NeoButton(
                label: 'اسأل عنه',
                icon: Icons.chat_bubble_outline,
                color: C.mint,
                onPressed: _askChat,
              ),
            ),
          ]),
        ]),
      ),
      if (widget.words.isNotEmpty && _langKnown) ...[
        const SizedBox(height: 16),
        NeoCard(
          color: C.mint,
          padding: const EdgeInsets.all(16),
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('كلمات مقترحة (${_picked.length})',
                style: heading(22, color: C.ink)),
            const SizedBox(height: 6),
            for (var i = 0; i < widget.words.length; i++)
              CheckboxListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                controlAffinity: ListTileControlAffinity.leading,
                value: _picked.contains(i),
                onChanged: (v) => setState(() {
                  if (v == true) {
                    _picked.add(i);
                  } else {
                    _picked.remove(i);
                  }
                }),
                title: Directionality(
                  textDirection: langDir(l),
                  child: Text(widget.words[i].word,
                      style: const TextStyle(
                          fontSize: 18, fontWeight: FontWeight.w900)),
                ),
                subtitle: Text(
                    '${widget.words[i].translation}${widget.words[i].pos.isEmpty ? '' : '  •  ${widget.words[i].pos}'}'),
                secondary:
                    SpeakButton(text: widget.words[i].word, lang: l, size: 36),
              ),
            const SizedBox(height: 8),
            NeoButton(
              label: 'أضف المحدّد إلى كلماتي',
              icon: Icons.add,
              color: C.yellow,
              onPressed: _picked.isEmpty ? null : _addWords,
            ),
          ]),
        ),
      ],
    ]);
  }
}

SummaryRec recFrom(SummaryResult r,
        {required String title, required String lang, required String source}) =>
    SummaryRec(
      id: app.newId(),
      ts: DateTime.now().millisecondsSinceEpoch,
      title: title,
      lang: lang,
      source: source,
      summary: r.summary,
      points: r.points,
      words: [for (final w in r.words) [w.word, w.translation, w.pos]],
    );

SummaryResult resultFrom(SummaryRec r) => SummaryResult(
      summary: r.summary,
      points: r.points,
      words: [
        for (final w in r.words)
          if (w.length >= 2) SumWord(w[0], w[1], w.length > 2 ? w[2] : '')
      ],
    );
