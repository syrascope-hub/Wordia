import 'dart:math';

import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';
import '../theme.dart';
import 'story_screen.dart';
import 'text_summary_screen.dart';
import 'video_summary_screen.dart';

enum GameMode { tf, mcq, listen, type, dictation }

class GamesScreen extends StatelessWidget {
  const GamesScreen({super.key});

  void _open(BuildContext context, GameMode m) {
    final need = switch (m) {
      GameMode.tf => 2,
      GameMode.type || GameMode.dictation => 1,
      _ => 4,
    };
    if (app.words.length < need) {
      toast(context, 'تحتاج $need كلمات على الأقل لهذه اللعبة');
      return;
    }
    Navigator.push(
        context, MaterialPageRoute(builder: (_) => GamePage(mode: m)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(title: const Text('ألعاب المفردات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _tile(context, C.blue, '⛵', 'صح أم خطأ',
              'ساعد القارب على الهروب من الأخطبوط', GameMode.tf),
          const SizedBox(height: 16),
          _tile(context, C.pink, '🎯', 'اختر الترجمة',
              'كلمة واحدة وأربعة خيارات', GameMode.mcq),
          const SizedBox(height: 16),
          _tile(context, C.mint, '🎧', 'استمع واختر',
              'اسمع النطق واختر الكلمة الصحيحة', GameMode.listen),
          const SizedBox(height: 16),
          _tile(context, C.yellow, '⌨️', 'اكتب الكلمة',
              'ترى المعنى فتكتب الكلمة بلغتها', GameMode.type),
          const SizedBox(height: 16),
          _tile(context, C.coral, '✍️', 'إملاء',
              'استمع واكتب ما سمعته', GameMode.dictation),
          const SizedBox(height: 16),
          NeoCard(
            color: C.blue,
            padding: const EdgeInsets.all(20),
            onTap: () {
              if (app.words.length < 3) {
                toast(context, 'تحتاج 3 كلمات على الأقل');
                return;
              }
              Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const StoryScreen()));
            },
            child: Row(children: [
              const Text('📖', style: TextStyle(fontSize: 44)),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('قصة بكلماتك', style: heading(24, color: C.ink)),
                    const SizedBox(height: 4),
                    const Text('يكتب الذكاء الاصطناعي قصة تستخدم كلماتك'),
                  ],
                ),
              ),
              const Icon(Icons.chevron_left),
            ]),
          ),
          const SizedBox(height: 16),
          NeoCard(
            color: C.yellow,
            padding: const EdgeInsets.all(20),
            onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => const TextSummaryScreen())),
            child: Row(children: [
              const Text('📝', style: TextStyle(fontSize: 44)),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('تلخيص نص', style: heading(24, color: C.ink)),
                    const SizedBox(height: 4),
                    const Text('الصق نصاً أو صوّر صفحة واستخرج كلمات منها'),
                  ],
                ),
              ),
              const Icon(Icons.chevron_left),
            ]),
          ),
          const SizedBox(height: 16),
          NeoCard(
            color: C.pink,
            padding: const EdgeInsets.all(20),
            onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => const VideoSummaryScreen())),
            child: Row(children: [
              const Text('📺', style: TextStyle(fontSize: 44)),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('تلخيص يوتيوب', style: heading(24, color: C.ink)),
                    const SizedBox(height: 4),
                    const Text('الصق رابط فيديو واحصل على ملخص وكلمات للتعلّم'),
                  ],
                ),
              ),
              const Icon(Icons.chevron_left),
            ]),
          ),
        ],
      ),
    );
  }

  Widget _tile(BuildContext context, Color color, String emoji, String title,
      String sub, GameMode m) {
    return NeoCard(
      color: color,
      padding: const EdgeInsets.all(20),
      onTap: () => _open(context, m),
      child: Row(children: [
        Text(emoji, style: const TextStyle(fontSize: 44)),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: heading(24, color: C.ink)),
              const SizedBox(height: 4),
              Text(sub),
            ],
          ),
        ),
        const Icon(Icons.chevron_left),
      ]),
    );
  }
}

class GamePage extends StatefulWidget {
  final GameMode mode;
  const GamePage({super.key, required this.mode});

  @override
  State<GamePage> createState() => _GamePageState();
}

class _GamePageState extends State<GamePage> {
  final _rnd = Random();
  late List<Word> _qs;
  int _i = 0;
  int _score = 0;
  int _wrongs = 0;
  bool _answered = false;
  String? _picked;

  // الحالة الخاصة بالسؤال الحالي
  List<String> _options = [];
  String _correct = '';
  bool _tfTruth = true;
  String _tfShown = '';
  final TextEditingController _input = TextEditingController();
  final FocusNode _focus = FocusNode();
  bool _typedOk = false;
  String _typed = '';

  GameMode get mode => widget.mode;

  @override
  void initState() {
    super.initState();
    final all = [...app.words]..shuffle(_rnd);
    _qs = all.take(min(12, all.length)).toList();
    _prepare();
  }

  Word get _w => _qs[_i];

  @override
  void dispose() {
    _input.dispose();
    _focus.dispose();
    super.dispose();
  }

  static String _n(String s) => s
      .toLowerCase()
      .replaceAll(RegExp(r'[\u064B-\u0652\u0640]'), '')
      .replaceAll(RegExp(r'[\s\.,;:!?¿¡"\u0027’«»()\-]+'), '');

  void _next() {
    if (!mounted) return;
    setState(() {
      _i++;
      if (_i < _qs.length) _prepare();
    });
  }

  void _checkTyped() {
    if (_answered) return;
    final typed = _input.text.trim();
    if (typed.isEmpty) return;
    final ok = _n(typed) == _n(_w.word);
    setState(() {
      _answered = true;
      _typed = typed;
      _typedOk = ok;
      if (ok) {
        _score++;
      } else {
        _wrongs++;
      }
    });
    app.bump(_w, ok);
    if (ok) speakText(_w.word, _w.language);
  }

  void _prepare() {
    _answered = false;
    _picked = null;
    _typed = '';
    _typedOk = false;
    _input.clear();
    final w = _w;
    if (mode == GameMode.type || mode == GameMode.dictation) {
      _correct = w.word;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _focus.requestFocus();
      });
      if (mode == GameMode.dictation) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) speakText(_w.word, _w.language);
        });
      }
    } else if (mode == GameMode.tf) {
      _tfTruth = _rnd.nextBool();
      _correct = w.translation;
      if (_tfTruth) {
        _tfShown = w.translation;
      } else {
        final others = app.words
            .where((x) =>
                x.id != w.id &&
                x.translation.trim() != w.translation.trim())
            .toList();
        if (others.isEmpty) {
          _tfTruth = true;
          _tfShown = w.translation;
        } else {
          _tfShown = others[_rnd.nextInt(others.length)].translation;
        }
      }
    } else {
      final useWords = mode == GameMode.listen;
      _correct = useWords ? w.word : w.translation;
      final pool = app.words
          .where((x) => x.id != w.id)
          .map((x) => useWords ? x.word : x.translation)
          .where((t) => t.trim() != _correct.trim())
          .toSet()
          .toList()
        ..shuffle(_rnd);
      _options = [_correct, ...pool.take(3)]..shuffle(_rnd);
    }
    if (mode == GameMode.listen) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) speakText(_w.word, _w.language);
      });
    }
  }

  void _answer(String choice, bool ok) {
    if (_answered) return;
    setState(() {
      _answered = true;
      _picked = choice;
      if (ok) {
        _score++;
      } else {
        _wrongs++;
      }
    });
    app.bump(_w, ok);
    Future.delayed(const Duration(milliseconds: 1000), _next);
  }

  @override
  Widget build(BuildContext context) {
    final done = _i >= _qs.length;
    final title = switch (mode) {
      GameMode.tf => 'صح أم خطأ',
      GameMode.mcq => 'اختر الترجمة',
      GameMode.listen => 'استمع واختر',
      GameMode.type => 'اكتب الكلمة',
      GameMode.dictation => 'إملاء',
    };
    return Scaffold(
      backgroundColor: isDark(context) ? C.darkBg : C.blue,
      appBar: AppBar(
        title: Text(title),
        actions: [
          if (!done)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    color: C.cream,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: C.ink, width: 2),
                  ),
                  child: Text('${_i + 1} / ${_qs.length}',
                      style: const TextStyle(
                          fontWeight: FontWeight.w900, color: C.ink)),
                ),
              ),
            ),
        ],
      ),
      body: done ? _result() : _body(),
    );
  }

  Widget _body() {
    switch (mode) {
      case GameMode.tf:
        return _tfBody();
      case GameMode.mcq:
        return _mcqBody(listen: false);
      case GameMode.listen:
        return _mcqBody(listen: true);
      case GameMode.type:
        return _typeBody(dictation: false);
      case GameMode.dictation:
        return _typeBody(dictation: true);
    }
  }

  // ---------- صح أم خطأ ----------
  Widget _tfBody() {
    final w = _w;
    final l = w.language;
    final progress = _qs.isEmpty ? 0.0 : _score / _qs.length;
    final wrongRatio = _qs.isEmpty ? 0.0 : _wrongs / _qs.length;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      child: Column(children: [
        Expanded(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: LayoutBuilder(builder: (context, box) {
              final W = box.maxWidth;
              final H = box.maxHeight;
              final boatLeft = 16 + (W - 110) * progress;
              final octoLeft = max(-10.0, boatLeft - 170 + wrongRatio * 150);
              return Stack(children: [
                Positioned.fill(
                  child: DecoratedBox(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Color(0xFFD7F5EE),
                          Color(0xFFBDE7F0),
                          Color(0xFF4FB6D1),
                          Color(0xFF2A93B5),
                        ],
                        stops: [0, 0.45, 0.46, 1],
                      ),
                    ),
                  ),
                ),
                Positioned.fill(
                  child: CustomPaint(painter: SeaPainter(horizon: 0.45)),
                ),
                AnimatedPositioned(
                  duration: const Duration(milliseconds: 600),
                  curve: Curves.easeOut,
                  top: H * 0.45 - 30,
                  left: octoLeft,
                  child: const Text('🐙', style: TextStyle(fontSize: 64)),
                ),
                AnimatedPositioned(
                  duration: const Duration(milliseconds: 600),
                  curve: Curves.easeOut,
                  top: H * 0.45 - 40,
                  left: boatLeft,
                  child: const Text('⛵', style: TextStyle(fontSize: 64)),
                ),
              ]);
            }),
          ),
        ),
        const SizedBox(height: 16),
        NeoCard(
          padding: const EdgeInsets.all(18),
          child: Column(children: [
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Flexible(
                child: Text.rich(
                  TextSpan(children: [
                    TextSpan(
                        text: '${w.word} = ',
                        style: TextStyle(
                            fontSize: 26,
                            fontWeight: FontWeight.w900,
                            color: isDark(context) ? Colors.white : C.ink)),
                    TextSpan(
                        text: _tfShown,
                        style: const TextStyle(
                            fontSize: 26,
                            fontWeight: FontWeight.w900,
                            color: Color(0xFF1B8A6B))),
                  ]),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(width: 10),
              SpeakButton(text: w.word, lang: l, size: 38),
            ]),
            const SizedBox(height: 4),
            const Text('صح أم خطأ؟'),
            const SizedBox(height: 14),
            Row(children: [
              Expanded(
                child: NeoButton(
                  label: 'نعم',
                  icon: Icons.check,
                  color: _tfResultColor(true, C.mint),
                  onPressed: _answered ? null : () => _answer('yes', _tfTruth),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: NeoButton(
                  label: 'لا',
                  icon: Icons.close,
                  color: _tfResultColor(false, C.pink),
                  onPressed: _answered ? null : () => _answer('no', !_tfTruth),
                ),
              ),
            ]),
          ]),
        ),
      ]),
    );
  }

  Color _tfResultColor(bool isYes, Color normal) {
    if (!_answered) return normal;
    final correctIsYes = _tfTruth;
    if (isYes == correctIsYes) return const Color(0xFF7ED9A8);
    return normal.withValues(alpha: 0.5);
  }

  // ---------- كتابة / إملاء ----------
  Widget _typeBody({required bool dictation}) {
    final w = _w;
    final l = w.language;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
      children: [
        NeoCard(
          color: dictation ? C.coral : C.yellow,
          padding: const EdgeInsets.all(24),
          child: Column(children: [
            if (dictation) ...[
              Text('اكتب ما تسمعه', style: heading(24, color: C.ink)),
              const SizedBox(height: 14),
              SpeakButton(text: w.word, lang: l, size: 84),
              const SizedBox(height: 8),
              Text('${l.flag} ${l.name}'),
            ] else ...[
              Text('${l.flag} ${l.name}'),
              const SizedBox(height: 10),
              Text(w.translation,
                  textAlign: TextAlign.center,
                  style: heading(36, color: C.ink)),
              if (w.note.isNotEmpty) ...[
                const SizedBox(height: 4),
                Text(w.note),
              ],
              const SizedBox(height: 6),
              const Text('اكتب الكلمة بلغتها',
                  style: TextStyle(fontWeight: FontWeight.w800)),
            ],
          ]),
        ),
        const SizedBox(height: 18),
        TextField(
          controller: _input,
          focusNode: _focus,
          enabled: !_answered,
          autofocus: true,
          autocorrect: false,
          enableSuggestions: false,
          textDirection: langDir(l),
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
          onSubmitted: (_) => _checkTyped(),
          decoration: const InputDecoration(hintText: '…اكتب هنا'),
        ),
        const SizedBox(height: 14),
        if (!_answered) ...[
          NeoButton(
            label: 'تحقّق',
            icon: Icons.check,
            color: C.mint,
            onPressed: _checkTyped,
          ),
          const SizedBox(height: 10),
          NeoButton(
            label: 'أظهر الإجابة',
            icon: Icons.visibility,
            color: C.pink,
            onPressed: () {
              setState(() {
                _answered = true;
                _typed = _input.text.trim();
                _typedOk = false;
                _wrongs++;
              });
              app.bump(_w, false);
            },
          ),
        ] else ...[
          NeoCard(
            color: _typedOk ? const Color(0xFF7ED9A8) : const Color(0xFFFFC9C0),
            padding: const EdgeInsets.all(16),
            child: Column(children: [
              Text(_typedOk ? 'أحسنت! ✓' : 'الإجابة الصحيحة',
                  style: heading(22, color: C.ink)),
              const SizedBox(height: 8),
              Directionality(
                textDirection: langDir(l),
                child: _diff(w.word, _typed),
              ),
              const SizedBox(height: 6),
              Text(w.translation,
                  style: const TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              SpeakButton(text: w.word, lang: l, size: 44),
            ]),
          ),
          const SizedBox(height: 14),
          NeoButton(
            label: _i + 1 >= _qs.length ? 'عرض النتيجة' : 'التالي',
            icon: Icons.arrow_back,
            color: C.blue,
            onPressed: _next,
          ),
        ],
      ],
    );
  }

  /// يلوّن حروف الإجابة الصحيحة: أخضر لما طابق ما كتبته وأحمر لما أخطأت فيه.
  Widget _diff(String correct, String typed) {
    final c = correct.runes.map(String.fromCharCode).toList();
    final t = typed.runes.map(String.fromCharCode).toList();
    // محاذاة LCS: الحرف أخضر إن كان ضمن أطول تسلسل مشترك مع ما كتبته، فلا يتحول
    // باقي الكلمة للأحمر عند نسيان حرف واحد (كانت المقارنة موضعاً بموضع).
    final n = c.length, m = t.length;
    bool same(int i, int j) => c[i].toLowerCase() == t[j].toLowerCase();
    final dp = List.generate(n + 1, (_) => List<int>.filled(m + 1, 0));
    for (var i = n - 1; i >= 0; i--) {
      for (var j = m - 1; j >= 0; j--) {
        dp[i][j] =
            same(i, j) ? dp[i + 1][j + 1] + 1 : max(dp[i + 1][j], dp[i][j + 1]);
      }
    }
    final good = List<bool>.filled(n, false);
    var gi = 0, gj = 0;
    while (gi < n && gj < m) {
      if (same(gi, gj)) {
        good[gi] = true;
        gi++;
        gj++;
      } else if (dp[gi + 1][gj] >= dp[gi][gj + 1]) {
        gi++;
      } else {
        gj++;
      }
    }
    return Text.rich(
      TextSpan(children: [
        for (var i = 0; i < c.length; i++)
          TextSpan(
            text: c[i],
            style: TextStyle(
              fontSize: 32,
              fontWeight: FontWeight.w900,
              color: (_typedOk || good[i])
                  ? const Color(0xFF0B6B3A)
                  : const Color(0xFFB3261E),
            ),
          ),
      ]),
      textAlign: TextAlign.center,
    );
  }

  // ---------- اختيار من متعدد / استماع ----------
  Widget _mcqBody({required bool listen}) {
    final w = _w;
    final l = w.language;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
      children: [
        NeoCard(
          color: listen ? C.mint : C.pink,
          padding: const EdgeInsets.all(24),
          child: Column(children: [
            if (listen) ...[
              const Text('ماذا سمعت؟',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
              const SizedBox(height: 14),
              SpeakButton(text: w.word, lang: l, size: 84),
            ] else ...[
              Text('${l.flag} ${l.name}'),
              const SizedBox(height: 10),
              Text(w.word,
                  textAlign: TextAlign.center,
                  textDirection: langDir(l),
                  style: const TextStyle(
                      fontSize: 38, fontWeight: FontWeight.w900)),
              const SizedBox(height: 12),
              SpeakButton(text: w.word, lang: l, size: 48),
            ],
          ]),
        ),
        const SizedBox(height: 20),
        for (final o in _options)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: _option(o, listen, l),
          ),
      ],
    );
  }

  Widget _option(String o, bool listen, Lang l) {
    Color? color;
    if (_answered) {
      if (o == _correct) {
        color = const Color(0xFF7ED9A8);
      } else if (o == _picked) {
        color = C.coral;
      }
    }
    return NeoCard(
      color: color,
      onTap: _answered ? null : () => _answer(o, o == _correct),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      child: SizedBox(
        width: double.infinity,
        child: Text(o,
            textAlign: TextAlign.center,
            textDirection: listen ? langDir(l) : TextDirection.rtl,
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
      ),
    );
  }

  // ---------- النتيجة ----------
  Widget _result() {
    final total = _qs.length;
    final pct = total == 0 ? 0 : (_score * 100 / total).round();
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        NeoCard(
          color: C.yellow,
          padding: const EdgeInsets.all(24),
          child: Column(children: [
            Text(pct >= 70 ? '🏆' : '💪', style: const TextStyle(fontSize: 60)),
            const SizedBox(height: 8),
            Text('$_score / $total',
                style:
                    const TextStyle(fontSize: 34, fontWeight: FontWeight.w900)),
            Text('$pct٪ إجابات صحيحة'),
          ]),
        ),
        const SizedBox(height: 20),
        NeoButton(
          label: 'العب مرة أخرى',
          icon: Icons.refresh,
          onPressed: () => setState(() {
            final all = [...app.words]..shuffle(_rnd);
            _qs = all.take(min(12, all.length)).toList();
            _i = 0;
            _score = 0;
            _wrongs = 0;
            _prepare();
          }),
        ),
        const SizedBox(height: 12),
        NeoButton(
          label: 'رجوع',
          color: C.blue,
          onPressed: () => Navigator.pop(context),
        ),
      ],
    );
  }
}
