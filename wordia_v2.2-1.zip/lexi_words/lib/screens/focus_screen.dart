import 'dart:async';

import 'package:flutter/material.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import '../models.dart';
import '../services/ambient_service.dart';
import '../store.dart';
import '../theme.dart';
import 'forest_screen.dart';
import 'tree_painter.dart';

enum _Mode { idle, focus, rest }

/// تركيز بأسلوب Forest: تزرع شجرة وتبدأ المؤقت. إن غادرت التطبيق أكثر من 10 ثوانٍ تذبل.
class FocusScreen extends StatefulWidget {
  const FocusScreen({super.key});

  @override
  State<FocusScreen> createState() => _FocusScreenState();
}

class _FocusScreenState extends State<FocusScreen> with WidgetsBindingObserver {
  static const _graceSeconds = 10;

  _Mode _mode = _Mode.idle;
  double _minutes = 25;
  bool _study = false;
  String _sound = 'none';

  Timer? _timer;
  DateTime? _start;
  DateTime? _end;
  DateTime? _awaySince;
  int _startAnswers = 0;
  String _sessionKind = 'oak';
  int _sessionMinutes = 25;
  int _remaining = 0; // بالثواني
  double _progress = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    app.addListener(_onApp);
  }

  void _onApp() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    app.removeListener(_onApp);
    _timer?.cancel();
    ambient.stop();
    WakelockPlus.disable();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (_mode != _Mode.focus) return;
    if (state == AppLifecycleState.paused || state == AppLifecycleState.hidden) {
      _awaySince ??= DateTime.now();
    } else if (state == AppLifecycleState.resumed) {
      final since = _awaySince;
      _awaySince = null;
      if (since != null &&
          DateTime.now().difference(since).inSeconds > _graceSeconds) {
        _wither(left: true);
      } else {
        _tick();
      }
    }
  }

  void _startFocus() {
    final mins = _minutes.round();
    _sessionMinutes = mins;
    _sessionKind = app.selectedTree;
    _start = DateTime.now();
    _end = _start!.add(Duration(minutes: mins));
    _startAnswers = app.todayAnswers;
    _awaySince = null;
    _mode = _Mode.focus;
    _progress = 0;
    _remaining = mins * 60;
    WakelockPlus.enable();
    ambient.play(_sound);
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) => _tick());
    setState(() {});
  }

  void _startRest() {
    _start = DateTime.now();
    _end = _start!.add(const Duration(minutes: 5));
    _mode = _Mode.rest;
    _progress = 0;
    _remaining = 300;
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) => _tick());
    setState(() {});
  }

  void _tick() {
    if (!mounted || _end == null || _mode == _Mode.idle) return;
    final total = _end!.difference(_start!).inSeconds;
    final left = _end!.difference(DateTime.now()).inSeconds;
    if (left <= 0) {
      if (_mode == _Mode.focus) {
        _succeed();
      } else {
        _toIdle();
        toast(context, 'انتهت الاستراحة. ابدأ جلسة جديدة 🌱');
      }
      return;
    }
    setState(() {
      _remaining = left;
      _progress = total == 0 ? 0 : 1 - left / total;
    });
  }

  void _toIdle() {
    _timer?.cancel();
    ambient.stop();
    WakelockPlus.disable();
    setState(() {
      _mode = _Mode.idle;
      _progress = 0;
    });
  }

  Future<void> _succeed() async {
    final answers = _study ? (app.todayAnswers - _startAnswers).clamp(0, 9999).toInt() : 0;
    final bonus = answers ~/ 5;
    app.addTree(
        ForestTree(_start!.millisecondsSinceEpoch, _sessionMinutes, _sessionKind, true),
        bonusCoins: bonus);
    _toIdle();
    if (!mounted) return;
    final rest = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('🌳 كبرت شجرتك!'),
        content: Text(
            'ركّزت $_sessionMinutes دقيقة وربحت ${_sessionMinutes + bonus} عملة'
            '${bonus > 0 ? ' (منها $bonus مكافأة على $answers إجابة)' : ''}.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('تم')),
          TextButton(
              onPressed: () => Navigator.pop(c, true),
              child: const Text('استراحة 5 دقائق')),
        ],
      ),
    );
    if (rest == true && mounted) _startRest();
  }

  Future<void> _wither({required bool left}) async {
    if (_mode != _Mode.focus) return;
    final mins = ((DateTime.now().difference(_start!).inSeconds) / 60).ceil();
    app.addTree(ForestTree(_start!.millisecondsSinceEpoch,
        mins.clamp(1, _sessionMinutes).toInt(), _sessionKind, false));
    _toIdle();
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('🥀 ذبلت الشجرة'),
        content: Text(left
            ? 'غادرت التطبيق أكثر من $_graceSeconds ثوانٍ فذبلت شجرتك. جرّب مرة أخرى!'
            : 'توقفت قبل انتهاء الجلسة فذبلت الشجرة.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('حسناً'))
        ],
      ),
    );
  }

  Future<void> _giveUp() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('التوقف الآن؟'),
        content: const Text('إن توقفت قبل نهاية الجلسة ستذبل الشجرة.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('أكمل')),
          TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('توقف')),
        ],
      ),
    );
    if (ok == true) _wither(left: false);
  }

  String get _clock {
    final m = (_remaining ~/ 60).toString().padLeft(2, '0');
    final s = (_remaining % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final dark = isDark(context);
    final fg = dark ? Colors.white : C.ink;
    final running = _mode != _Mode.idle;
    final kindId = running ? (_mode == _Mode.focus ? _sessionKind : app.selectedTree) : app.selectedTree;
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: const Text('تركيز'),
        actions: [
          Center(
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 4),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: C.yellow,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: C.ink, width: 2),
              ),
              child: Text('🪙 ${app.coins}',
                  style: const TextStyle(
                      fontWeight: FontWeight.w900, color: C.ink)),
            ),
          ),
          IconButton(
            tooltip: 'الغابة',
            icon: const Icon(Icons.forest),
            onPressed: running
                ? null
                : () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const ForestScreen())),
          ),
          IconButton(
            tooltip: 'المتجر',
            icon: const Icon(Icons.storefront),
            onPressed: running
                ? null
                : () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const ShopScreen())),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
        children: [
          NeoCard(
            color: _mode == _Mode.rest ? C.mint : const Color(0xFFD7F5EE),
            padding: const EdgeInsets.fromLTRB(16, 20, 16, 16),
            child: Column(children: [
              SizedBox(
                height: 230,
                child: Center(
                  child: _mode == _Mode.rest
                      ? const Text('☕', style: TextStyle(fontSize: 120))
                      : TreeView(
                          kindId: kindId,
                          progress: _mode == _Mode.focus ? _progress : 1,
                          size: 230,
                        ),
                ),
              ),
              if (running) ...[
                Text(_clock, style: heading(60, color: C.ink)),
                Text(
                    _mode == _Mode.focus
                        ? 'ابقَ في التطبيق لتكبر شجرتك'
                        : 'استراحة قصيرة',
                    style: const TextStyle(fontWeight: FontWeight.w800)),
              ] else ...[
                Text('${_minutes.round()} دقيقة',
                    style: heading(44, color: C.ink)),
                Slider(
                  value: _minutes,
                  min: 10,
                  max: 120,
                  divisions: 22,
                  label: '${_minutes.round()}',
                  onChanged: (v) => setState(() => _minutes = v),
                ),
              ],
            ]),
          ),
          const SizedBox(height: 14),
          if (!running) ...[
            NeoCard(
              padding: const EdgeInsets.all(14),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('الشجرة',
                        style: heading(20, color: fg)),
                    const SizedBox(height: 8),
                    SizedBox(
                      height: 78,
                      child: ListView(
                        scrollDirection: Axis.horizontal,
                        children: [
                          for (final k in kTrees)
                            if (app.ownedTrees.contains(k.id))
                              GestureDetector(
                                onTap: () {
                                  app.selectedTree = k.id;
                                  app.saveForest();
                                },
                                child: Container(
                                  margin: const EdgeInsetsDirectional.only(end: 8),
                                  padding: const EdgeInsets.all(4),
                                  decoration: BoxDecoration(
                                    color: app.selectedTree == k.id
                                        ? C.yellow
                                        : Colors.transparent,
                                    borderRadius: BorderRadius.circular(14),
                                    border: Border.all(color: fg, width: 2),
                                  ),
                                  child: TreeView(kindId: k.id, size: 64),
                                ),
                              ),
                        ],
                      ),
                    ),
                  ]),
            ),
            const SizedBox(height: 14),
            NeoCard(
              padding: const EdgeInsets.all(14),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('صوت الخلفية', style: heading(20, color: fg)),
                    const SizedBox(height: 8),
                    Wrap(spacing: 8, runSpacing: 4, children: [
                      for (final s in kSounds)
                        ChoiceChip(
                          label: Text('${s.emoji} ${s.label}'),
                          selected: _sound == s.id,
                          onSelected: (_) {
                            setState(() => _sound = s.id);
                            // معاينة سريعة
                            if (s.id == 'none') {
                              ambient.stop();
                            } else {
                              ambient.play(s.id);
                              Future.delayed(const Duration(seconds: 3), () {
                                if (mounted && _mode == _Mode.idle) {
                                  ambient.stop();
                                }
                              });
                            }
                          },
                        ),
                    ]),
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('ركّز على الدراسة',
                          style: TextStyle(fontWeight: FontWeight.w800)),
                      subtitle: const Text(
                          'عملة إضافية لكل 5 إجابات في المراجعة والألعاب أثناء الجلسة'),
                      value: _study,
                      onChanged: (v) => setState(() => _study = v),
                    ),
                  ]),
            ),
            const SizedBox(height: 16),
            NeoButton(
              label: 'ازرع وابدأ التركيز',
              icon: Icons.eco,
              color: C.mint,
              onPressed: _startFocus,
            ),
            const SizedBox(height: 8),
            const Text(
              'إن غادرت التطبيق أكثر من 10 ثوانٍ (أو أطفأت الشاشة) تذبل الشجرة.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12.5),
            ),
          ] else ...[
            if (_mode == _Mode.focus && _study)
              NeoCard(
                color: C.yellow,
                child: Text(
                    'إجابات هذه الجلسة: ${(app.todayAnswers - _startAnswers).clamp(0, 9999).toInt()}',
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontWeight: FontWeight.w900)),
              ),
            const SizedBox(height: 12),
            NeoButton(
              label: _mode == _Mode.focus ? 'توقف (ستذبل الشجرة)' : 'تخطّي الاستراحة',
              icon: _mode == _Mode.focus ? Icons.close : Icons.skip_next,
              color: C.coral,
              onPressed: _mode == _Mode.focus ? _giveUp : _toIdle,
            ),
          ],
        ],
      ),
    );
  }
}
