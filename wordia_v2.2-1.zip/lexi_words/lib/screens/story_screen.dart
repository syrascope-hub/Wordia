import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import '../models.dart';
import '../services/ai_service.dart';
import '../store.dart';
import '../theme.dart';

/// قصة قصيرة يكتبها الذكاء الاصطناعي بكلماتك، والكلمات مظللة وقابلة للنقر.
class StoryScreen extends StatefulWidget {
  const StoryScreen({super.key});

  @override
  State<StoryScreen> createState() => _StoryScreenState();
}

class _StoryScreenState extends State<StoryScreen> {
  late String _lang;
  String _level = 'A2';
  final Set<String> _sel = {};
  bool _busy = false;
  String? _error;
  Story? _story;
  List<Word> _used = [];
  bool _showTr = false;
  Word? _tapped;
  final List<TapGestureRecognizer> _recs = [];

  static const _levels = ['A1', 'A2', 'B1', 'B2'];

  @override
  void initState() {
    super.initState();
    final counts = <String, int>{};
    for (final w in app.words) {
      counts[w.lang] = (counts[w.lang] ?? 0) + 1;
    }
    _lang = counts.containsKey(app.s.defaultLang)
        ? app.s.defaultLang
        : (counts.entries.isEmpty
            ? app.s.defaultLang
            : (counts.entries.toList()
                  ..sort((a, b) => b.value.compareTo(a.value)))
                .first
                .key);
    _autoSelect();
  }

  @override
  void dispose() {
    for (final r in _recs) {
      r.dispose();
    }
    super.dispose();
  }

  List<Word> get _pool => app.words.where((w) => w.lang == _lang).toList();

  /// يفضّل الكلمات الصعبة ثم الأحدث.
  void _autoSelect() {
    final p = _pool
      ..sort((a, b) {
        final c = b.wrong.compareTo(a.wrong);
        return c != 0 ? c : b.createdAt.compareTo(a.createdAt);
      });
    _sel
      ..clear()
      ..addAll(p.take(8).map((w) => w.id));
  }

  Future<void> _generate() async {
    final chosen = _pool.where((w) => _sel.contains(w.id)).toList();
    if (chosen.length < 3) {
      toast(context, 'اختر 3 كلمات على الأقل');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
      _tapped = null;
    });
    try {
      final s = await ai.story(chosen, _lang, _level, app.s);
      if (!mounted) return;
      setState(() {
        _story = s;
        _used = chosen;
        _showTr = false;
      });
    } catch (_) {
      if (mounted) {
        const msg = 'تعذّر توليد القصة. تحقق من الإنترنت وأعد المحاولة.';
        setState(() => _error = msg);
        if (_story != null) toast(context, msg);
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  List<InlineSpan> _spans(String text, TextStyle base) {
    for (final r in _recs) {
      r.dispose();
    }
    _recs.clear();
    final byLower = {for (final w in _used) w.word.trim().toLowerCase(): w};
    if (byLower.isEmpty) return [TextSpan(text: text, style: base)];
    final keys = byLower.keys.toList()..sort((a, b) => b.length.compareTo(a.length));
    final body = keys.map(RegExp.escape).join('|');
    final cjk = RegExp(r'[\u3040-\u30ff\u3400-\u9fff\uac00-\ud7af]');
    final pattern = keys.any(cjk.hasMatch)
        ? body
        : r'(?<![\p{L}\p{N}])(?:' + body + r')(?![\p{L}\p{N}])';
    final re = RegExp(pattern, caseSensitive: false, unicode: true);
    final spans = <InlineSpan>[];
    var last = 0;
    for (final m in re.allMatches(text)) {
      if (m.start > last) {
        spans.add(TextSpan(text: text.substring(last, m.start), style: base));
      }
      final word = byLower[m.group(0)!.toLowerCase()];
      final rec = TapGestureRecognizer()
        ..onTap = () {
          setState(() => _tapped = word);
          if (word != null) speakText(word.word, word.language);
        };
      _recs.add(rec);
      spans.add(TextSpan(
        text: m.group(0),
        recognizer: rec,
        style: base.copyWith(
          backgroundColor: C.yellow,
          color: C.ink,
          fontWeight: FontWeight.w900,
        ),
      ));
      last = m.end;
    }
    if (last < text.length) spans.add(TextSpan(text: text.substring(last), style: base));
    return spans;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: isDark(context) ? C.darkBg : C.yellow,
      appBar: AppBar(title: const Text('قصة بكلماتك')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
        children: [
          if (_story == null || _busy) _setup() else _storyView(),
        ],
      ),
    );
  }

  Widget _setup() {
    final langsWithWords = kLangs
        .where((l) => app.words.any((w) => w.lang == l.code))
        .toList();
    final pool = _pool;
    if (app.words.length < 3) {
      return NeoCard(
        padding: const EdgeInsets.all(20),
        child: const Text('أضف 3 كلمات على الأقل ثم عُد لتولّد قصتك.',
            style: TextStyle(fontWeight: FontWeight.w800)),
      );
    }
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      NeoCard(
        color: C.mint,
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('اللغة والمستوى', style: heading(22, color: C.ink)),
          const SizedBox(height: 10),
          InputDecorator(
            decoration: const InputDecoration(
                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 2)),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: langsWithWords.any((l) => l.code == _lang)
                    ? _lang
                    : langsWithWords.first.code,
                isExpanded: true,
                items: [
                  for (final l in langsWithWords)
                    DropdownMenuItem(
                        value: l.code, child: Text('${l.flag}  ${l.name}')),
                ],
                onChanged: (v) {
                  if (v == null) return;
                  setState(() {
                    _lang = v;
                    _autoSelect();
                  });
                },
              ),
            ),
          ),
          const SizedBox(height: 10),
          Wrap(spacing: 8, children: [
            for (final l in _levels)
              ChoiceChip(
                label: Text(l),
                selected: _level == l,
                onSelected: (_) => setState(() => _level = l),
              ),
          ]),
        ]),
      ),
      const SizedBox(height: 16),
      NeoCard(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(
                child: Text('اختر الكلمات (${_sel.length})',
                    style: heading(22))),
            TextButton(
                onPressed: () => setState(_autoSelect),
                child: const Text('اقتراح تلقائي')),
          ]),
          const SizedBox(height: 6),
          Wrap(spacing: 6, runSpacing: 2, children: [
            for (final w in pool.take(60))
              FilterChip(
                label: Text(w.word),
                selected: _sel.contains(w.id),
                onSelected: (v) => setState(() {
                  if (v) {
                    if (_sel.length < 12) _sel.add(w.id);
                  } else {
                    _sel.remove(w.id);
                  }
                }),
              ),
          ]),
        ]),
      ),
      if (_error != null)
        Padding(
          padding: const EdgeInsets.only(top: 12),
          child: Text(_error!, style: const TextStyle(color: Colors.redAccent)),
        ),
      const SizedBox(height: 16),
      NeoButton(
        label: 'اكتب لي قصة',
        icon: Icons.auto_stories,
        busy: _busy,
        onPressed: _generate,
      ),
    ]);
  }

  Widget _storyView() {
    final s = _story!;
    final l = langOf(_lang);
    final base = TextStyle(
      fontFamily: 'Tajawal',
      fontSize: 22,
      height: 1.7,
      fontWeight: FontWeight.w700,
      color: isDark(context) ? Colors.white : C.ink,
    );
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      NeoCard(
        padding: const EdgeInsets.all(18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(
              child: Directionality(
                textDirection: langDir(l),
                child: Text(s.title.isEmpty ? '…' : s.title,
                    style: heading(28, color: isDark(context) ? Colors.white : C.ink)),
              ),
            ),
            SpeakButton(text: s.text, lang: l, size: 46),
          ]),
          const SizedBox(height: 12),
          Directionality(
            textDirection: langDir(l),
            child: Text.rich(TextSpan(children: _spans(s.text, base))),
          ),
          if (_showTr && s.translation.isNotEmpty) ...[
            const Divider(height: 28, thickness: 2),
            Text(s.translation,
                style: TextStyle(
                    fontSize: 17,
                    height: 1.6,
                    color: isDark(context) ? Colors.white70 : Colors.black87)),
          ],
        ]),
      ),
      if (_tapped != null) ...[
        const SizedBox(height: 14),
        NeoCard(
          color: C.mint,
          padding: const EdgeInsets.all(14),
          child: Row(children: [
            Text(_tapped!.language.flag, style: const TextStyle(fontSize: 24)),
            const SizedBox(width: 10),
            Expanded(
              child: Text('${_tapped!.word}  =  ${_tapped!.translation}',
                  style: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.w900)),
            ),
          ]),
        ),
      ],
      const SizedBox(height: 16),
      Row(children: [
        Expanded(
          child: NeoButton(
            label: _showTr ? 'إخفاء الترجمة' : 'إظهار الترجمة',
            icon: Icons.translate,
            color: C.blue,
            onPressed: () => setState(() => _showTr = !_showTr),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: NeoButton(
            label: 'قصة جديدة',
            icon: Icons.refresh,
            color: C.coral,
            onPressed: _generate,
          ),
        ),
      ]),
      const SizedBox(height: 12),
      NeoButton(
        label: 'تغيير الكلمات',
        icon: Icons.tune,
        color: C.pink,
        onPressed: () => setState(() => _story = null),
      ),
    ]);
  }
}
