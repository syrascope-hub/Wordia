import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models.dart';
import '../services/ai_service.dart';
import '../store.dart';
import '../theme.dart';
import 'quiz_screen.dart';
import 'settings_screen.dart';
import 'study_widgets.dart';

/// يدمج المواد المختارة في نص واحد لا يتجاوز [budget] حرفاً.
/// المادة الطويلة تُؤخذ منها ثلاث نوافذ موزّعة (بداية ووسط ونهاية)
/// حتى يغطي الاختبار المادة كلها لا أولها فقط.
String combineMaterials(List<StudyMaterial> ms, {int budget = 11500}) {
  if (ms.isEmpty) return '';
  final per = budget ~/ ms.length;
  final b = StringBuffer();
  for (final m in ms) {
    final t = m.text.trim();
    if (ms.length > 1) b.writeln('## ${m.title}');
    if (t.length <= per) {
      b.writeln(t);
    } else {
      final w = per ~/ 3;
      final mid = (t.length - w) ~/ 2;
      b.writeln(t.substring(0, w));
      b.writeln('…');
      b.writeln(t.substring(mid, mid + w));
      b.writeln('…');
      b.writeln(t.substring(t.length - w));
    }
    b.writeln();
  }
  return b.toString().trim();
}

class SubjectDraft {
  final String title;
  final String emoji;
  final int color;
  const SubjectDraft(this.title, this.emoji, this.color);
}

/// نافذة إنشاء مقرّر أو تعديله (الاسم والأيقونة واللون).
Future<SubjectDraft?> showSubjectDialog(BuildContext context, {Subject? edit}) {
  final ctrl = TextEditingController(text: edit?.title ?? '');
  var emoji = edit?.emoji ?? kSubjectEmojis.first;
  var color = edit?.color ?? 0;
  return showDialog<SubjectDraft>(
    context: context,
    builder: (c) => StatefulBuilder(
      builder: (c, set) => AlertDialog(
        title: Text(edit == null ? 'مادة جديدة' : 'تعديل المادة'),
        content: SingleChildScrollView(
          child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  controller: ctrl,
                  autofocus: true,
                  decoration: const InputDecoration(
                      labelText: 'اسم المادة', hintText: 'مثال: الأحياء'),
                ),
                const SizedBox(height: 16),
                const Text('الأيقونة',
                    style: TextStyle(fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                Wrap(spacing: 8, runSpacing: 8, children: [
                  for (final e in kSubjectEmojis)
                    GestureDetector(
                      onTap: () => set(() => emoji = e),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        width: 44,
                        height: 44,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: emoji == e ? C.yellow : Colors.transparent,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                              color: emoji == e ? C.ink : Colors.grey,
                              width: 2),
                        ),
                        child: Text(e, style: const TextStyle(fontSize: 22)),
                      ),
                    ),
                ]),
                const SizedBox(height: 16),
                const Text('اللون',
                    style: TextStyle(fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                Wrap(spacing: 10, runSpacing: 8, children: [
                  for (var i = 0; i < kSubjectColors.length; i++)
                    GestureDetector(
                      onTap: () => set(() => color = i),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        width: 38,
                        height: 38,
                        decoration: BoxDecoration(
                          color: kSubjectColors[i],
                          shape: BoxShape.circle,
                          border: Border.all(
                              color: color == i ? C.ink : Colors.grey,
                              width: color == i ? 3.5 : 1.5),
                        ),
                      ),
                    ),
                ]),
              ]),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c), child: const Text('إلغاء')),
          TextButton(
            onPressed: () {
              final t = ctrl.text.trim();
              if (t.isEmpty) return;
              Navigator.pop(c, SubjectDraft(t, emoji, color));
            },
            child: const Text('حفظ'),
          ),
        ],
      ),
    ),
  );
}

String _firstLine(String t, {int max = 40}) {
  final first = t.split(RegExp(r'[\r\n]+')).first.trim();
  if (first.isEmpty) return 'مادة بلا عنوان';
  return first.length > max ? '${first.substring(0, max)}…' : first;
}

// ======================= قائمة المقرّرات =======================

/// تبويب «موادي»: مقرّراتك الدراسية، ومن كل مقرّر تولّد اختبارات من مواده.
class SubjectsScreen extends StatelessWidget {
  const SubjectsScreen({super.key});

  Future<void> _create(BuildContext context) async {
    final d = await showSubjectDialog(context);
    if (d == null || !context.mounted) return;
    final sub = app.addSubject(d.title, d.emoji, d.color);
    Navigator.push(context, fadeSlide(SubjectPage(subjectId: sub.id)));
  }

  @override
  Widget build(BuildContext context) {
    final dark = isDark(context);
    final fg = dark ? Colors.white : C.ink;
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final subs = app.subjects;
        return Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            title: const Text('موادي الدراسية'),
            actions: [
              IconButton(
                tooltip: 'الإعدادات',
                icon: const Icon(Icons.settings_outlined),
                onPressed: () => openSettings(context),
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
            children: [
              const AiKeyBanner(),
              NeoButton(
                label: 'مادة جديدة',
                icon: Icons.add_rounded,
                color: C.coral,
                onPressed: () => _create(context),
              ),
              const SizedBox(height: 16),
              if (subs.isEmpty)
                NeoCard(
                  padding: const EdgeInsets.all(20),
                  child: Column(children: [
                    const PopIn(
                        child: Text('📚', style: TextStyle(fontSize: 56))),
                    const SizedBox(height: 10),
                    Text('ابدأ بمادتك الأولى', style: heading(24, color: fg)),
                    const SizedBox(height: 8),
                    Text(
                      '١) أنشئ مادة (مثل: الأحياء)\n'
                      '٢) أضف موادها: الصق ملخصاً أو صوّر صفحة من الكتاب\n'
                      '٣) اضغط «أنشئ الاختبار» ليولّده الذكاء الاصطناعي من محتواك',
                      style: TextStyle(height: 1.8, color: fg),
                    ),
                  ]),
                )
              else
                for (var i = 0; i < subs.length; i++)
                  Appear(
                    key: ValueKey(subs[i].id),
                    index: i,
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: _SubjectCard(sub: subs[i]),
                    ),
                  ),
            ],
          ),
        );
      },
    );
  }
}

class _SubjectCard extends StatelessWidget {
  final Subject sub;
  const _SubjectCard({required this.sub});

  @override
  Widget build(BuildContext context) {
    final color = kSubjectColors[sub.color % kSubjectColors.length];
    final quizzes = app.quizzesOf(sub.id).length;
    final avg = app.avgScoreOf(sub.id);
    return NeoCard(
      color: color,
      padding: const EdgeInsets.all(14),
      onTap: () =>
          Navigator.push(context, fadeSlide(SubjectPage(subjectId: sub.id))),
      child: Row(children: [
        Container(
          width: 56,
          height: 56,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: Colors.white,
            shape: BoxShape.circle,
            border: Border.all(color: C.ink, width: 2),
          ),
          child: Text(sub.emoji, style: const TextStyle(fontSize: 28)),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(sub.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: heading(24, color: C.ink)),
                const SizedBox(height: 2),
                Text('${sub.materials.length} مادة  •  $quizzes اختبار',
                    style: const TextStyle(fontWeight: FontWeight.w700)),
              ]),
        ),
        if (avg >= 0)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: C.ink, width: 2),
            ),
            child: Text('$avg٪',
                style: const TextStyle(
                    fontWeight: FontWeight.w900, color: C.ink)),
          ),
        const Icon(Icons.chevron_left),
      ]),
    );
  }
}

// ======================= صفحة المقرّر =======================

class SubjectPage extends StatefulWidget {
  final String subjectId;
  const SubjectPage({super.key, required this.subjectId});

  @override
  State<SubjectPage> createState() => _SubjectPageState();
}

class _SubjectPageState extends State<SubjectPage> {
  final Set<String> _sel = {}; // فارغ = كل المواد
  String _mode = 'mcq'; // mcq | solve | explain
  int _count = 10;
  String _level = 'متوسط';
  bool _qAr = false;
  bool _busy = false;
  String? _error;
  String? _explain;

  static const _modes = {
    'mcq': '📝 اختبار',
    'solve': '🧮 حل مسائل',
    'explain': '💡 شرح',
  };

  Future<void> _edit(Subject sub) async {
    final d = await showSubjectDialog(context, edit: sub);
    if (d == null) return;
    sub.title = d.title;
    sub.emoji = d.emoji;
    sub.color = d.color;
    app.updateSubject(sub);
  }

  Future<void> _delete(Subject sub) async {
    final ok = await confirm(context, 'حذف المادة',
        'سيتم حذف «${sub.title}» مع كل موادها واختباراتها نهائياً.',
        ok: 'حذف');
    if (!ok || !mounted) return;
    Navigator.pop(context);
    app.removeSubject(sub.id);
  }

  void _openEditor(Subject sub, {StudyMaterial? m}) {
    Navigator.push(
        context,
        fadeSlide(MaterialEditorPage(subjectId: sub.id, materialId: m?.id)));
  }

  Future<void> _run(Subject sub) async {
    FocusScope.of(context).unfocus();
    final used = sub.materials
        .where((m) => _sel.isEmpty || _sel.contains(m.id))
        .toList();
    final text = combineMaterials(used);
    if (text.length < 30) {
      setState(() => _error = 'أضف مادة نصية أولاً (30 حرفاً على الأقل).');
      return;
    }
    final all = used.length == sub.materials.length;
    final scope = all ? 'كل المواد' : used.map((m) => m.title).join('، ');
    var title = '${sub.emoji} ${sub.title} • $scope';
    if (title.length > 70) title = '${title.substring(0, 70)}…';
    setState(() {
      _busy = true;
      _error = null;
      _explain = null;
    });
    try {
      if (_mode == 'mcq') {
        final items = await ai.makeQuiz(text,
            count: _count, level: _level, arabicQ: _qAr, s: app.s);
        final qs = QuizSet(
            id: app.newId(),
            ts: DateTime.now().millisecondsSinceEpoch,
            title: title,
            mode: 'mcq',
            items: items,
            subjectId: sub.id);
        app.addQuiz(qs);
        if (!mounted) return;
        await Navigator.push(context, fadeSlide(QuizPlayPage(qs: qs)));
      } else if (_mode == 'solve') {
        final solves = await ai.solveProblems(text, app.s);
        final qs = QuizSet(
            id: app.newId(),
            ts: DateTime.now().millisecondsSinceEpoch,
            title: title,
            mode: 'solve',
            solves: solves,
            subjectId: sub.id);
        app.addQuiz(qs);
        if (!mounted) return;
        await Navigator.push(context, fadeSlide(SolvePage(qs: qs)));
      } else {
        final ex = await ai.explainText(text, app.s);
        if (mounted) setState(() => _explain = ex);
      }
    } catch (e) {
      if (mounted) {
        final msg = e.toString().replaceFirst('Exception: ', '');
        setState(() => _error = msg.startsWith('لم ')
            ? msg
            : 'تعذّرت العملية. تحقق من الإنترنت ومن مفتاح الذكاء الاصطناعي في الإعدادات.');
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _openQuiz(QuizSet q) {
    Navigator.push(context,
        fadeSlide(q.mode == 'mcq' ? QuizPlayPage(qs: q) : SolvePage(qs: q)));
  }

  @override
  Widget build(BuildContext context) {
    final dark = isDark(context);
    final fg = dark ? Colors.white : C.ink;
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final sub = app.subjectById(widget.subjectId);
        if (sub == null) {
          return Scaffold(
            appBar: AppBar(),
            body: const Center(child: Text('تم حذف هذه المادة')),
          );
        }
        _sel.removeWhere((id) => !sub.materials.any((m) => m.id == id));
        final tint = kSubjectColors[sub.color % kSubjectColors.length];
        final hist = app.quizzesOf(sub.id);
        final avg = app.avgScoreOf(sub.id);
        final nUsed = _sel.isEmpty ? sub.materials.length : _sel.length;
        return Scaffold(
          backgroundColor: dark ? C.darkBg : tint,
          appBar: AppBar(
            title: Text('${sub.emoji} ${sub.title}'),
            actions: [
              IconButton(
                tooltip: 'تعديل المادة',
                icon: const Icon(Icons.edit_outlined),
                onPressed: () => _edit(sub),
              ),
              IconButton(
                tooltip: 'حذف المادة',
                icon: const Icon(Icons.delete_outline),
                onPressed: () => _delete(sub),
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
            children: [
              const AiKeyBanner(),
              Appear(
                child: NeoCard(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  child: Row(children: [
                    _stat('المواد', sub.materials.length, ''),
                    _stat('الاختبارات', hist.length, ''),
                    _stat('المتوسط', avg < 0 ? 0 : avg, avg < 0 ? '' : '٪',
                        dash: avg < 0),
                  ]),
                ),
              ),
              const SizedBox(height: 18),
              Row(children: [
                Expanded(
                    child: Text('المواد', style: heading(24, color: fg))),
                if (sub.materials.length > 1 && _sel.isNotEmpty)
                  TextButton(
                    onPressed: () => setState(_sel.clear),
                    child: const Text('استخدم الكل'),
                  ),
              ]),
              const SizedBox(height: 6),
              NeoButton(
                label: 'إضافة مادة',
                icon: Icons.note_add_outlined,
                color: C.mint,
                onPressed: () => _openEditor(sub),
              ),
              const SizedBox(height: 12),
              if (sub.materials.isEmpty)
                const NeoCard(
                  padding: EdgeInsets.all(16),
                  child: Text(
                      'لا توجد مواد بعد. أضف أول مادة: الصق ملخصك أو صوّر صفحة '
                      'من الكتاب، ثم اضغط «أنشئ الاختبار».',
                      style: TextStyle(height: 1.6)),
                )
              else ...[
                for (var i = 0; i < sub.materials.length; i++)
                  _materialTile(sub, sub.materials[i], i),
                Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Text(
                      _sel.isEmpty
                          ? 'سيُستخدم كل المواد. اضغط على مادة لتحديدها فقط.'
                          : 'المحدد: $nUsed من ${sub.materials.length}',
                      style: TextStyle(fontSize: 12.5, color: fg)),
                ),
              ],
              if (sub.materials.isNotEmpty) ...[
                const SizedBox(height: 14),
                _generatePanel(sub),
              ],
              if (_error != null)
                Padding(
                  padding: const EdgeInsets.only(top: 12),
                  child: NeoCard(
                    color: const Color(0xFFFFC9C0),
                    child: Text(_error!,
                        style: const TextStyle(fontWeight: FontWeight.w800)),
                  ),
                ),
              if (_explain != null && !_busy) ...[
                const SizedBox(height: 14),
                Appear(
                  child: NeoCard(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Directionality(
                            textDirection: autoDir(_explain!),
                            child: SelectableText.rich(
                              TextSpan(
                                  children: mdSpans(
                                      _explain!,
                                      TextStyle(
                                          fontSize: 16,
                                          height: 1.6,
                                          color: fg))),
                            ),
                          ),
                          const SizedBox(height: 10),
                          Row(children: [
                            Expanded(
                              child: NeoButton(
                                label: 'نسخ',
                                icon: Icons.copy,
                                color: C.blue,
                                onPressed: () {
                                  Clipboard.setData(
                                      ClipboardData(text: _explain!));
                                  toast(context, 'تم النسخ');
                                },
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: NeoButton(
                                label: 'حوّله لاختبار',
                                icon: Icons.quiz,
                                color: C.mint,
                                onPressed: () {
                                  setState(() => _mode = 'mcq');
                                  _run(sub);
                                },
                              ),
                            ),
                          ]),
                        ]),
                  ),
                ),
              ],
              if (hist.isNotEmpty) ...[
                const SizedBox(height: 22),
                Text('اختبارات هذه المادة', style: heading(24, color: fg)),
                const SizedBox(height: 8),
                for (var i = 0; i < hist.length; i++)
                  Appear(
                    key: ValueKey(hist[i].id),
                    index: i,
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: _quizTile(hist[i]),
                    ),
                  ),
              ],
            ],
          ),
        );
      },
    );
  }

  Widget _stat(String label, int v, String suffix, {bool dash = false}) {
    return Expanded(
      child: Column(children: [
        dash
            ? Text('—', style: heading(28))
            : CountUp(value: v, suffix: suffix, style: heading(28)),
        const SizedBox(height: 2),
        Text(label,
            style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700)),
      ]),
    );
  }

  Widget _materialTile(Subject sub, StudyMaterial m, int i) {
    final dark = isDark(context);
    final sel = _sel.contains(m.id);
    final ring = (dark && !sel) ? Colors.white70 : C.ink;
    return Appear(
      key: ValueKey(m.id),
      index: i,
      child: Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: NeoCard(
          color: sel ? C.yellow : null,
          padding: const EdgeInsets.fromLTRB(12, 10, 4, 10),
          onTap: () => setState(() {
            if (!_sel.remove(m.id)) _sel.add(m.id);
          }),
          child: Row(children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              curve: Curves.easeOutBack,
              width: 26,
              height: 26,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: sel ? C.coral : Colors.transparent,
                border: Border.all(color: ring, width: 2),
              ),
              child: AnimatedScale(
                scale: sel ? 1 : 0,
                duration: const Duration(milliseconds: 220),
                curve: Curves.easeOutBack,
                child: const Icon(Icons.check, size: 16, color: C.ink),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(m.title.isEmpty ? 'مادة بلا عنوان' : m.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontWeight: FontWeight.w900, fontSize: 16)),
                    const SizedBox(height: 2),
                    Text(m.text.replaceAll(RegExp(r'\s+'), ' '),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        textDirection: autoDir(m.text),
                        style: const TextStyle(fontSize: 12.5, height: 1.4)),
                    const SizedBox(height: 2),
                    Text('${m.text.length} حرف',
                        style: const TextStyle(fontSize: 11.5)),
                  ]),
            ),
            PopupMenuButton<String>(
              onSelected: (v) async {
                if (v == 'edit') {
                  _openEditor(sub, m: m);
                } else if (v == 'del') {
                  if (await confirm(context, 'حذف المادة النصية',
                      'حذف «${m.title}»؟',
                      ok: 'حذف')) {
                    _sel.remove(m.id);
                    app.removeMaterial(sub, m.id);
                  }
                }
              },
              itemBuilder: (c) => const [
                PopupMenuItem(value: 'edit', child: Text('عرض / تعديل')),
                PopupMenuItem(value: 'del', child: Text('حذف')),
              ],
            ),
          ]),
        ),
      ),
    );
  }

  Widget _generatePanel(Subject sub) {
    return NeoCard(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('ماذا تريد من هذه المواد؟',
            style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 4, children: [
          for (final e in _modes.entries)
            ChoiceChip(
              label: Text(e.value),
              selected: _mode == e.key,
              onSelected: _busy ? null : (_) => setState(() => _mode = e.key),
            ),
        ]),
        AnimatedSize(
          duration: const Duration(milliseconds: 260),
          curve: Curves.easeOut,
          alignment: Alignment.topCenter,
          child: _mode != 'mcq'
              ? const SizedBox(width: double.infinity)
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 12),
                    const Text('عدد الأسئلة',
                        style: TextStyle(fontWeight: FontWeight.w900)),
                    const SizedBox(height: 6),
                    Wrap(spacing: 8, children: [
                      for (final n in const [5, 10, 15])
                        ChoiceChip(
                          label: Text('$n'),
                          selected: _count == n,
                          onSelected:
                              _busy ? null : (_) => setState(() => _count = n),
                        ),
                    ]),
                    const SizedBox(height: 10),
                    const Text('المستوى',
                        style: TextStyle(fontWeight: FontWeight.w900)),
                    const SizedBox(height: 6),
                    Wrap(spacing: 8, children: [
                      for (final l in const ['سهل', 'متوسط', 'صعب'])
                        ChoiceChip(
                          label: Text(l),
                          selected: _level == l,
                          onSelected:
                              _busy ? null : (_) => setState(() => _level = l),
                        ),
                    ]),
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      value: _qAr,
                      onChanged: _busy ? null : (v) => setState(() => _qAr = v),
                      title: const Text('الأسئلة بالعربية'),
                      subtitle: const Text('وإلا فبلغة النص نفسها'),
                    ),
                  ]),
        ),
        const SizedBox(height: 12),
        NeoButton(
          label: switch (_mode) {
            'solve' => 'حلّ المسائل',
            'explain' => 'اشرح المواد',
            _ => 'أنشئ الاختبار',
          },
          icon: Icons.auto_awesome,
          color: C.coral,
          busy: _busy,
          onPressed: () => _run(sub),
        ),
      ]),
    );
  }

  Widget _quizTile(QuizSet q) {
    return NeoCard(
      padding: const EdgeInsets.all(12),
      onTap: () => _openQuiz(q),
      child: Row(children: [
        Text(q.mode == 'mcq' ? '📝' : '🧮', style: const TextStyle(fontSize: 26)),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(q.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w800)),
                Text(
                    q.mode == 'mcq'
                        ? '${q.items.length} سؤال'
                            '${q.lastScore >= 0 ? ' • آخر نتيجة ${q.lastScore}٪' : ''}'
                        : '${q.solves.length} مسألة',
                    style: const TextStyle(fontSize: 12.5)),
              ]),
        ),
        IconButton(
          tooltip: 'ورقة عمل',
          icon: const Icon(Icons.print_outlined),
          onPressed: () => exportWorksheet(context, q),
        ),
        IconButton(
          icon: const Icon(Icons.delete_outline),
          onPressed: () => app.removeQuiz(q.id),
        ),
      ]),
    );
  }
}

// ======================= إضافة/تعديل مادة نصية =======================

class MaterialEditorPage extends StatefulWidget {
  final String subjectId;
  final String? materialId;
  const MaterialEditorPage({super.key, required this.subjectId, this.materialId});

  @override
  State<MaterialEditorPage> createState() => _MaterialEditorPageState();
}

class _MaterialEditorPageState extends State<MaterialEditorPage> {
  late final TextEditingController _title;
  late final TextEditingController _text;
  StudyMaterial? _m;

  @override
  void initState() {
    super.initState();
    final sub = app.subjectById(widget.subjectId);
    if (sub != null && widget.materialId != null) {
      for (final m in sub.materials) {
        if (m.id == widget.materialId) _m = m;
      }
    }
    _title = TextEditingController(text: _m?.title ?? '');
    _text = TextEditingController(text: _m?.text ?? '');
  }

  @override
  void dispose() {
    _title.dispose();
    _text.dispose();
    super.dispose();
  }

  void _onSource(String t) {
    final cur = _text.text.trim();
    setState(() => _text.text = cur.isEmpty ? t : '$cur\n\n$t');
  }

  void _save() {
    final sub = app.subjectById(widget.subjectId);
    if (sub == null) return;
    var t = _text.text.trim();
    if (t.length < 10) {
      toast(context, 'اكتب أو الصق نصاً أطول');
      return;
    }
    var cut = false;
    if (t.length > kMaxMaterialChars) {
      t = t.substring(0, kMaxMaterialChars);
      cut = true;
    }
    var title = _title.text.trim();
    if (title.isEmpty) title = _firstLine(t);
    if (_m != null) {
      _m!.title = title;
      _m!.text = t;
      app.materialsChanged();
    } else {
      app.addMaterial(sub, title, t);
    }
    if (cut) {
      toast(context, 'اقتُطع النص إلى $kMaxMaterialChars حرف');
    }
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final dark = isDark(context);
    final sub = app.subjectById(widget.subjectId);
    final tint = sub == null
        ? kLavender
        : kSubjectColors[sub.color % kSubjectColors.length];
    return Scaffold(
      backgroundColor: dark ? C.darkBg : tint,
      appBar: AppBar(title: Text(_m == null ? 'مادة جديدة' : 'تعديل المادة')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
        children: [
          NeoCard(
            padding: const EdgeInsets.all(16),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              TextField(
                controller: _title,
                decoration: const InputDecoration(
                    labelText: 'عنوان المادة (اختياري)',
                    hintText: 'مثال: الفصل الثالث، ملخص الدرس'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _text,
                minLines: 8,
                maxLines: 16,
                textDirection: autoDir(_text.text),
                onChanged: (_) => setState(() {}),
                decoration: const InputDecoration(
                    hintText: 'الصق نص المادة هنا، أو استخدم الأزرار بالأسفل…'),
              ),
              const SizedBox(height: 4),
              Text('${_text.text.length} / $kMaxMaterialChars حرف',
                  style: const TextStyle(fontSize: 12)),
            ]),
          ),
          const SizedBox(height: 14),
          NeoCard(
            color: C.yellow,
            padding: const EdgeInsets.all(16),
            child: SourceBar(onText: _onSource),
          ),
          const SizedBox(height: 14),
          NeoButton(
            label: 'حفظ المادة',
            icon: Icons.check_rounded,
            color: C.coral,
            onPressed: _save,
          ),
        ],
      ),
    );
  }
}
