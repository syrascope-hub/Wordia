import 'package:flutter/material.dart';

import '../theme.dart';
import 'games_screen.dart';
import 'quiz_screen.dart';
import 'review_screen.dart';
import 'subjects_screen.dart';
import 'words_screen.dart';

/// قسم بتبويبات فرعية: شريط انزلاقي في الأعلى، والمحتوى يحتفظ بحالته
/// (IndexedStack) مع انتقال تلاشي/انزلاق عند التبديل.
class TabHub extends StatefulWidget {
  final List<String> labels;
  final List<IconData> icons;
  final List<Widget> pages;
  const TabHub(
      {super.key,
      required this.labels,
      required this.icons,
      required this.pages});

  @override
  State<TabHub> createState() => _TabHubState();
}

class _TabHubState extends State<TabHub> with SingleTickerProviderStateMixin {
  int _i = 0;
  late final AnimationController _c = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 280),
      value: 1);
  late final Animation<double> _a =
      CurvedAnimation(parent: _c, curve: Curves.easeOutCubic);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  void _go(int v) {
    if (v == _i) return;
    FocusManager.instance.primaryFocus?.unfocus();
    setState(() => _i = v);
    _c.forward(from: 0);
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      PillTabs(
          labels: widget.labels,
          icons: widget.icons,
          index: _i,
          onChanged: _go),
      Expanded(
        child: FadeTransition(
          opacity: _a,
          child: SlideTransition(
            position: Tween<Offset>(
                    begin: const Offset(0, 0.025), end: Offset.zero)
                .animate(_a),
            child: IndexedStack(index: _i, children: widget.pages),
          ),
        ),
      ),
    ]);
  }
}

/// قسم Flashcards: كلماتي، المراجعة، الألعاب.
class FlashcardsHub extends StatelessWidget {
  const FlashcardsHub({super.key});

  @override
  Widget build(BuildContext context) => const TabHub(
        labels: ['كلماتي', 'مراجعة', 'ألعاب'],
        icons: [Icons.style_outlined, Icons.psychology_outlined, Icons.sports_esports_outlined],
        pages: [WordsScreen(), ReviewScreen(), GamesScreen()],
      );
}

/// قسم Study: موادي الدراسية (اختبارات من محتواها) + اختبار سريع من نص.
class StudyHub extends StatelessWidget {
  const StudyHub({super.key});

  @override
  Widget build(BuildContext context) => const TabHub(
        labels: ['موادي', 'اختبار سريع'],
        icons: [Icons.menu_book_outlined, Icons.bolt_outlined],
        pages: [SubjectsScreen(), QuizScreen()],
      );
}
