import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models.dart';
import '../services/ai_service.dart';
import '../store.dart';
import '../theme.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _ctrl = TextEditingController();
  final _scroll = ScrollController();
  bool _busy = false;

  static const _quick = [
    'اختبرني بخمس كلمات من قائمتي',
    'اكتب قصة قصيرة بكلماتي',
    'اشرح لي الفرق بين make و do',
    'صحّح لي هذه الجملة: I goed to school',
  ];

  @override
  void initState() {
    super.initState();
    app.tab.addListener(_onTab);
  }

  @override
  void dispose() {
    app.tab.removeListener(_onTab);
    _ctrl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _onTab() {
    if (app.tab.value == kTabChat && app.chatPrefill != null) {
      _ctrl.text = app.chatPrefill!;
      app.chatPrefill = null;
      setState(() {});
    }
  }

  void _toBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(_scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      }
    });
  }

  Future<void> _send([String? preset]) async {
    final text = (preset ?? _ctrl.text).trim();
    if (text.isEmpty || _busy) return;
    _ctrl.clear();
    app.removeLastError();
    app.addChat(ChatMsg('user', text));
    await _ask();
  }

  Future<void> _ask() async {
    setState(() => _busy = true);
    _toBottom();
    try {
      final hist = app.chat.where((m) => !m.error).toList();
      final recent = hist.length > 14 ? hist.sublist(hist.length - 14) : hist;
      final msgs = <Map<String, String>>[
        {'role': 'system', 'content': ai.systemPrompt(app.words)},
        for (final m in recent) {'role': m.role, 'content': m.text},
      ];
      final r = await ai.chat(msgs, s: app.s);
      app.addChat(ChatMsg('assistant', r.text));
    } catch (e) {
      app.addChat(ChatMsg(
          'assistant', 'تعذّر الاتصال بالذكاء الاصطناعي. تحقق من الإنترنت.',
          error: true));
    } finally {
      if (mounted) setState(() => _busy = false);
      _toBottom();
    }
  }

  Future<void> _retry() async {
    if (_busy) return;
    app.removeLastError();
    await _ask();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final msgs = app.chat;
        return Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            title: const Text('المساعد الذكي'),
            actions: [
              IconButton(
                tooltip: 'مسح المحادثة',
                icon: const Icon(Icons.delete_sweep_outlined),
                onPressed: msgs.isEmpty
                    ? null
                    : () async {
                        if (await confirm(context, 'مسح المحادثة',
                            'سيتم حذف كل الرسائل. متأكد؟',
                            ok: 'مسح')) {
                          app.clearChat();
                        }
                      },
              ),
            ],
          ),
          body: Column(children: [
            Expanded(
              child: msgs.isEmpty && !_busy
                  ? _emptyState()
                  : ListView.builder(
                      controller: _scroll,
                      padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
                      itemCount: msgs.length + (_busy ? 1 : 0),
                      itemBuilder: (c, i) {
                        if (i >= msgs.length) return _typing();
                        return _bubble(msgs[i], i == msgs.length - 1);
                      },
                    ),
            ),
            _input(),
          ]),
        );
      },
    );
  }

  Widget _emptyState() {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const SizedBox(height: 24),
        const Center(child: Text('🤖', style: TextStyle(fontSize: 56))),
        const SizedBox(height: 8),
        const Center(
          child: Text('اسألني أي شيء عن اللغة',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
        ),
        const SizedBox(height: 24),
        for (final q in _quick)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: NeoCard(
              color: C.yellow,
              onTap: () => _send(q),
              child: SizedBox(
                  width: double.infinity,
                  child: Text(q,
                      style: const TextStyle(fontWeight: FontWeight.w800))),
            ),
          ),
      ],
    );
  }

  Widget _typing() {
    return const Align(
      alignment: AlignmentDirectional.centerEnd,
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: 8),
        child: SizedBox(
            width: 22,
            height: 22,
            child: CircularProgressIndicator(strokeWidth: 2.5)),
      ),
    );
  }

  /// عرض مبسّط لماركداون ردود الذكاء الاصطناعي: **عريض**، `كود`، عناوين #، ونقاط.
  /// (كانت النجوم والعلامات تظهر حرفياً داخل الفقاعة.)
  List<InlineSpan> _md(String text, TextStyle base) {
    final out = <InlineSpan>[];
    final lines = text.split('\n');
    final re = RegExp(r'\*\*(.+?)\*\*|`([^`]+)`');
    for (var li = 0; li < lines.length; li++) {
      var line = lines[li];
      var style = base;
      final h = RegExp(r'^\s{0,3}#{1,6}\s+').firstMatch(line);
      if (h != null) {
        line = line.substring(h.end);
        style = base.copyWith(fontWeight: FontWeight.w900, fontSize: 17);
      }
      line = line.replaceFirstMapped(
          RegExp(r'^(\s*)[-*]\s+'), (m) => '${m.group(1)}• ');
      var last = 0;
      for (final m in re.allMatches(line)) {
        if (m.start > last) {
          out.add(TextSpan(text: line.substring(last, m.start), style: style));
        }
        if (m.group(1) != null) {
          out.add(TextSpan(
              text: m.group(1),
              style: style.copyWith(fontWeight: FontWeight.w900)));
        } else {
          out.add(TextSpan(
              text: m.group(2),
              style: style.copyWith(
                  fontFamily: 'monospace', backgroundColor: Colors.black12)));
        }
        last = m.end;
      }
      if (last < line.length) {
        out.add(TextSpan(text: line.substring(last), style: style));
      }
      if (li < lines.length - 1) out.add(TextSpan(text: '\n', style: style));
    }
    return out;
  }

  Widget _bubble(ChatMsg m, bool isLast) {
    final user = m.role == 'user';
    final dark = isDark(context);
    return Align(
      alignment:
          user ? AlignmentDirectional.centerStart : AlignmentDirectional.centerEnd,
      child: ConstrainedBox(
        constraints:
            BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.85),
        child: NeoCard(
          margin: const EdgeInsets.only(bottom: 12),
          radius: 18,
          color: m.error ? const Color(0xFFFFC9C0) : (user ? C.yellow : null),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Directionality(
                textDirection: autoDir(m.text),
                child: Builder(builder: (_) {
                  final st = TextStyle(
                    fontSize: 16,
                    height: 1.45,
                    color: (user || m.error)
                        ? C.ink
                        : (dark ? Colors.white : C.ink),
                  );
                  return SelectableText.rich(
                    TextSpan(
                        children: (user || m.error)
                            ? [TextSpan(text: m.text, style: st)]
                            : _md(m.text, st)),
                    style: st,
                  );
                }),
              ),
              if (m.error && isLast)
                TextButton.icon(
                  onPressed: _retry,
                  icon: const Icon(Icons.refresh, size: 18),
                  label: const Text('إعادة المحاولة'),
                )
              else if (!user && !m.error)
                Align(
                  alignment: AlignmentDirectional.centerEnd,
                  child: InkWell(
                    onTap: () {
                      Clipboard.setData(ClipboardData(text: m.text));
                      toast(context, 'تم النسخ');
                    },
                    child: const Padding(
                      padding: EdgeInsets.only(top: 6),
                      child: Icon(Icons.copy_rounded, size: 16),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _input() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 4, 12, 10),
      child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
        Expanded(
          child: TextField(
            controller: _ctrl,
            minLines: 1,
            maxLines: 4,
            keyboardType: TextInputType.multiline,
            decoration: const InputDecoration(
              hintText: 'اكتب رسالتك…',
              isDense: true,
              contentPadding:
                  EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            ),
          ),
        ),
        const SizedBox(width: 8),
        GestureDetector(
          onTap: _busy ? null : () => _send(),
          child: Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: _busy ? Colors.grey : C.coral,
              shape: BoxShape.circle,
              border: Border.all(color: C.ink, width: 2),
            ),
            child: const Icon(Icons.send_rounded, color: C.ink),
          ),
        ),
      ]),
    );
  }
}
