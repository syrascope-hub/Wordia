import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:webview_flutter/webview_flutter.dart';

import 'screens/splash_screen.dart';
import 'services/notify_service.dart';
import 'services/tts_service.dart';
import 'store.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await app.load();
  tts.setup();
  runApp(const WordiaApp());
  // تهيئة الإشعارات بعد ظهور الواجهة حتى لا تتأخر
  notifier.init().then((_) => app.scheduleNotifications());
}

class WordiaApp extends StatelessWidget {
  const WordiaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: app.themeN,
      builder: (context, mode, _) => MaterialApp(
        title: 'Wordia',
        debugShowCheckedModeBanner: false,
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        themeMode: const [
          ThemeMode.system,
          ThemeMode.light,
          ThemeMode.dark
        ][mode.clamp(0, 2).toInt()],
        theme: buildTheme(Brightness.light),
        darkTheme: buildTheme(Brightness.dark),
        builder: (context, child) => Stack(
          textDirection: TextDirection.ltr,
          children: [
            child ?? const SizedBox.shrink(),
            // WebView مخفي (1×1) يشغّل ResponsiveVoice
            Positioned(
              left: 0,
              bottom: 0,
              width: 1,
              height: 1,
              child: IgnorePointer(
                child: WebViewWidget(controller: tts.controller),
              ),
            ),
          ],
        ),
        home: const SplashScreen(),
      ),
    );
  }
}
