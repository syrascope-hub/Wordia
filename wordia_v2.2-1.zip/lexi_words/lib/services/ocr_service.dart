import 'package:google_mlkit_commons/google_mlkit_commons.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:image_picker/image_picker.dart';

/// استخراج الكلمات من صورة (كاميرا أو معرض). يعمل دون إنترنت للغات اللاتينية
/// (الإنجليزية، الإسبانية، الفرنسية، الألمانية، الإيطالية، التركية، البرتغالية).
class OcrService {
  final ImagePicker _picker = ImagePicker();

  /// يعيد قائمة كلمات فريدة (بالترتيب)، أو null إن ألغى المستخدم الاختيار.
  Future<List<String>?> scan({required bool camera}) async {
    final x = await _picker.pickImage(
      source: camera ? ImageSource.camera : ImageSource.gallery,
      maxWidth: 2200,
      imageQuality: 90,
    );
    if (x == null) return null;
    final rec = TextRecognizer(script: TextRecognitionScript.latin);
    try {
      final r = await rec.processImage(InputImage.fromFilePath(x.path));
      return extractWords(r.text);
    } finally {
      await rec.close();
    }
  }

  /// يستخرج النص الكامل من صورة (للتلخيص). null إن ألغى المستخدم.
  Future<String?> scanText({required bool camera}) async {
    final x = await _picker.pickImage(
      source: camera ? ImageSource.camera : ImageSource.gallery,
      maxWidth: 2600,
      imageQuality: 92,
    );
    if (x == null) return null;
    final rec = TextRecognizer(script: TextRecognitionScript.latin);
    try {
      final r = await rec.processImage(InputImage.fromFilePath(x.path));
      return r.text;
    } finally {
      await rec.close();
    }
  }

  /// OCR لملف موجود (احتياطي عندما تفشل قراءة الصورة بالذكاء الاصطناعي).
  Future<String> readFile(String path) async {
    final rec = TextRecognizer(script: TextRecognitionScript.latin);
    try {
      final r = await rec.processImage(InputImage.fromFilePath(path));
      return r.text;
    } finally {
      await rec.close();
    }
  }

  static List<String> extractWords(String text) {
    final out = <String>[];
    final seen = <String>{};
    final re = RegExp(r"[A-Za-zÀ-ÿĞğİıŞşÇçÖöÜü]+(?:['’-][A-Za-zÀ-ÿĞğİıŞşÇçÖöÜü]+)*");
    for (final m in re.allMatches(text)) {
      final w = m.group(0)!;
      if (w.length < 3) continue;
      if (seen.add(w.toLowerCase())) out.add(w);
    }
    return out;
  }
}

final OcrService ocr = OcrService();
