import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;

import '../models.dart';

final NotifyService notifier = NotifyService();

/// إشعار يومي بكلمة مختلفة: نجدول الأيام الـ 30 القادمة، وتُعاد الجدولة
/// عند كل فتح للتطبيق أو تغيير في الكلمات/الإعدادات.
class NotifyService {
  final FlutterLocalNotificationsPlugin _p = FlutterLocalNotificationsPlugin();
  bool _ready = false;

  Future<void> init() async {
    try {
      await _p.initialize(
        settings: const InitializationSettings(
          android: AndroidInitializationSettings('@mipmap/ic_launcher'),
        ),
      );
      _ready = true;
    } catch (e) {
      debugPrint('notification init failed: $e');
    }
  }

  Future<bool> requestPermission() async {
    try {
      final a = _p.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
      return (await a?.requestNotificationsPermission()) ?? false;
    } catch (e) {
      debugPrint('notification permission failed: $e');
      return false;
    }
  }

  NotificationDetails _details(String body) => NotificationDetails(
        android: AndroidNotificationDetails(
          'daily_word',
          'كلمة اليوم',
          channelDescription: 'تذكير يومي بكلمة من قائمتك',
          importance: Importance.high,
          priority: Priority.high,
          styleInformation: BigTextStyleInformation(body),
        ),
      );

  String _body(Word w, bool hideTranslation) => hideTranslation
      ? '${w.language.flag} ${w.word}'
      : '${w.language.flag} ${w.word}  =  ${w.translation}';

  Future<void> reschedule({
    required bool enabled,
    required List<Word> pool,
    required int hour,
    required int minute,
    required bool hideTranslation,
  }) async {
    if (!_ready) return;
    try {
      await _p.cancelAll();
      if (!enabled || pool.isEmpty) return;
      final list = [...pool]..sort((a, b) => a.createdAt.compareTo(b.createdAt));
      final now = DateTime.now();
      for (var i = 0; i < 30; i++) {
        final d = DateTime(now.year, now.month, now.day + i, hour, minute);
        if (!d.isAfter(now)) continue;
        final dayNo =
            DateTime.utc(d.year, d.month, d.day).millisecondsSinceEpoch ~/
                86400000;
        final w = list[dayNo % list.length];
        final body = _body(w, hideTranslation);
        await _p.zonedSchedule(
          id: 1000 + i,
          title: 'هل تتذكر هذه الكلمة؟',
          body: body,
          scheduledDate: tz.TZDateTime.from(d, tz.UTC),
          notificationDetails: _details(body),
          androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        );
      }
    } catch (e) {
      debugPrint('notification schedule failed: $e');
    }
  }

  Future<bool> showTest(Word? w, bool hideTranslation) async {
    if (!_ready) return false;
    try {
      final body = w == null
          ? 'هكذا سيظهر تذكير الكلمة اليومية 🎉'
          : _body(w, hideTranslation);
      await _p.show(
        id: 1,
        title: 'هل تتذكر هذه الكلمة؟',
        body: body,
        notificationDetails: _details(body),
      );
      return true;
    } catch (e) {
      debugPrint('test notification failed: $e');
      return false;
    }
  }
}
