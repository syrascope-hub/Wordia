import 'dart:convert';
import 'dart:io';

import 'package:archive/archive.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class AnkiImport {
  /// أزواج [الوجه الأمامي، الخلفي].
  final List<List<String>> pairs;
  final String source;
  AnkiImport(this.pairs, this.source);
}

/// استيراد بطاقات Anki:
/// - ملف .apkg (تصدير «Support older Anki versions») أو
/// - ملف نصي/‏CSV/‏TSV مُصدَّر من Anki (فاصل Tab أو فاصلة).
class AnkiService {
  static String _clean(String s) {
    var t = s
        .replaceAll(RegExp(r'\[sound:[^\]]*\]'), '')
        .replaceAll(RegExp(r'<br\s*/?>', caseSensitive: false), ' ')
        .replaceAll(RegExp(r'<[^>]*>'), '')
        .replaceAll('&nbsp;', ' ')
        .replaceAll('&amp;', '&')
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>')
        .replaceAll('&quot;', '"');
    t = t.replaceAll(RegExp(r'\s+'), ' ').trim();
    return t;
  }

  /// يفتح منتقي الملفات ويحلّل الملف. يعيد null عند الإلغاء ويرمي استثناءً برسالة عربية عند الخطأ.
  Future<AnkiImport?> pickAndParse() async {
    final res = await FilePicker.platform.pickFiles(
      type: FileType.any,
      withData: true,
    );
    if (res == null || res.files.isEmpty) return null;
    final f = res.files.first;
    final name = f.name;
    final bytes = f.bytes ?? await File(f.path!).readAsBytes();
    if (name.toLowerCase().endsWith('.apkg')) {
      return AnkiImport(await _parseApkg(bytes), name);
    }
    return AnkiImport(_parseText(bytes), name);
  }

  List<List<String>> _parseText(List<int> bytes) {
    final text = utf8.decode(bytes, allowMalformed: true);
    final out = <List<String>>[];
    for (final raw in text.split(RegExp(r'[\r\n]+'))) {
      final line = raw.trim();
      if (line.isEmpty || line.startsWith('#')) continue;
      final sep = line.contains('\t') ? '\t' : (line.contains(';') ? ';' : ',');
      final cols = line.split(sep);
      if (cols.length < 2) continue;
      final a = _clean(cols[0]);
      final b = _clean(cols[1]);
      if (a.isNotEmpty && b.isNotEmpty) out.add([a, b]);
    }
    if (out.isEmpty) throw Exception('لم أجد بطاقات صالحة في الملف');
    return out;
  }

  Future<List<List<String>>> _parseApkg(List<int> bytes) async {
    final archive = ZipDecoder().decodeBytes(bytes);
    ArchiveFile? col;
    for (final name in ['collection.anki21', 'collection.anki2']) {
      for (final f in archive.files) {
        if (f.isFile && f.name == name && f.size > 4096) {
          col = f;
          break;
        }
      }
      if (col != null) break;
    }
    if (col == null) {
      final hasNew = archive.files.any((f) => f.name == 'collection.anki21b');
      throw Exception(hasNew
          ? 'هذه الحزمة بصيغة Anki الحديثة. صدّرها مجدداً مع تفعيل «Support older Anki versions» أو صدّرها كنص (Notes in Plain Text).'
          : 'ملف .apkg غير صالح');
    }
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/anki_${DateTime.now().millisecondsSinceEpoch}.db');
    await file.writeAsBytes(col.content as List<int>, flush: true);
    final db = await openDatabase(file.path, readOnly: true, singleInstance: false);
    try {
      final rows = await db.rawQuery('SELECT flds FROM notes');
      final out = <List<String>>[];
      for (final r in rows) {
        final parts = (r['flds'] ?? '').toString().split('\x1f');
        if (parts.length < 2) continue;
        final a = _clean(parts[0]);
        final b = _clean(parts[1]);
        if (a.isNotEmpty && b.isNotEmpty) out.add([a, b]);
      }
      if (out.isEmpty) throw Exception('لم أجد بطاقات داخل الحزمة');
      return out;
    } finally {
      await db.close();
      try {
        await file.delete();
      } catch (_) {}
    }
  }
}

final AnkiService anki = AnkiService();
