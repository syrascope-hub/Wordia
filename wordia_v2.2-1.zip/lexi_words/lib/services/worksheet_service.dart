import '../models.dart';

String _esc(String s) => s
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll('\n', '<br>');

const _letters = ['A', 'B', 'C', 'D', 'E', 'F'];

/// يبني ورقة عمل جاهزة للطباعة (HTML بالاتجاه العربي). تُحوَّل إلى PDF عبر حزمة printing.
/// الاختبار: أسئلة بخيارات ○. المسائل: مساحة للحل. وصفحة إجابات اختيارية.
String buildWorksheetHtml(QuizSet qs, {required bool answerKey}) {
  final b = StringBuffer();
  final isQuiz = qs.mode == 'mcq';
  final n = isQuiz ? qs.items.length : qs.solves.length;
  b.write('''<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8">
<style>
body{font-family:sans-serif;font-size:15px;line-height:1.75;color:#111;margin:0;padding:8px}
h1{font-size:24px;margin:0 0 6px}
.meta{display:flex;justify-content:space-between;border-bottom:2px solid #111;padding-bottom:8px;margin-bottom:18px;font-size:14px}
.q{margin:0 0 18px;page-break-inside:avoid}
.qt{font-weight:bold}
.opt{margin:3px 22px}
.box{display:inline-block;width:13px;height:13px;border:1.5px solid #111;border-radius:50%;margin-inline-end:8px;vertical-align:middle}
.line{border-bottom:1px solid #999;height:28px}
.key{page-break-before:always}
.ans{background:#e8f7ef;border-radius:6px;padding:2px 8px;font-weight:bold}
.step{margin:2px 18px}
.exp{color:#444;font-size:13px;margin:2px 22px}
</style></head><body>
<h1 dir="auto">${_esc(qs.title.isEmpty ? 'ورقة عمل' : qs.title)}</h1>
<div class="meta"><span>الاسم: ____________________</span><span>التاريخ: ______________</span><span>الدرجة: ____ / $n</span></div>
''');

  if (isQuiz) {
    for (var i = 0; i < qs.items.length; i++) {
      final it = qs.items[i];
      b.write('<div class="q"><div class="qt" dir="auto">${i + 1}. ${_esc(it.q)}</div>');
      for (var k = 0; k < it.options.length; k++) {
        b.write(
            '<div class="opt" dir="auto"><span class="box"></span>${_letters[k % _letters.length]}) ${_esc(it.options[k])}</div>');
      }
      b.write('</div>');
    }
  } else {
    for (var i = 0; i < qs.solves.length; i++) {
      final it = qs.solves[i];
      b.write('<div class="q"><div class="qt" dir="auto">${i + 1}. ${_esc(it.problem)}</div>');
      for (var k = 0; k < 4; k++) {
        b.write('<div class="line"></div>');
      }
      b.write('</div>');
    }
  }

  if (answerKey) {
    b.write('<div class="key"><h1>صفحة الإجابات</h1>');
    if (isQuiz) {
      for (var i = 0; i < qs.items.length; i++) {
        final it = qs.items[i];
        b.write(
            '<div class="q"><span class="ans" dir="auto">${i + 1}. ${_letters[it.answer % _letters.length]}) ${_esc(it.options[it.answer])}</span>');
        if (it.explanation.isNotEmpty) {
          b.write('<div class="exp" dir="auto">${_esc(it.explanation)}</div>');
        }
        b.write('</div>');
      }
    } else {
      for (var i = 0; i < qs.solves.length; i++) {
        final it = qs.solves[i];
        b.write('<div class="q"><div class="qt" dir="auto">${i + 1}. ${_esc(it.problem)}</div>');
        for (var k = 0; k < it.steps.length; k++) {
          b.write('<div class="step" dir="auto">${k + 1}) ${_esc(it.steps[k])}</div>');
        }
        b.write('<div><span class="ans" dir="auto">الجواب: ${_esc(it.answer)}</span></div></div>');
      }
    }
    b.write('</div>');
  }
  b.write('</body></html>');
  return b.toString();
}
