import 'dart:math';
import 'dart:typed_data';

import 'package:audioplayers/audioplayers.dart';

final AmbientService ambient = AmbientService();

class AmbientSound {
  final String id;
  final String label;
  final String emoji;
  const AmbientSound(this.id, this.label, this.emoji);
}

const List<AmbientSound> kSounds = [
  AmbientSound('none', 'بلا صوت', '🔇'),
  AmbientSound('rain', 'مطر', '🌧️'),
  AmbientSound('ocean', 'محيط', '🌊'),
  AmbientSound('forest', 'غابة', '🌲'),
  AmbientSound('fire', 'موقد', '🔥'),
];

/// أصوات خلفية مولَّدة بالكود (لا ملفات مضمّنة): تُنشأ مقاطع WAV قصيرة وتُكرَّر.
class AmbientService {
  AudioPlayer? _player;
  final Map<String, Uint8List> _cache = {};
  String _current = 'none';

  String get current => _current;

  Future<void> play(String id) async {
    _current = id;
    try {
      if (id == 'none') {
        await stop();
        return;
      }
      _player ??= AudioPlayer();
      final bytes = _cache.putIfAbsent(id, () => _build(id));
      await _player!.stop();
      await _player!.setReleaseMode(ReleaseMode.loop);
      await _player!.setVolume(0.6);
      await _player!.play(BytesSource(bytes, mimeType: 'audio/wav'));
    } catch (_) {}
  }

  Future<void> stop() async {
    try {
      await _player?.stop();
    } catch (_) {}
  }

  // ---------- التوليد ----------
  static const int _sr = 16000;
  static const int _secs = 8;

  Uint8List _build(String id) {
    final n = _sr * _secs;
    final r = Random(id.hashCode);
    final x = List<double>.filled(n, 0);
    switch (id) {
      case 'rain':
        // ضجيج أبيض مرشَّح قليلاً + قطرات عشوائية
        var prev = 0.0;
        for (var i = 0; i < n; i++) {
          final w = r.nextDouble() * 2 - 1;
          prev = prev * 0.35 + w * 0.65;
          x[i] = prev * 0.45;
        }
        for (var d = 0; d < 260; d++) {
          final at = r.nextInt(n - 200);
          final amp = 0.15 + r.nextDouble() * 0.25;
          for (var k = 0; k < 120; k++) {
            x[at + k] += (r.nextDouble() * 2 - 1) * amp * exp(-k / 25);
          }
        }
        break;
      case 'ocean':
        // ضجيج بني مضبوط بموجة بطيئة (دورة 8 ثوانٍ فتتكرر بسلاسة)
        var lp1 = 0.0;
        for (var i = 0; i < n; i++) {
          final w = r.nextDouble() * 2 - 1;
          lp1 += (w - lp1) * 0.06;
          final t = i / _sr;
          final env = 0.35 + 0.65 * (0.5 + 0.5 * sin(2 * pi * t / _secs - pi / 2));
          x[i] = lp1 * 2.2 * env;
        }
        break;
      case 'forest':
        // ريح خفيفة + زقزقة
        var lp2 = 0.0;
        for (var i = 0; i < n; i++) {
          final w = r.nextDouble() * 2 - 1;
          lp2 += (w - lp2) * 0.03;
          final t = i / _sr;
          x[i] = lp2 * 1.6 * (0.6 + 0.4 * sin(2 * pi * t / 4));
        }
        for (var b = 0; b < 7; b++) {
          final at = r.nextInt(n - _sr);
          final base = 1800 + r.nextInt(1800);
          final chirps = 2 + r.nextInt(3);
          for (var c = 0; c < chirps; c++) {
            final s0 = at + c * 2600;
            for (var k = 0; k < 1500 && s0 + k < n; k++) {
              final tt = k / _sr;
              final f = base + 900 * sin(2 * pi * 9 * tt) + 1500 * tt;
              x[s0 + k] += sin(2 * pi * f * tt) * 0.16 * sin(pi * k / 1500);
            }
          }
        }
        break;
      case 'fire':
        var lp3 = 0.0;
        for (var i = 0; i < n; i++) {
          final w = r.nextDouble() * 2 - 1;
          lp3 += (w - lp3) * 0.04;
          x[i] = lp3 * 1.2;
        }
        for (var p = 0; p < 90; p++) {
          final at = r.nextInt(n - 400);
          final amp = 0.2 + r.nextDouble() * 0.6;
          final len = 40 + r.nextInt(160);
          for (var k = 0; k < len; k++) {
            x[at + k] += (r.nextDouble() * 2 - 1) * amp * exp(-k / (len / 4));
          }
        }
        break;
    }
    // تلاشي قصير جداً عند الحدّين لتفادي طقطقة التكرار
    const fade = 320;
    for (var i = 0; i < fade; i++) {
      final g = i / fade;
      x[i] *= g;
      x[n - 1 - i] *= g;
    }
    return _wav(x);
  }

  Uint8List _wav(List<double> x) {
    final n = x.length;
    final data = ByteData(44 + n * 2);
    void str(int off, String s) {
      for (var i = 0; i < s.length; i++) {
        data.setUint8(off + i, s.codeUnitAt(i));
      }
    }

    str(0, 'RIFF');
    data.setUint32(4, 36 + n * 2, Endian.little);
    str(8, 'WAVE');
    str(12, 'fmt ');
    data.setUint32(16, 16, Endian.little);
    data.setUint16(20, 1, Endian.little);
    data.setUint16(22, 1, Endian.little);
    data.setUint32(24, _sr, Endian.little);
    data.setUint32(28, _sr * 2, Endian.little);
    data.setUint16(32, 2, Endian.little);
    data.setUint16(34, 16, Endian.little);
    str(36, 'data');
    data.setUint32(40, n * 2, Endian.little);
    for (var i = 0; i < n; i++) {
      final v = (x[i].clamp(-1.0, 1.0) * 30000).round();
      data.setInt16(44 + i * 2, v, Endian.little);
    }
    return data.buffer.asUint8List();
  }
}
