import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';

import '../models.dart';

/// مفتاح ResponsiveVoice (مفتاح عميل عام يظهر أصلاً في وسم السكربت).
const String kRvKey = 'qlpAd0be';

final TtsService tts = TtsService();

const String _html = r'''<!doctype html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="https://code.responsivevoice.org/responsivevoice.js?key=qlpAd0be"></script>
</head><body>
<script>
function post(m){ try{ Tts.postMessage(m); }catch(e){} }
var tries = 0;
function waitReady(){
  if (window.responsiveVoice) { post('ready'); return; }
  tries++;
  if (tries < 40) setTimeout(waitReady, 500);
}
window.addEventListener('load', waitReady);
function say(text, voice, id, rate){
  try {
    responsiveVoice.cancel();
    responsiveVoice.speak(text, voice, {
      rate: rate,
      onstart: function(){ post('start:' + id); },
      onend: function(){ post('end:' + id); },
      onerror: function(){ post('error:' + id); }
    });
  } catch(e) { post('error:' + id); }
}
function stopSay(){ try { responsiveVoice.cancel(); } catch(e) {} }
</script></body></html>''';

/// محرك النطق: ResponsiveVoice داخل WebView مخفي، وإن فشل يُستخدم صوت الجهاز
/// (Android TTS) تلقائياً، فلا يبقى النطق صامتاً داخل ملف APK.
class TtsService extends ChangeNotifier {
  late final WebViewController controller;
  final FlutterTts _native = FlutterTts();

  bool rvReady = false;
  bool rvBroken = false;
  int _rvFails = 0;
  int _seq = 0;
  Completer<String>? _pending;
  String status = 'جارٍ تحميل ResponsiveVoice…';

  void setup() {
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0x00000000))
      ..addJavaScriptChannel('Tts', onMessageReceived: (m) => _onMsg(m.message));
    final p = controller.platform;
    if (p is AndroidWebViewController) {
      p.setMediaPlaybackRequiresUserGesture(false);
    }
    controller.loadHtmlString(_html, baseUrl: 'https://localhost/');
    // إن لم يجهز المحرك خلال 15 ثانية نعتمد على صوت الجهاز
    Future.delayed(const Duration(seconds: 15), () {
      if (!rvReady) {
        status = 'تعذّر تحميل ResponsiveVoice (تحقق من الإنترنت) — يُستخدم صوت الجهاز';
        notifyListeners();
      }
    });
  }

  void _onMsg(String m) {
    if (m == 'ready') {
      rvReady = true;
      status = 'ResponsiveVoice جاهز';
      notifyListeners();
      return;
    }
    final i = m.indexOf(':');
    if (i < 0) return;
    final kind = m.substring(0, i);
    final id = m.substring(i + 1);
    if ((kind == 'start' || kind == 'error') &&
        id == '$_seq' &&
        _pending != null &&
        !_pending!.isCompleted) {
      _pending!.complete(kind);
    }
  }

  // ---------- المحرك الثاني: Google Translate TTS (مع تخزين مؤقت) ----------
  final AudioPlayer _player = AudioPlayer();
  Directory? _cacheDir;
  bool googleBroken = false;
  int _gFails = 0;
  int _gSeq = 0;
  String googleStatus = 'لم يُختبر بعد';

  static String _hash(String s) {
    var h = 0x811c9dc5;
    for (final c in s.codeUnits) {
      h ^= c;
      h = (h * 0x01000193) & 0xFFFFFFFF;
    }
    return '${h.toRadixString(16)}_${s.length}';
  }

  /// يقسّم النص إلى أجزاء لا تتجاوز ~180 حرفاً (حدّ الخدمة).
  List<String> _chunks(String text) {
    final parts = text.split(RegExp(r'(?<=[.!?؟。！？\n])\s*'));
    final out = <String>[];
    var cur = '';
    for (final p in parts) {
      if (p.trim().isEmpty) continue;
      if ((cur + ' ' + p).length > 180 && cur.isNotEmpty) {
        out.add(cur.trim());
        cur = p;
      } else {
        cur = cur.isEmpty ? p : '$cur $p';
      }
      while (cur.length > 180) {
        out.add(cur.substring(0, 180));
        cur = cur.substring(180);
      }
    }
    if (cur.trim().isNotEmpty) out.add(cur.trim());
    return out;
  }

  Future<File?> _googleFile(String text, Lang lang) async {
    _cacheDir ??= await () async {
      final base = await getTemporaryDirectory();
      final d = Directory('${base.path}/tts_cache');
      if (!await d.exists()) await d.create(recursive: true);
      return d;
    }();
    final f = File('${_cacheDir!.path}/${lang.code}_${_hash(text)}.mp3');
    if (await f.exists() && await f.length() > 500) return f;
    final uri = Uri.https('translate.google.com', '/translate_tts', {
      'ie': 'UTF-8',
      'client': 'tw-ob',
      'tl': lang.code == 'zh' ? 'zh-CN' : lang.code,
      'q': text,
    });
    final res = await http.get(uri, headers: {
      'User-Agent':
          'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36',
      'Referer': 'https://translate.google.com/',
    }).timeout(const Duration(seconds: 8));
    if (res.statusCode != 200 || res.bodyBytes.length < 500) return null;
    await f.writeAsBytes(res.bodyBytes, flush: true);
    return f;
  }

  Future<bool> _speakGoogle(String text, Lang lang, double rate) async {
    final id = ++_gSeq;
    try {
      final chunks = _chunks(text);
      if (chunks.isEmpty) return false;
      final first = await _googleFile(chunks.first, lang);
      if (first == null) return false;
      if (id != _gSeq) return true; // طلب أحدث ألغى هذا الطلب
      // بقية الأجزاء تُحمَّل في الخلفية أثناء تشغيل الأول
      final rest = <Future<File?>>[
        for (final c in chunks.skip(1))
          _googleFile(c, lang).catchError((_) => null),
      ];
      await _player.stop();
      await _player.setPlaybackRate((rate / 0.9).clamp(0.6, 1.4).toDouble());
      if (id != _gSeq) return true;
      if (rest.isNotEmpty) {
        var i = 0;
        StreamSubscription<void>? sub;
        sub = _player.onPlayerComplete.listen((_) async {
          if (id != _gSeq || i >= rest.length) {
            await sub?.cancel();
            return;
          }
          final f = await rest[i++];
          if (f == null || id != _gSeq) {
            await sub?.cancel();
            return;
          }
          await _player.play(DeviceFileSource(f.path));
        });
      }
      await _player.play(DeviceFileSource(first.path));
      return true;
    } catch (e) {
      debugPrint('Google TTS failed: $e');
      return false;
    }
  }

  Future<bool> testGoogle() async {
    googleBroken = false;
    _gFails = 0;
    final ok = await _speakGoogle('Hello, this is a test', kLangs.first, 0.9);
    googleStatus = ok
        ? 'محرك Google يعمل ✓'
        : 'محرك Google لا يستجيب (قد يكون محجوباً أو لا يوجد إنترنت)';
    notifyListeners();
    return ok;
  }

  /// engine: 0 تلقائي (Google ثم ResponsiveVoice ثم الجهاز)، 1 Google،
  /// 2 ResponsiveVoice، 3 صوت الجهاز فقط. يسقط تلقائياً للمحرك التالي عند الفشل.
  Future<void> speak(String text, Lang lang,
      {int engine = 0, double rate = 0.9}) async {
    text = text.trim();
    if (text.isEmpty) return;
    await stop();
    final order = switch (engine) {
      1 => ['g', 'n'],
      2 => ['r', 'n'],
      3 => ['n'],
      _ => ['g', 'r', 'n'],
    };
    for (final e in order) {
      if (e == 'g') {
        if (googleBroken && engine == 0) continue;
        if (await _speakGoogle(text, lang, rate)) {
          _gFails = 0;
          googleStatus = 'محرك Google يعمل ✓';
          return;
        }
        _gFails++;
        if (_gFails >= 3) {
          googleBroken = true;
          googleStatus = 'محرك Google لا يستجيب — تم تجاوزه';
          notifyListeners();
        }
      } else if (e == 'r') {
        if (rvReady && !rvBroken) {
          if (await _speakRv(text, lang, rate)) {
            _rvFails = 0;
            return;
          }
          _rvFails++;
          if (_rvFails >= 3) {
            rvBroken = true;
            status = 'ResponsiveVoice لا يستجيب — يُستخدم محرك آخر';
            notifyListeners();
          }
          await _stopRv();
        }
      } else {
        await _speakNative(text, lang, rate);
        return;
      }
    }
  }

  Future<bool> _speakRv(String text, Lang lang, double rate) async {
    try {
      final id = ++_seq;
      _pending = Completer<String>();
      await controller.runJavaScript(
          'say(${jsonEncode(text)}, ${jsonEncode(lang.rvVoice)}, $id, $rate);');
      final r = await _pending!.future
          .timeout(const Duration(seconds: 5), onTimeout: () => 'timeout');
      return r == 'start';
    } catch (e) {
      debugPrint('RV speak failed: $e');
      return false;
    }
  }

  Future<void> _speakNative(String text, Lang lang, double rate) async {
    try {
      await _native.setLanguage(lang.locale);
      await _native.setSpeechRate((rate * 0.5).clamp(0.2, 0.9).toDouble());
      await _native.speak(text);
    } catch (e) {
      debugPrint('native TTS failed: $e');
    }
  }

  Future<void> _stopRv() async {
    try {
      await controller.runJavaScript('stopSay();');
    } catch (_) {}
  }

  Future<void> stop() async {
    _gSeq++;
    try {
      await _player.stop();
    } catch (_) {}
    try {
      await _native.stop();
    } catch (_) {}
    if (rvReady) await _stopRv();
  }

  /// اختبار ResponsiveVoice فقط، ويعيد true إن بدأ النطق فعلاً.
  Future<bool> testRv() async {
    rvBroken = false;
    _rvFails = 0;
    if (!rvReady) {
      status = 'ResponsiveVoice غير جاهز بعد — يُستخدم صوت الجهاز';
      notifyListeners();
      return false;
    }
    final ok = await _speakRv('Hello, this is a test', kLangs.first, 0.9);
    if (ok) {
      status = 'ResponsiveVoice يعمل';
    } else {
      status = 'ResponsiveVoice لا يعمل هنا — يُستخدم صوت الجهاز';
      await _stopRv();
    }
    notifyListeners();
    return ok;
  }
}
