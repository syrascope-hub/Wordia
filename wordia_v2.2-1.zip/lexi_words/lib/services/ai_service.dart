import 'dart:convert';
import 'dart:typed_data';

import 'package:http/http.dart' as http;

import '../models.dart';

/// يُمرَّر وقت البناء عبر: --dart-define=HF_TOKEN=xxxx (من GitHub Secrets).
/// لا يوجد أي مفتاح مكتوب داخل ملفات المشروع.
const String kHfToken = String.fromEnvironment('HF_TOKEN');

const String _hfUrl = 'https://router.huggingface.co/v1/chat/completions';
const String _pollUrl = 'https://text.pollinations.ai/openai';

final AiService ai = AiService();

class AiResult {
  final String text;
  final String provider;
  AiResult(this.text, this.provider);
}

class _Try {
  final String label;
  final String url;
  final String model;
  final String? token;
  _Try(this.label, this.url, this.model, this.token);
}

class AutoFill {
  final String translation;
  final String pos;
  final String example;
  final String exampleTr;
  AutoFill(
      {required this.translation,
      required this.pos,
      required this.example,
      required this.exampleTr});
}

class Story {
  final String title;
  final String text;
  final String translation;
  Story({required this.title, required this.text, required this.translation});
}

class SumWord {
  final String word;
  final String translation;
  final String pos;
  SumWord(this.word, this.translation, this.pos);
}

class SummaryResult {
  final String summary;
  final List<String> points;
  final List<SumWord> words;
  SummaryResult(
      {required this.summary, required this.points, required this.words});
}

class AiService {
  /// هل يوجد مفتاح (مدمج أو أدخله المستخدم)؟
  bool hasKey(Settings s) => effectiveToken(s).isNotEmpty;

  String effectiveToken(Settings s) =>
      s.hfToken.trim().isNotEmpty ? s.hfToken.trim() : kHfToken;

  /// يجرّب Hugging Face بالنموذج الأول ثم الثاني، وإن فشلا (أو لم يوجد مفتاح)
  /// يستخدم Pollinations المجاني كاحتياطي.
  Future<AiResult> chat(
    List<dynamic> messages, {
    required Settings s,
    double temperature = 0.7,
    int maxTokens = 800,
    int timeoutSec = 45,
    String? onlyHfModel, // لطلبات الصور: نموذج رؤية محدد بدل النموذجين النصيين
  }) async {
    final token = effectiveToken(s);
    final tries = <_Try>[];
    if (token.isNotEmpty && onlyHfModel != null) {
      tries.add(_Try('Hugging Face', _hfUrl, onlyHfModel, token));
    } else if (token.isNotEmpty) {
      if (s.hfModel.trim().isNotEmpty) {
        tries.add(_Try('Hugging Face', _hfUrl, s.hfModel.trim(), token));
      }
      if (s.hfModel2.trim().isNotEmpty && s.hfModel2.trim() != s.hfModel.trim()) {
        tries.add(_Try('Hugging Face (2)', _hfUrl, s.hfModel2.trim(), token));
      }
    }
    tries.add(_Try('Pollinations', _pollUrl, 'openai', null));

    final errors = <String>[];
    for (final t in tries) {
      try {
        final res = await http
            .post(
              Uri.parse(t.url),
              headers: {
                'Content-Type': 'application/json',
                if (t.token != null) 'Authorization': 'Bearer ${t.token}',
              },
              body: jsonEncode({
                'model': t.model,
                'messages': messages,
                'temperature': temperature,
                'max_tokens': maxTokens,
                'stream': false,
              }),
            )
            .timeout(Duration(seconds: timeoutSec));
        if (res.statusCode == 200) {
          final j = jsonDecode(utf8.decode(res.bodyBytes));
          var c = j['choices'][0]['message']['content'];
          if (c is String) {
            c = c.replaceAll(RegExp(r'<think>[\s\S]*?</think>'), '').trim();
            if (c.isNotEmpty) return AiResult(c, t.label);
          }
          errors.add('${t.label}: رد فارغ');
        } else {
          errors.add('${t.label}: ${res.statusCode}');
        }
      } catch (e) {
        errors.add('${t.label}: ${e.runtimeType}');
      }
    }
    throw Exception(errors.join(' | '));
  }

  String systemPrompt(List<Word> words) {
    final ordered = [
      ...words.where((w) => w.daily),
      ...words.where((w) => !w.daily),
    ];
    final sample =
        ordered.take(25).map((w) => '${w.word} = ${w.translation}').join('، ');
    final extra = sample.isEmpty ? '' : ' كلمات المستخدم الحالية: $sample.';
    return 'أنت مساعد ودود لتعلّم اللغات داخل تطبيق مفردات. أجب بالعربية '
        'بإيجاز ووضوح، واستخدم أمثلة قصيرة بلغة الكلمة المطلوبة مع ترجمتها. '
        'إذا طلب المستخدم اختباراً فاسأل سؤالاً واحداً في كل مرة.$extra';
  }

  /// يولّد 3 جمل مثال للكلمة مع ترجمتها العربية.
  Future<List<Example>> examples(Word w, Settings s) async {
    final l = w.language;
    final prompt =
        'اكتب 3 جمل قصيرة وبسيطة باللغة ${l.name} تحتوي على الكلمة "${w.word}" '
        '(معناها: ${w.translation}). استخدم الكلمة بنفس شكلها في كل جملة. '
        'أعد JSON فقط بالشكل [{"text":"الجملة","translation":"ترجمتها العربية"}] '
        'بدون أي شرح أو علامات ماركداون.';
    final r = await chat(
      [
        {
          'role': 'system',
          'content': 'You are a precise language tutor. Output valid JSON only.'
        },
        {'role': 'user', 'content': prompt},
      ],
      s: s,
      temperature: 0.6,
      maxTokens: 500,
    );
    final raw = r.text;
    final a = raw.indexOf('[');
    final b = raw.lastIndexOf(']');
    if (a < 0 || b <= a) throw Exception('تعذّر قراءة رد الذكاء الاصطناعي');
    final list = jsonDecode(raw.substring(a, b + 1)) as List;
    final out = <Example>[];
    for (final e in list) {
      if (e is Map) {
        final ex = Example.fromJson(Map<String, dynamic>.from(e));
        if (ex.text.trim().isNotEmpty) out.add(ex);
      }
    }
    if (out.isEmpty) throw Exception('لم يتم توليد أمثلة');
    return out;
  }

  // ---------- أدوات JSON ----------
  dynamic _extractJson(String raw, {required bool list}) {
    final open = list ? '[' : '{';
    final close = list ? ']' : '}';
    final a = raw.indexOf(open);
    final b = raw.lastIndexOf(close);
    if (a < 0 || b <= a) throw Exception('تعذّر قراءة رد الذكاء الاصطناعي');
    return jsonDecode(raw.substring(a, b + 1));
  }

  Future<String> _json(String prompt, Settings s,
      {int maxTokens = 600,
      double temperature = 0.3,
      int timeoutSec = 45}) async {
    final r = await chat(
      [
        {
          'role': 'system',
          'content': 'You are a precise language tutor. Output valid JSON only, '
              'no markdown, no explanation.'
        },
        {'role': 'user', 'content': prompt},
      ],
      s: s,
      temperature: temperature,
      maxTokens: maxTokens,
      timeoutSec: timeoutSec,
    );
    return r.text;
  }

  /// تعبئة تلقائية لكلمة واحدة: الترجمة العربية + نوع الكلمة + جملة مثال.
  Future<AutoFill> autoFill(String word, String langCode, Settings s) async {
    final l = langOf(langCode);
    final raw = await _json(
      'الكلمة "$word" باللغة ${l.name}. أعد JSON فقط بهذا الشكل: '
      '{"translation":"أشهر معنى عربي مختصر","pos":"noun/verb/adj/adv/phrase...",'
      '"example":"جملة قصيرة بسيطة باللغة ${l.name} تحتوي الكلمة بنفس شكلها",'
      '"example_tr":"ترجمة الجملة بالعربية"}',
      s,
    );
    final j = Map<String, dynamic>.from(_extractJson(raw, list: false) as Map);
    final tr = (j['translation'] ?? '').toString().trim();
    if (tr.isEmpty) throw Exception('لم تُولَّد ترجمة');
    return AutoFill(
      translation: tr,
      pos: (j['pos'] ?? '').toString().trim(),
      example: (j['example'] ?? '').toString().trim(),
      exampleTr: (j['example_tr'] ?? '').toString().trim(),
    );
  }

  /// ترجمة مجموعة كلمات دفعة واحدة (حتى 25 كلمة لكل طلب).
  Future<Map<String, List<String>>> translateWords(
      List<String> words, String langCode, Settings s) async {
    final l = langOf(langCode);
    final out = <String, List<String>>{};
    for (var i = 0; i < words.length; i += 25) {
      final chunk = words.sublist(i, i + 25 > words.length ? words.length : i + 25);
      final raw = await _json(
        'ترجم هذه الكلمات من ${l.name} إلى العربية (أشهر معنى مختصر): '
        '${jsonEncode(chunk)}. أعد JSON فقط: '
        '[{"w":"الكلمة كما وردت","tr":"المعنى","pos":"noun/verb/adj/..."}]',
        s,
        maxTokens: 1200,
      );
      final list = _extractJson(raw, list: true) as List;
      for (final e in list) {
        if (e is Map) {
          final w = (e['w'] ?? '').toString().trim();
          final tr = (e['tr'] ?? '').toString().trim();
          if (w.isNotEmpty && tr.isNotEmpty) {
            out[w.toLowerCase()] = [tr, (e['pos'] ?? '').toString().trim()];
          }
        }
      }
    }
    return out;
  }

  /// قصة قصيرة تستخدم كلمات المستخدم.
  Future<Story> story(List<Word> words, String langCode, String level,
      Settings s) async {
    final l = langOf(langCode);
    final list = words.map((w) => w.word).toList();
    final raw = await _json(
      'اكتب قصة قصيرة ممتعة (6 إلى 9 جمل) باللغة ${l.name} بمستوى $level '
      'تستخدم هذه الكلمات كلها بنفس شكلها تماماً: ${jsonEncode(list)}. '
      'أعد JSON فقط: {"title":"عنوان قصير بلغة القصة","text":"القصة",'
      '"translation":"ترجمة القصة كاملة بالعربية"}',
      s,
      maxTokens: 1400,
      temperature: 0.8,
    );
    final j = Map<String, dynamic>.from(_extractJson(raw, list: false) as Map);
    final text = (j['text'] ?? '').toString().trim();
    if (text.isEmpty) throw Exception('لم تُولَّد قصة');
    return Story(
      title: (j['title'] ?? '').toString().trim(),
      text: text,
      translation: (j['translation'] ?? '').toString().trim(),
    );
  }

  /// يلخّص نصاً (أو نص فيديو) ويستخرج كلمات مهمة بلغة النص مع معانيها.
  /// [outLang]: 'ar' للملخص بالعربية، أو 'src' بلغة النص نفسه (للتدرّب على القراءة).
  /// النصوص الطويلة تُلخَّص على أجزاء ثم تُدمج.
  Future<SummaryResult> summarizeText(
    String transcript,
    String langCode,
    String style, // short | points | detailed
    String title,
    Settings s, {
    String outLang = 'ar',
  }) async {
    final l = langOf(langCode);
    const chunkSize = 7000;
    const maxChunks = 8;
    var text = transcript.trim();
    // مقتطف من النص الأصلي تُستخرج منه الكلمات (حتى لا تُستخرج من ملخصات
    // عربية فتصبح كلمات مُختلَقة غير موجودة في النص).
    var wordSample = '';

    if (text.length > chunkSize * 1.4) {
      wordSample = [
        text.substring(0, 2500),
        text.substring(text.length ~/ 2, text.length ~/ 2 + 2000),
      ].join('\n…\n');
      final chunks = <String>[];
      for (var i = 0; i < text.length; i += chunkSize) {
        chunks.add(text.substring(
            i, i + chunkSize > text.length ? text.length : i + chunkSize));
      }
      var use = chunks;
      if (chunks.length > maxChunks) {
        // عيّنة موزّعة بالتساوي على الفيديو
        use = [
          for (var k = 0; k < maxChunks; k++)
            chunks[(k * (chunks.length - 1) / (maxChunks - 1)).round()]
        ];
      }
      final partials = <String>[];
      for (final c in use) {
        final r = await chat(
          [
            {
              'role': 'system',
              'content': 'You summarize video transcript parts faithfully.'
            },
            {
              'role': 'user',
              'content': 'لخّص هذا الجزء من نص في 5 إلى 7 جمل ${outLang == 'src' ? 'بلغة النص نفسها (${l.name})' : 'بالعربية'} '
                  'مع الحفاظ على الأفكار والأسماء الأساسية:\n\n$c'
            },
          ],
          s: s,
          temperature: 0.3,
          maxTokens: 450,
        );
        partials.add(r.text);
      }
      text = partials.join('\n');
    }

    final styleHint = switch (style) {
      'short' => 'summary من 3 جمل فقط و points قائمة فارغة',
      'detailed' => 'summary فقرة مفصّلة (8 إلى 12 جملة) و points من 8 إلى 10 نقاط',
      _ => 'summary من جملتين إلى 3 و points من 5 إلى 7 نقاط رئيسية',
    };
    final outHint = outLang == 'src' ? 'بلغة النص نفسها (${l.name}) وبمفردات بسيطة' : 'بالعربية';
    final raw = await _json(
      '${title.isEmpty ? '' : 'العنوان: "$title". '}لغة النص: ${l.name}.\n'
      'النص (أو ملخصات أجزائه):\n$text\n\n'
      '${wordSample.isEmpty ? '' : 'مقتطف من النص الأصلي (اختر كلمات words منه حصراً):\n$wordSample\n\n'}'
      'أعد JSON فقط بهذا الشكل: {"summary":"...","points":["..."],'
      '"words":[{"w":"كلمة مهمة بلغة ${l.name} كما وردت في النص",'
      '"tr":"معناها العربي المختصر","pos":"noun/verb/adj/..."}]}. '
      'اكتب summary وpoints $outHint. $styleHint. '
      'اختر في words من 8 إلى 12 كلمة مفيدة للتعلّم (دون أسماء الأعلام).',
      s,
      maxTokens: 1600,
      temperature: 0.3,
    );
    final j = Map<String, dynamic>.from(_extractJson(raw, list: false) as Map);
    final summary = (j['summary'] ?? '').toString().trim();
    if (summary.isEmpty) throw Exception('لم يُولَّد ملخص');
    final points = [
      for (final p in (j['points'] as List? ?? const []))
        if (p.toString().trim().isNotEmpty) p.toString().trim()
    ];
    final words = <SumWord>[];
    final seen = <String>{};
    for (final e in (j['words'] as List? ?? const [])) {
      if (e is Map) {
        final w = (e['w'] ?? '').toString().trim();
        final tr = (e['tr'] ?? '').toString().trim();
        if (w.isNotEmpty && tr.isNotEmpty && seen.add(w.toLowerCase())) {
          words.add(SumWord(w, tr, (e['pos'] ?? '').toString().trim()));
        }
      }
    }
    return SummaryResult(summary: summary, points: points, words: words);
  }

  Future<SummaryResult> summarizeVideo(String transcript, String langCode,
          String style, String title, Settings s) =>
      summarizeText(transcript, langCode, style, title, s);

  // ====================== الاختبارات والمسائل ======================

  static const int _maxSrc = 12000;

  String _clip(String t) => t.length > _maxSrc ? t.substring(0, _maxSrc) : t;

  /// يقرأ النص من صورة بنموذج رؤية (يدعم العربية والمعادلات). يعيد '' إن لم يجد نصاً.
  Future<String> imageToText(Uint8List bytes, Settings s) async {
    final url = 'data:image/jpeg;base64,${base64Encode(bytes)}';
    final r = await chat(
      [
        {
          'role': 'user',
          'content': [
            {
              'type': 'text',
              'text': 'انسخ كل النص الموجود في هذه الصورة حرفياً وبنفس لغته '
                  'دون أي تعليق أو شرح (اكتب المعادلات والرموز بنص عادي). '
                  'إن لم يوجد نص فاكتب فقط: NO_TEXT'
            },
            {
              'type': 'image_url',
              'image_url': {'url': url}
            },
          ]
        }
      ],
      s: s,
      temperature: 0.1,
      maxTokens: 2000,
      timeoutSec: 90,
      onlyHfModel: 'Qwen/Qwen2.5-VL-72B-Instruct',
    );
    final t = r.text.trim();
    return t.contains('NO_TEXT') ? '' : t;
  }

  /// يحوّل نصاً إلى أسئلة اختيار من متعدد مع شرح لكل إجابة.
  Future<List<QuizItem>> makeQuiz(String text,
      {required int count,
      required String level,
      required bool arabicQ,
      required Settings s}) async {
    final lang = arabicQ
        ? 'اكتب الأسئلة والخيارات والشرح كلها بالعربية.'
        : 'اكتب الأسئلة والخيارات بنفس لغة النص، والشرح بالعربية.';
    final raw = await _json(
      'من النص التالي أنشئ $count سؤال اختيار من متعدد بمستوى $level. '
      'لكل سؤال 4 خيارات: واحد صحيح فقط والبقية مموّهات معقولة وغير متشابهة. '
      'ركّز على الفهم لا الحفظ الحرفي، وتنوّع في أجزاء النص. $lang '
      'أعد JSON فقط بالشكل: [{"q":"السؤال","options":["..","..","..",".."],'
      '"answer":0,"explanation":"لماذا هذه الإجابة صحيحة في جملتين"}] '
      'حيث answer فهرس الخيار الصحيح من 0 إلى 3.\n\nالنص:\n"""${_clip(text)}"""',
      s,
      maxTokens: 3200,
      temperature: 0.4,
      timeoutSec: 90,
    );
    final list = _extractJson(raw, list: true) as List;
    final out = <QuizItem>[];
    for (final e in list) {
      if (e is! Map) continue;
      final q = (e['q'] ?? '').toString().trim();
      final opts = [
        for (final o in (e['options'] as List? ?? const [])) o.toString().trim()
      ]..removeWhere((o) => o.isEmpty);
      if (q.isEmpty || opts.length < 2) continue;
      var ans = -1;
      final a = e['answer'];
      if (a is num) {
        ans = a.toInt();
      } else if (a is String) {
        ans = int.tryParse(a.trim()) ?? 'abcd'.indexOf(a.trim().toLowerCase());
      }
      if (ans < 0 || ans >= opts.length) continue;
      final correct = opts[ans];
      opts.shuffle(); // النماذج تميل لوضع الصحيح في مكان ثابت
      out.add(QuizItem(q, opts, opts.indexOf(correct),
          (e['explanation'] ?? '').toString().trim()));
    }
    if (out.isEmpty) throw Exception('لم تُولَّد أسئلة');
    return out;
  }

  /// يستخرج المسائل/التمارين من النص ويحلّها خطوة بخطوة.
  Future<List<SolveItem>> solveProblems(String text, Settings s) async {
    final raw = await _json(
      'النص التالي يحتوي مسائل أو تمارين (رياضيات أو فيزياء أو لغة أو منطق...). '
      'استخرج كل مسألة (حتى 12) وحلّها بدقة خطوة بخطوة. اكتب الخطوات بالعربية '
      'والرموز الرياضية بنص عادي بلا LaTeX. إن لم تجد أي مسألة أعد []. '
      'أعد JSON فقط: [{"problem":"نص المسألة","steps":["خطوة","..."],'
      '"answer":"الجواب النهائي"}]\n\nالنص:\n"""${_clip(text)}"""',
      s,
      maxTokens: 3500,
      temperature: 0.2,
      timeoutSec: 120,
    );
    final list = _extractJson(raw, list: true) as List;
    final out = <SolveItem>[];
    for (final e in list) {
      if (e is! Map) continue;
      final p = (e['problem'] ?? '').toString().trim();
      final a = (e['answer'] ?? '').toString().trim();
      if (p.isEmpty || a.isEmpty) continue;
      out.add(SolveItem(
        p,
        [
          for (final st in (e['steps'] as List? ?? const []))
            if (st.toString().trim().isNotEmpty) st.toString().trim()
        ],
        a,
      ));
    }
    if (out.isEmpty) throw Exception('لم أجد مسائل في النص');
    return out;
  }

  /// شرح مبسّط للنص بالعربية.
  Future<String> explainText(String text, Settings s) async {
    final r = await chat(
      [
        {
          'role': 'system',
          'content': 'أنت معلّم صبور يشرح ببساطة ووضوح وبالعربية.'
        },
        {
          'role': 'user',
          'content': 'اشرح النص التالي: ابدأ بالفكرة العامة في جملتين، ثم اشرح '
              'النقاط الصعبة أو المصطلحات، ثم أعطِ مثالاً إن لزم. '
              'استخدم عناوين قصيرة ونقاطاً.\n\nالنص:\n"""${_clip(text)}"""'
        },
      ],
      s: s,
      temperature: 0.4,
      maxTokens: 1800,
      timeoutSec: 90,
    );
    return r.text;
  }

  /// شرح موسّع لإجابة سؤال (لماذا الصحيح صحيح ولماذا اختيارك خطأ).
  Future<String> explainAnswer(QuizItem q, String chosen, Settings s) async {
    final r = await chat(
      [
        {
          'role': 'user',
          'content': 'السؤال: ${q.q}\nالخيارات: ${q.options.join(' | ')}\n'
              'الإجابة الصحيحة: ${q.options[q.answer]}\n'
              '${chosen.isEmpty ? '' : 'اختيار المستخدم: $chosen\n'}'
              'اشرح بالعربية وبإيجاز لماذا الإجابة الصحيحة صحيحة'
              '${chosen.isEmpty || chosen == q.options[q.answer] ? '' : ' ولماذا اختيار المستخدم خاطئ'}'
              '، وأعطِ حيلة بسيطة للتذكّر.'
        },
      ],
      s: s,
      temperature: 0.4,
      maxTokens: 700,
      timeoutSec: 60,
    );
    return r.text;
  }
}
