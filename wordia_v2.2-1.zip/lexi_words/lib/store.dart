import 'dart:async';
import 'dart:convert';
import 'dart:math' show max;

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';
import 'services/notify_service.dart';

final AppState app = AppState();

/// فهارس التبويبات السفلية.
const int kTabFlash = 0;
const int kTabStudy = 1;
const int kTabChat = 2;
const int kTabFocus = 3;

class BulkResult {
  final int added;
  final int skipped;
  final int invalid;
  BulkResult(this.added, this.skipped, this.invalid);
}

class AppState extends ChangeNotifier {
  late SharedPreferences _sp;
  List<Word> words = [];
  List<ChatMsg> chat = [];
  Settings s = Settings();

  /// عدد الإجابات في كل يوم (مفتاح = رقم اليوم منذ 1970).
  Map<int, int> history = {};

  /// سجل الملخصات (آخر 20) والغابة (أشجار التركيز).
  List<SummaryRec> sumHistory = [];
  List<ForestTree> forest = [];

  /// سجل الاختبارات والمسائل المولَّدة (آخر 15).
  List<QuizSet> quizHistory = [];
  /// قسم Study: المقرّرات ومواد كل مقرّر.
  List<Subject> subjects = [];
  int coins = 0;
  Set<String> ownedTrees = {'oak'};
  String selectedTree = 'oak';

  final ValueNotifier<int> tab = ValueNotifier<int>(0);
  final ValueNotifier<int> themeN = ValueNotifier<int>(0);
  String? chatPrefill;

  Timer? _notifTimer;
  int _idc = 0;

  /// فواصل المراجعة بالأيام لكل صندوق (نظام لايتنر).
  static const List<int> intervals = [0, 1, 3, 7, 14];

  Future<void> load() async {
    _sp = await SharedPreferences.getInstance();
    // قراءة متسامحة: عنصر تالف واحد لا يُسقط كل الكلمات، ونحتفظ بنسخة خام
    // قبل أن يُستبدل المحتوى عند أول حفظ (كان الفشل يمسح كل شيء بصمت).
    try {
      final w = _sp.getString('words');
      if (w != null) {
        var bad = 0;
        for (final e in (jsonDecode(w) as List)) {
          try {
            words.add(Word.fromJson(Map<String, dynamic>.from(e as Map)));
          } catch (_) {
            bad++;
          }
        }
        if (bad > 0) _sp.setString('words_backup_raw', w);
      }
    } catch (_) {
      final w = _sp.getString('words');
      if (w != null) _sp.setString('words_backup_raw', w);
    }
    try {
      final c = _sp.getString('chat');
      if (c != null) {
        chat = (jsonDecode(c) as List)
            .map((e) => ChatMsg.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList();
      }
    } catch (_) {}
    try {
      final st = _sp.getString('settings');
      if (st != null) {
        s = Settings.fromJson(Map<String, dynamic>.from(jsonDecode(st) as Map));
      }
    } catch (_) {}
    try {
      final h = _sp.getString('hist');
      if (h != null) {
        history = (jsonDecode(h) as Map)
            .map((k, v) => MapEntry(int.parse(k.toString()), (v as num).toInt()));
      }
    } catch (_) {}
    try {
      final h = _sp.getString('sumhist');
      if (h != null) {
        sumHistory = (jsonDecode(h) as List)
            .map((e) => SummaryRec.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList();
      }
    } catch (_) {}
    try {
      final f = _sp.getString('forest');
      if (f != null) {
        final j = Map<String, dynamic>.from(jsonDecode(f) as Map);
        forest = [
          for (final e in (j['trees'] as List? ?? const []))
            ForestTree.fromJson(Map<String, dynamic>.from(e as Map))
        ];
        coins = (j['coins'] as num?)?.toInt() ?? 0;
        ownedTrees = {
          'oak',
          for (final k in (j['owned'] as List? ?? const [])) k.toString()
        };
        selectedTree = (j['sel'] ?? 'oak').toString();
        if (!ownedTrees.contains(selectedTree)) selectedTree = 'oak';
      }
    } catch (_) {}
    try {
      final q = _sp.getString('quizhist');
      if (q != null) {
        for (final e in (jsonDecode(q) as List)) {
          try {
            quizHistory
                .add(QuizSet.fromJson(Map<String, dynamic>.from(e as Map)));
          } catch (_) {}
        }
      }
    } catch (_) {}
    try {
      final sj = _sp.getString('subjects');
      if (sj != null) {
        for (final e in (jsonDecode(sj) as List)) {
          try {
            subjects
                .add(Subject.fromJson(Map<String, dynamic>.from(e as Map)));
          } catch (_) {}
        }
      }
    } catch (_) {
      final sj = _sp.getString('subjects');
      if (sj != null) _sp.setString('subjects_backup_raw', sj);
    }
    themeN.value = s.themeMode;
  }

  // ---------- المقرّرات (Study) ----------
  void _saveSubjects() => _sp.setString(
      'subjects', jsonEncode(subjects.map((e) => e.toJson()).toList()));

  Subject? subjectById(String id) {
    for (final x in subjects) {
      if (x.id == id) return x;
    }
    return null;
  }

  Subject addSubject(String title, String emoji, int color) {
    final sub = Subject(id: newId(), title: title, emoji: emoji, color: color);
    subjects.insert(0, sub);
    _saveSubjects();
    notifyListeners();
    return sub;
  }

  void updateSubject(Subject sub) {
    _saveSubjects();
    notifyListeners();
  }

  /// يحذف المقرّر مع كل اختباراته.
  void removeSubject(String id) {
    subjects.removeWhere((e) => e.id == id);
    quizHistory.removeWhere((q) => q.subjectId == id);
    _saveSubjects();
    _saveQuiz();
    notifyListeners();
  }

  StudyMaterial addMaterial(Subject sub, String title, String text) {
    final m = StudyMaterial(id: newId(), title: title, text: text);
    sub.materials.add(m);
    _saveSubjects();
    notifyListeners();
    return m;
  }

  void removeMaterial(Subject sub, String id) {
    sub.materials.removeWhere((m) => m.id == id);
    _saveSubjects();
    notifyListeners();
  }

  /// يُستدعى بعد تعديل مادة مباشرةً (العنوان أو النص).
  void materialsChanged() {
    _saveSubjects();
    notifyListeners();
  }

  List<QuizSet> quizzesOf(String subjectId) =>
      quizHistory.where((q) => q.subjectId == subjectId).toList();

  /// متوسط آخر نتائج اختبارات المقرّر بالمئة، أو -1 إن لم يُحلّ أي اختبار.
  int avgScoreOf(String subjectId) {
    final scored = quizzesOf(subjectId)
        .where((q) => q.mode == 'mcq' && q.lastScore >= 0)
        .toList();
    if (scored.isEmpty) return -1;
    final sum = scored.fold<int>(0, (a, q) => a + q.lastScore);
    return (sum / scored.length).round();
  }

  // ---------- الاختبارات ----------
  void _saveQuiz() => _sp.setString(
      'quizhist', jsonEncode(quizHistory.map((e) => e.toJson()).toList()));

  /// السجل: آخر 15 اختباراً سريعاً + آخر 20 لكل مقرّر.
  void addQuiz(QuizSet q) {
    quizHistory.insert(0, q);
    final counts = <String?, int>{};
    quizHistory = quizHistory.where((e) {
      final n = counts[e.subjectId] = (counts[e.subjectId] ?? 0) + 1;
      return n <= (e.subjectId == null ? 15 : 20);
    }).toList();
    _saveQuiz();
    notifyListeners();
  }

  void updateQuiz(QuizSet q) {
    _saveQuiz();
    notifyListeners();
  }

  void removeQuiz(String id) {
    quizHistory.removeWhere((e) => e.id == id);
    _saveQuiz();
    notifyListeners();
  }

  // ---------- الملخصات ----------
  void addSummary(SummaryRec r) {
    sumHistory.insert(0, r);
    if (sumHistory.length > 20) sumHistory = sumHistory.sublist(0, 20);
    _sp.setString('sumhist', jsonEncode(sumHistory.map((e) => e.toJson()).toList()));
    notifyListeners();
  }

  void removeSummary(String id) {
    sumHistory.removeWhere((e) => e.id == id);
    _sp.setString('sumhist', jsonEncode(sumHistory.map((e) => e.toJson()).toList()));
    notifyListeners();
  }

  // ---------- الغابة ----------
  void saveForest() {
    _sp.setString(
        'forest',
        jsonEncode({
          'trees': forest.map((e) => e.toJson()).toList(),
          'coins': coins,
          'owned': ownedTrees.toList(),
          'sel': selectedTree,
        }));
    notifyListeners();
  }

  void addTree(ForestTree t, {int bonusCoins = 0}) {
    forest.insert(0, t);
    if (t.alive) coins += t.minutes + bonusCoins;
    saveForest();
  }

  bool buyTree(String id, int price) {
    if (ownedTrees.contains(id)) return true;
    if (coins < price) return false;
    coins -= price;
    ownedTrees.add(id);
    selectedTree = id;
    saveForest();
    return true;
  }

  /// مجموع إجابات اليوم (للربط بين الدراسة والتركيز).
  int get todayAnswers => history[_today()] ?? 0;

  String newId() => '${DateTime.now().microsecondsSinceEpoch}_${_idc++}';

  // ---------- حفظ ----------
  void _saveWords() =>
      _sp.setString('words', jsonEncode(words.map((e) => e.toJson()).toList()));

  void _saveChat() {
    final list = chat.where((m) => !m.error).toList();
    final keep = list.length > 100 ? list.sublist(list.length - 100) : list;
    _sp.setString('chat', jsonEncode(keep.map((e) => e.toJson()).toList()));
  }

  void saveSettings({bool reschedule = false}) {
    _sp.setString('settings', jsonEncode(s.toJson()));
    themeN.value = s.themeMode;
    notifyListeners();
    if (reschedule) scheduleNotifications();
  }

  void wordsChanged({bool reschedule = true}) {
    _saveWords();
    notifyListeners();
    if (reschedule) scheduleNotifications();
  }

  // ---------- الإشعارات ----------
  List<Word> get dailyPool {
    final d = words.where((w) => w.daily).toList();
    return d.isNotEmpty ? d : words;
  }

  void scheduleNotifications() {
    _notifTimer?.cancel();
    _notifTimer = Timer(const Duration(milliseconds: 800), () {
      notifier.reschedule(
        enabled: s.notifyOn,
        pool: dailyPool,
        hour: s.notifyHour,
        minute: s.notifyMinute,
        hideTranslation: s.hideTranslation,
      );
    });
  }

  // ---------- الكلمات ----------
  static String norm(String s) => s
      .replaceAll(RegExp(r'[\u064B-\u0652\u0640]'), '')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim()
      .toLowerCase();

  bool exists(String word, String lang, {String? exceptId}) => words.any((w) =>
      w.id != exceptId && w.lang == lang && norm(w.word) == norm(word));

  bool addWord(Word w) {
    if (exists(w.word, w.lang)) return false;
    words.insert(0, w);
    wordsChanged();
    return true;
  }

  void updateWord(Word w) => wordsChanged();

  void removeWord(Word w) {
    words.removeWhere((x) => x.id == w.id);
    wordsChanged();
  }

  void setDaily(Word w, bool v) {
    w.daily = v;
    wordsChanged();
  }

  void setDailyFor(Iterable<Word> list, bool v) {
    for (final w in list) {
      w.daily = v;
    }
    wordsChanged();
  }

  void toggleFavorite(Word w) {
    w.favorite = !w.favorite;
    wordsChanged(reschedule: false);
  }

  static List<List<String>> parseBulk(String text) {
    final out = <List<String>>[];
    for (final raw in text.split(RegExp(r'[\r\n]+'))) {
      final line = raw.trim();
      if (line.isEmpty) continue;
      final m = RegExp(r'[,،\t=;؛]').firstMatch(line);
      if (m == null) continue;
      final w = line.substring(0, m.start).trim();
      final t = line.substring(m.end).trim();
      if (w.isEmpty || t.isEmpty) continue;
      out.add([w, t]);
    }
    return out;
  }

  BulkResult addBulk(String text, String lang, {bool daily = false}) {
    final lines = text
        .split(RegExp(r'[\r\n]+'))
        .where((l) => l.trim().isNotEmpty)
        .length;
    final pairs = parseBulk(text);
    final r = addPairs(pairs, lang, daily: daily);
    return BulkResult(r.added, r.skipped, lines - pairs.length);
  }

  /// يضيف أزواج [كلمة، ترجمة، (ملاحظة)] مع تجاهل المكرر.
  BulkResult addPairs(List<List<String>> pairs, String lang,
      {bool daily = false}) {
    var added = 0, skipped = 0;
    for (final p in pairs) {
      if (p.length < 2 || p[0].trim().isEmpty || p[1].trim().isEmpty) continue;
      if (exists(p[0], lang)) {
        skipped++;
        continue;
      }
      words.insert(
          0,
          Word(
              id: newId(),
              word: p[0].trim(),
              translation: p[1].trim(),
              note: p.length > 2 ? p[2].trim() : '',
              lang: lang,
              daily: daily));
      added++;
    }
    if (added > 0) wordsChanged();
    return BulkResult(added, skipped, 0);
  }

  /// يقسّم نصاً إلى كلمات فقط (سطر لكل كلمة) دون ترجمة.
  static List<String> parseWordsOnly(String text) {
    final out = <String>[];
    final seen = <String>{};
    for (final raw in text.split(RegExp(r'[\r\n]+'))) {
      final line = raw.trim();
      if (line.isEmpty) continue;
      if (RegExp(r'[,،\t=;؛]').hasMatch(line)) continue;
      if (seen.add(line.toLowerCase())) out.add(line);
    }
    return out;
  }

  // ---------- المراجعة ----------
  int _today() {
    final n = DateTime.now();
    return DateTime.utc(n.year, n.month, n.day).millisecondsSinceEpoch ~/
        86400000;
  }

  int get todayNo => _today();

  int get todayCount => history[_today()] ?? 0;

  void _logActivity() {
    final t = _today();
    history[t] = (history[t] ?? 0) + 1;
    history.removeWhere((k, _) => k < t - 400);
    _sp.setString(
        'hist', jsonEncode(history.map((k, v) => MapEntry(k.toString(), v))));
  }

  bool isDue(Word w) => w.nextReview <= DateTime.now().millisecondsSinceEpoch;

  int get dueCount => words.where(isDue).length;

  void _touchStreak() {
    final t = _today();
    if (s.lastStudyDay == t) return;
    s.streak = (s.lastStudyDay == t - 1) ? s.streak + 1 : 1;
    s.lastStudyDay = t;
    _sp.setString('settings', jsonEncode(s.toJson()));
  }

  int get streak {
    final t = _today();
    return (s.lastStudyDay == t || s.lastStudyDay == t - 1) ? s.streak : 0;
  }

  void review(Word w, bool ok) {
    if (ok) {
      w.correct++;
      w.box = (w.box + 1).clamp(0, 4).toInt();
    } else {
      w.wrong++;
      w.box = 0;
    }
    // الصندوق 0 يعود بعد 10 دقائق (وليس فوراً) لتجنّب التكرار اللانهائي.
    final wait = w.box == 0
        ? const Duration(minutes: 10)
        : Duration(days: intervals[w.box]);
    w.nextReview = DateTime.now().add(wait).millisecondsSinceEpoch;
    _touchStreak();
    _logActivity();
    wordsChanged(reschedule: false);
  }

  /// للألعاب: يحدّث العدّادات فقط دون تغيير صندوق المراجعة.
  void bump(Word w, bool ok) {
    if (ok) {
      w.correct++;
    } else {
      w.wrong++;
    }
    _touchStreak();
    _logActivity();
    _saveWords();
    notifyListeners();
  }

  // ---------- المحادثة ----------
  void addChat(ChatMsg m) {
    chat.add(m);
    _saveChat();
    notifyListeners();
  }

  void removeLastError() {
    if (chat.isNotEmpty && chat.last.error) {
      chat.removeLast();
      notifyListeners();
    }
  }

  void clearChat() {
    chat.clear();
    _saveChat();
    notifyListeners();
  }

  // ---------- نسخ احتياطي ----------
  /// نسخة احتياطية كاملة (v2): الكلمات + النشاط + السلسلة + الغابة والعملات.
  /// تبقى متوافقة مع النسخ القديمة (v1) عند الاستيراد.
  String exportJson() => const JsonEncoder.withIndent('  ').convert({
        'app': 'wordia',
        'version': 2,
        'words': words.map((e) => e.toJson()).toList(),
        'history': history.map((k, v) => MapEntry(k.toString(), v)),
        'streak': s.streak,
        'lastStudyDay': s.lastStudyDay,
        'dailyGoal': s.dailyGoal,
        'forest': forest.map((e) => e.toJson()).toList(),
        'coins': coins,
        'owned': ownedTrees.toList(),
        'subjects': subjects.map((e) => e.toJson()).toList(),
        'quizzes': quizHistory.map((e) => e.toJson()).toList(),
      });

  /// يدمج بيانات النسخة (v2) دون إنقاص ما لدى المستخدم الآن.
  void _mergeExtras(Map<String, dynamic> j) {
    try {
      final h = j['history'];
      if (h is Map) {
        h.forEach((k, v) {
          final day = int.tryParse(k.toString());
          final n = (v as num?)?.toInt();
          if (day != null && n != null) history[day] = max(history[day] ?? 0, n);
        });
        _sp.setString(
            'hist', jsonEncode(history.map((k, v) => MapEntry(k.toString(), v))));
      }
      final st = (j['streak'] as num?)?.toInt();
      final ld = (j['lastStudyDay'] as num?)?.toInt();
      if (st != null && ld != null && ld >= s.lastStudyDay) {
        s.streak = st;
        s.lastStudyDay = ld;
        _sp.setString('settings', jsonEncode(s.toJson()));
      }
      final f = j['forest'];
      if (f is List) {
        final have = forest.map((t) => t.ts).toSet();
        for (final e in f) {
          final t = ForestTree.fromJson(Map<String, dynamic>.from(e as Map));
          if (t.ts != 0 && have.add(t.ts)) forest.add(t);
        }
        forest.sort((a, b) => b.ts.compareTo(a.ts));
      }
      final c = (j['coins'] as num?)?.toInt();
      if (c != null && c > coins) coins = c;
      for (final k in (j['owned'] as List? ?? const [])) {
        ownedTrees.add(k.toString());
      }
      saveForest();
      // المقرّرات والاختبارات: تُضاف غير الموجودة فقط
      final subs = j['subjects'];
      if (subs is List) {
        for (final e in subs) {
          try {
            final sub = Subject.fromJson(Map<String, dynamic>.from(e as Map));
            if (sub.id.isNotEmpty && subjectById(sub.id) == null) {
              subjects.add(sub);
            }
          } catch (_) {}
        }
        _saveSubjects();
      }
      final qz = j['quizzes'];
      if (qz is List) {
        final have = quizHistory.map((q) => q.id).toSet();
        for (final e in qz) {
          try {
            final q = QuizSet.fromJson(Map<String, dynamic>.from(e as Map));
            if (q.id.isNotEmpty && have.add(q.id)) quizHistory.add(q);
          } catch (_) {}
        }
        quizHistory.sort((a, b) => b.ts.compareTo(a.ts));
        _saveQuiz();
      }
      notifyListeners();
    } catch (_) {}
  }

  /// يدمج الكلمات ويعيد عدد المضاف. يرمي استثناءً إن كان النص غير صالح.
  int importJson(String text) {
    final j = jsonDecode(text);
    final list = (j is Map ? j['words'] : j) as List;
    var added = 0;
    for (final e in list) {
      final w = Word.fromJson(Map<String, dynamic>.from(e as Map));
      if (w.word.trim().isEmpty || w.translation.trim().isEmpty) continue;
      if (exists(w.word, w.lang)) continue;
      w.id = newId();
      words.add(w);
      added++;
    }
    if (j is Map) _mergeExtras(Map<String, dynamic>.from(j));
    if (added > 0) wordsChanged();
    return added;
  }

  void clearAll() {
    history.clear();
    _sp.remove('hist');
    words.clear();
    chat.clear();
    sumHistory.clear();
    _sp.remove('sumhist');
    quizHistory.clear();
    _sp.remove('quizhist');
    subjects.clear();
    _sp.remove('subjects');
    forest.clear();
    coins = 0;
    ownedTrees = {'oak'};
    selectedTree = 'oak';
    s.streak = 0;
    s.lastStudyDay = 0;
    _sp.setString('settings', jsonEncode(s.toJson()));
    saveForest();
    _saveChat();
    wordsChanged();
  }
}
