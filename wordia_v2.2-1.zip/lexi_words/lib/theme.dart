import 'dart:math';

import 'package:flutter/material.dart';

import 'models.dart';
import 'services/tts_service.dart';
import 'store.dart';

class C {
  static const pink = Color(0xFFFF8FB8);
  static const blue = Color(0xFF6FA8F5);
  static const mint = Color(0xFFA8E0D6);
  static const coral = Color(0xFFFF7A59);
  static const yellow = Color(0xFFFFE08A);
  static const cream = Color(0xFFFFF8EE);
  static const ink = Color(0xFF1A1A1A);
  static const darkBg = Color(0xFF15141B);
  static const darkCard = Color(0xFF23222C);
}

const Color kLavender = Color(0xFFD9C8FF);

/// خلفية كل تبويب سفلي (باستيل): Flashcards، Study، المحادثة، التركيز.
const List<Color> kTabColors = [
  C.mint,
  kLavender,
  C.yellow,
  C.mint,
];

/// ألوان المقرّرات الدراسية (الفهرس يُحفظ في Subject.color).
const List<Color> kSubjectColors = [
  Color(0xFFFFD6E0), // وردي
  Color(0xFFCDE7FF), // أزرق
  Color(0xFFD4F5E9), // نعناعي
  Color(0xFFFFE9A8), // أصفر
  Color(0xFFFFD2C2), // مرجاني
  Color(0xFFE4D6FF), // بنفسجي
  Color(0xFFD9F2A8), // ليموني
];

/// نمط العناوين الكبيرة: Lilita One للاتيني وLalezar للعربي.
TextStyle heading(double size, {Color? color, double height = 1.1}) => TextStyle(
      fontFamily: 'LilitaOne',
      fontFamilyFallback: const ['Lalezar'],
      fontSize: size,
      height: height,
      fontWeight: FontWeight.w400,
      color: color,
    );

bool isDark(BuildContext c) => Theme.of(c).brightness == Brightness.dark;

ThemeData buildTheme(Brightness b) {
  final dark = b == Brightness.dark;
  final fg = dark ? Colors.white : C.ink;
  return ThemeData(
    useMaterial3: true,
    fontFamily: 'Tajawal',
    brightness: b,
    colorScheme: ColorScheme.fromSeed(seedColor: C.coral, brightness: b),
    scaffoldBackgroundColor: dark ? C.darkBg : C.cream,
    appBarTheme: AppBarTheme(
      backgroundColor: Colors.transparent,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      foregroundColor: fg,
      titleTextStyle: heading(30, color: fg),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: dark ? const Color(0xFF1E1D26) : Colors.white,
      indicatorColor: dark ? C.coral.withValues(alpha: 0.4) : C.yellow,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      height: 68,
      labelTextStyle: WidgetStateProperty.all(
          const TextStyle(fontWeight: FontWeight.w900, fontSize: 12)),
    ),
    chipTheme: ChipThemeData(
      side: BorderSide(color: fg, width: 2),
      labelStyle: TextStyle(fontWeight: FontWeight.w800, color: fg),
      selectedColor: dark ? C.coral.withValues(alpha: 0.45) : C.yellow,
      checkmarkColor: dark ? Colors.white : C.ink,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      backgroundColor: C.ink,
      contentTextStyle:
          const TextStyle(color: Colors.white, fontWeight: FontWeight.w800),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: dark ? C.darkCard : Colors.white,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(color: fg, width: 2),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(color: fg, width: 2),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: C.coral, width: 2.5),
      ),
    ),
  );
}

/// اتجاه النص تلقائياً حسب الأحرف الغالبة (عربي أو لاتيني).
TextDirection autoDir(String s) {
  final sample = s.length > 120 ? s.substring(0, 120) : s;
  final ar = RegExp(r'[؀-ۿ]').allMatches(sample).length;
  final lat = RegExp(r'[A-Za-z]').allMatches(sample).length;
  return ar >= lat ? TextDirection.rtl : TextDirection.ltr;
}

/// عرض مبسّط لماركداون: **عريض**، `كود`، عناوين #، ونقاط.
List<InlineSpan> mdSpans(String text, TextStyle base) {
  final out = <InlineSpan>[];
  final lines = text.split('\n');
  final re = RegExp(r'\*\*(.+?)\*\*|`([^`]+)`');
  for (var li = 0; li < lines.length; li++) {
    var line = lines[li];
    var style = base;
    final h = RegExp(r'^\s{0,3}#{1,6}\s+').firstMatch(line);
    if (h != null) {
      line = line.substring(h.end);
      style = base.copyWith(fontWeight: FontWeight.w900, fontSize: (base.fontSize ?? 16) + 2);
    }
    line = line.replaceFirstMapped(
        RegExp(r'^(\s*)[-*]\s+'), (m) => '${m.group(1)}• ');
    var last = 0;
    for (final m in re.allMatches(line)) {
      if (m.start > last) {
        out.add(TextSpan(text: line.substring(last, m.start), style: style));
      }
      if (m.group(1) != null) {
        out.add(TextSpan(
            text: m.group(1), style: style.copyWith(fontWeight: FontWeight.w900)));
      } else {
        out.add(TextSpan(
            text: m.group(2),
            style: style.copyWith(
                fontFamily: 'monospace', backgroundColor: Colors.black12)));
      }
      last = m.end;
    }
    if (last < line.length) {
      out.add(TextSpan(text: line.substring(last), style: style));
    }
    if (li < lines.length - 1) out.add(TextSpan(text: '\n', style: style));
  }
  return out;
}

TextDirection langDir(Lang l) => l.rtl ? TextDirection.rtl : TextDirection.ltr;

Future<void> speakText(String text, Lang l) =>
    tts.speak(text, l, engine: app.s.ttsEngine, rate: app.s.rate);

List<InlineSpan> highlightSpans(String text, String word, TextStyle base) {
  final w = word.trim();
  if (w.isEmpty) return [TextSpan(text: text, style: base)];
  final cjk = RegExp(r'[\u3040-\u30ff\u3400-\u9fff\uac00-\ud7af]');
  final pattern = cjk.hasMatch(w)
      ? RegExp.escape(w)
      : r'(?<![\p{L}\p{N}])' + RegExp.escape(w) + r'(?![\p{L}\p{N}])';
  final re = RegExp(pattern, caseSensitive: false, unicode: true);
  final spans = <InlineSpan>[];
  var last = 0;
  for (final m in re.allMatches(text)) {
    if (m.start > last) {
      spans.add(TextSpan(text: text.substring(last, m.start), style: base));
    }
    spans.add(TextSpan(
      text: text.substring(m.start, m.end),
      style: base.copyWith(
          backgroundColor: C.yellow,
          color: C.ink,
          fontWeight: FontWeight.w900),
    ));
    last = m.end;
  }
  if (last < text.length) {
    spans.add(TextSpan(text: text.substring(last), style: base));
  }
  return spans.isEmpty ? [TextSpan(text: text, style: base)] : spans;
}

class NeoCard extends StatelessWidget {
  final Widget child;
  final Color? color;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;
  final EdgeInsets padding;
  final EdgeInsets? margin;
  final double radius;

  const NeoCard({
    super.key,
    required this.child,
    this.color,
    this.onTap,
    this.onLongPress,
    this.padding = const EdgeInsets.all(14),
    this.margin,
    this.radius = 20,
  });

  @override
  Widget build(BuildContext context) {
    final dark = isDark(context);
    final border = dark ? const Color(0xFFEDEDED) : C.ink;
    final fill = color ?? (dark ? C.darkCard : Colors.white);
    final pastel = color != null;
    Widget content = Padding(padding: padding, child: child);
    if (pastel) {
      content = DefaultTextStyle.merge(
        style: const TextStyle(color: C.ink),
        child: IconTheme.merge(
            data: const IconThemeData(color: C.ink), child: content),
      );
    }
    final br = BorderRadius.circular(radius);
    return Container(
      margin: margin,
      decoration: BoxDecoration(
        color: fill,
        borderRadius: br,
        border: Border.all(color: border, width: 2),
        boxShadow: [
          BoxShadow(
              color: dark ? Colors.black : C.ink, offset: const Offset(0, 4)),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: br,
        child: InkWell(
          borderRadius: br,
          onTap: onTap,
          onLongPress: onLongPress,
          child: content,
        ),
      ),
    );
  }
}

class NeoButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final Color color;
  final VoidCallback? onPressed;
  final bool busy;

  const NeoButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.color = C.coral,
    this.busy = false,
  });

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: onPressed == null ? 0.5 : 1,
      child: NeoCard(
        color: color,
        radius: 16,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        onTap: busy ? null : onPressed,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            if (busy)
              const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2.5))
            else if (icon != null)
              Icon(icon, size: 20),
            if (busy || icon != null) const SizedBox(width: 8),
            Flexible(
              child: Text(label,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      fontWeight: FontWeight.w900, fontSize: 15)),
            ),
          ],
        ),
      ),
    );
  }
}

class SpeakButton extends StatelessWidget {
  final String text;
  final Lang lang;
  final double size;

  const SpeakButton(
      {super.key, required this.text, required this.lang, this.size = 44});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => speakText(text, lang),
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: C.coral,
          shape: BoxShape.circle,
          border: Border.all(color: C.ink, width: 2),
        ),
        child: Icon(Icons.volume_up_rounded, color: C.ink, size: size * 0.55),
      ),
    );
  }
}

class LangDropdown extends StatelessWidget {
  final String value;
  final ValueChanged<String> onChanged;
  final String label;

  const LangDropdown({
    super.key,
    required this.value,
    required this.onChanged,
    this.label = 'اللغة',
  });

  @override
  Widget build(BuildContext context) {
    return InputDecorator(
      decoration: InputDecoration(
        labelText: label,
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value,
          isExpanded: true,
          items: kLangs
              .map((l) => DropdownMenuItem(
                  value: l.code, child: Text('${l.flag}  ${l.name}')))
              .toList(),
          onChanged: (v) {
            if (v != null) onChanged(v);
          },
        ),
      ),
    );
  }
}

void toast(BuildContext context, String msg) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(msg)));
}

Future<bool> confirm(BuildContext context, String title, String body,
    {String ok = 'تأكيد'}) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (c) => AlertDialog(
      title: Text(title),
      content: Text(body),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')),
        TextButton(onPressed: () => Navigator.pop(c, true), child: Text(ok)),
      ],
    ),
  );
  return r ?? false;
}


// ---------- عناصر بصرية ----------

/// موجات صوتية على جانبي زر النطق (مثل شاشة «النطق الدقيق»).
class Waveform extends StatelessWidget {
  final bool mirrored;
  final Color color;
  const Waveform({super.key, this.mirrored = false, this.color = C.coral});

  @override
  Widget build(BuildContext context) =>
      CustomPaint(size: const Size(72, 64), painter: _WavePainter(mirrored, color));
}

class _WavePainter extends CustomPainter {
  final bool mirrored;
  final Color color;
  _WavePainter(this.mirrored, this.color);

  static const _h = [0.25, 0.55, 0.35, 0.8, 0.5, 1.0, 0.6, 0.9, 0.4, 0.7, 0.3];

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 5
      ..strokeCap = StrokeCap.round;
    final n = _h.length;
    for (var i = 0; i < n; i++) {
      final k = mirrored ? n - 1 - i : i;
      final x = size.width * (i + 0.5) / n;
      final h = size.height * _h[k];
      canvas.drawLine(Offset(x, (size.height - h) / 2),
          Offset(x, (size.height + h) / 2), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _WavePainter old) =>
      old.mirrored != mirrored || old.color != color;
}

/// مشهد البحر لشاشة «صح أم خطأ»: شمس وغيوم وأمواج.
class SeaPainter extends CustomPainter {
  final double horizon; // نسبة موضع خط الأفق
  SeaPainter({this.horizon = 0.45});

  void _cloud(Canvas c, Offset o, double s) {
    final p = Paint()..color = Colors.white.withValues(alpha: 0.95);
    c.drawCircle(o, 14 * s, p);
    c.drawCircle(o + Offset(16 * s, -8 * s), 18 * s, p);
    c.drawCircle(o + Offset(36 * s, 0), 14 * s, p);
    c.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromLTWH(o.dx - 14 * s, o.dy, 64 * s, 14 * s), Radius.circular(8 * s)),
        p);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final hy = size.height * horizon;
    // شمس
    final sun = Offset(w - 52, 56);
    final ray = Paint()
      ..color = const Color(0xFFFFB627)
      ..strokeWidth = 4
      ..strokeCap = StrokeCap.round;
    for (var i = 0; i < 12; i++) {
      final a = i * pi / 6;
      canvas.drawLine(sun + Offset(cos(a), sin(a)) * 30,
          sun + Offset(cos(a), sin(a)) * 40, ray);
    }
    canvas.drawCircle(sun, 26, Paint()..color = const Color(0xFFFFC93C));
    canvas.drawCircle(
        sun,
        26,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..color = const Color(0xFFE59A00));
    // غيوم
    _cloud(canvas, const Offset(40, 70), 1.0);
    _cloud(canvas, Offset(w * 0.45, 110), 0.7);
    // أمواج
    final wave = Paint()
      ..color = Colors.white.withValues(alpha: 0.55)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round;
    for (var row = 0; row < 4; row++) {
      final y = hy + 36 + row * 46.0;
      final path = Path()..moveTo(0, y);
      for (double x = 0; x <= w; x += 4) {
        path.lineTo(x, y + sin((x / 28) + row) * 4);
      }
      canvas.drawPath(path, wave);
    }
  }

  @override
  bool shouldRepaint(covariant SeaPainter old) => old.horizon != horizon;
}

/// حلقة تقدّم دائرية (الهدف اليومي).
class GoalRing extends StatelessWidget {
  final double value; // 0..1
  final double size;
  final Widget child;
  final Color color;
  const GoalRing(
      {super.key,
      required this.value,
      required this.child,
      this.size = 110,
      this.color = C.coral});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: Stack(alignment: Alignment.center, children: [
        CustomPaint(
            size: Size(size, size),
            painter: _RingPainter(value.clamp(0, 1).toDouble(), color)),
        child,
      ]),
    );
  }
}

class _RingPainter extends CustomPainter {
  final double v;
  final Color color;
  _RingPainter(this.v, this.color);

  @override
  void paint(Canvas canvas, Size size) {
    final r = size.width / 2 - 9;
    final c = size.center(Offset.zero);
    final base = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 16
      ..color = C.ink.withValues(alpha: 0.12);
    canvas.drawCircle(c, r, base);
    final arc = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 16
      ..strokeCap = StrokeCap.round
      ..color = color;
    canvas.drawArc(Rect.fromCircle(center: c, radius: r), -pi / 2,
        2 * pi * v, false, arc);
  }

  @override
  bool shouldRepaint(covariant _RingPainter old) => old.v != v || old.color != color;
}


// ---------- أنيميشن ----------

/// انتقال بين الصفحات: تلاشي مع انزلاق خفيف من الأسفل.
Route<T> fadeSlide<T>(Widget page) => PageRouteBuilder<T>(
      transitionDuration: const Duration(milliseconds: 320),
      reverseTransitionDuration: const Duration(milliseconds: 240),
      pageBuilder: (_, __, ___) => page,
      transitionsBuilder: (_, anim, __, child) {
        final curved = CurvedAnimation(parent: anim, curve: Curves.easeOutCubic);
        return FadeTransition(
          opacity: curved,
          child: SlideTransition(
            position: Tween<Offset>(
                    begin: const Offset(0, 0.06), end: Offset.zero)
                .animate(curved),
            child: child,
          ),
        );
      },
    );

/// ظهور تدريجي (تلاشي + صعود) مع تأخير متتابع حسب [index].
class Appear extends StatefulWidget {
  final Widget child;
  final int index;
  const Appear({super.key, required this.child, this.index = 0});

  @override
  State<Appear> createState() => _AppearState();
}

class _AppearState extends State<Appear> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 420));
  late final Animation<double> _a =
      CurvedAnimation(parent: _c, curve: Curves.easeOutCubic);

  @override
  void initState() {
    super.initState();
    final int delay = widget.index.clamp(0, 8).toInt() * 60;
    Future.delayed(Duration(milliseconds: delay), () {
      if (mounted) _c.forward();
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => FadeTransition(
        opacity: _a,
        child: SlideTransition(
          position: Tween<Offset>(begin: const Offset(0, 0.12), end: Offset.zero)
              .animate(_a),
          child: widget.child,
        ),
      );
}

/// ظهور بتكبير مرن (للإيموجي والأيقونات الكبيرة).
class PopIn extends StatelessWidget {
  final Widget child;
  final Duration duration;
  const PopIn(
      {super.key,
      required this.child,
      this.duration = const Duration(milliseconds: 600)});

  @override
  Widget build(BuildContext context) => TweenAnimationBuilder<double>(
        tween: Tween(begin: 0, end: 1),
        duration: duration,
        curve: Curves.elasticOut,
        builder: (_, v, c) =>
            Transform.scale(scale: v.clamp(0.0, 1.4).toDouble(), child: c),
        child: child,
      );
}

/// رقم يعدّ تصاعدياً من الصفر (أو من قيمته السابقة) إلى [value].
class CountUp extends StatelessWidget {
  final int value;
  final String suffix;
  final TextStyle? style;
  const CountUp({super.key, required this.value, this.suffix = '', this.style});

  @override
  Widget build(BuildContext context) => TweenAnimationBuilder<double>(
        tween: Tween(begin: 0, end: value.toDouble()),
        duration: const Duration(milliseconds: 700),
        curve: Curves.easeOutCubic,
        builder: (_, v, __) => Text('${v.round()}$suffix', style: style),
      );
}

/// شريط تبديل بين أقسام فرعية: مؤشر ينزلق بين الخيارات.
class PillTabs extends StatelessWidget {
  final List<String> labels;
  final List<IconData> icons;
  final int index;
  final ValueChanged<int> onChanged;
  const PillTabs({
    super.key,
    required this.labels,
    required this.icons,
    required this.index,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final dark = isDark(context);
    final border = dark ? const Color(0xFFEDEDED) : C.ink;
    final n = labels.length;
    return Container(
      height: 48,
      margin: const EdgeInsets.fromLTRB(16, 8, 16, 4),
      decoration: BoxDecoration(
        color: dark ? C.darkCard : Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: border, width: 2),
        boxShadow: [
          BoxShadow(
              color: dark ? Colors.black : C.ink, offset: const Offset(0, 3)),
        ],
      ),
      child: LayoutBuilder(builder: (context, box) {
        final w = box.maxWidth / n;
        return Stack(children: [
          // الاتجاه RTL: نحدّد الموضع بـ AlignmentDirectional لينسجم مع ترتيب الأزرار
          AnimatedAlign(
            duration: const Duration(milliseconds: 280),
            curve: Curves.easeOutBack,
            alignment: AlignmentDirectional(
                n == 1 ? 0 : -1 + 2 * index / (n - 1), 0),
            child: Container(
              width: w - 4,
              height: 48 - 4 - 4,
              margin: const EdgeInsets.all(2),
              decoration: BoxDecoration(
                color: dark ? C.coral.withValues(alpha: 0.5) : C.yellow,
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
          Row(children: [
            for (var i = 0; i < n; i++)
              Expanded(
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => onChanged(i),
                  child: Center(
                    child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(icons[i],
                              size: 18, color: dark ? Colors.white : C.ink),
                          const SizedBox(width: 6),
                          Flexible(
                            child: Text(labels[i],
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                    fontWeight: FontWeight.w900,
                                    fontSize: 14,
                                    color: dark ? Colors.white : C.ink)),
                          ),
                        ]),
                  ),
                ),
              ),
          ]),
        ]);
      }),
    );
  }
}
