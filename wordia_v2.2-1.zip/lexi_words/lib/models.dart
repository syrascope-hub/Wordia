/// رقم الإصدار المعروض في الإعدادات (حدّثه مع pubspec.yaml).
const String kAppVersion = '2.2.0';

class Lang {
  final String code;
  final String name;
  final String flag;
  final String rvVoice; // اسم الصوت في ResponsiveVoice
  final String locale; // للصوت الاحتياطي (صوت الجهاز)
  final bool rtl;
  const Lang(this.code, this.name, this.flag, this.rvVoice, this.locale,
      {this.rtl = false});
}

const List<Lang> kLangs = [
  Lang('en', 'الإنجليزية', '🇬🇧', 'UK English Female', 'en-GB'),
  Lang('es', 'الإسبانية', '🇪🇸', 'Spanish Female', 'es-ES'),
  Lang('fr', 'الفرنسية', '🇫🇷', 'French Female', 'fr-FR'),
  Lang('de', 'الألمانية', '🇩🇪', 'Deutsch Female', 'de-DE'),
  Lang('it', 'الإيطالية', '🇮🇹', 'Italian Female', 'it-IT'),
  Lang('tr', 'التركية', '🇹🇷', 'Turkish Female', 'tr-TR'),
  Lang('ru', 'الروسية', '🇷🇺', 'Russian Female', 'ru-RU'),
  Lang('pt', 'البرتغالية', '🇧🇷', 'Brazilian Portuguese Female', 'pt-BR'),
  Lang('ja', 'اليابانية', '🇯🇵', 'Japanese Female', 'ja-JP'),
  Lang('ko', 'الكورية', '🇰🇷', 'Korean Female', 'ko-KR'),
  Lang('zh', 'الصينية', '🇨🇳', 'Chinese Female', 'zh-CN'),
  Lang('ar', 'العربية', '🇸🇦', 'Arabic Female', 'ar-SA', rtl: true),
];

Lang langOf(String code) =>
    kLangs.firstWhere((l) => l.code == code, orElse: () => kLangs.first);

class Example {
  final String text;
  final String translation;
  const Example(this.text, this.translation);

  Map<String, dynamic> toJson() => {'t': text, 'tr': translation};

  factory Example.fromJson(Map<String, dynamic> j) => Example(
        (j['t'] ?? j['text'] ?? '').toString(),
        (j['tr'] ?? j['translation'] ?? '').toString(),
      );
}

class Word {
  String id;
  String word;
  String translation;
  String lang;
  String note;
  List<Example> examples;
  bool daily;
  bool favorite;
  int box; // 0..4 (نظام لايتنر)
  int correct;
  int wrong;
  int createdAt;
  int nextReview;

  Word({
    required this.id,
    required this.word,
    required this.translation,
    this.lang = 'en',
    this.note = '',
    List<Example>? examples,
    this.daily = false,
    this.favorite = false,
    this.box = 0,
    this.correct = 0,
    this.wrong = 0,
    int? createdAt,
    this.nextReview = 0,
  })  : examples = examples ?? [],
        createdAt = createdAt ?? DateTime.now().millisecondsSinceEpoch;

  Lang get language => langOf(lang);

  Map<String, dynamic> toJson() => {
        'id': id,
        'word': word,
        'translation': translation,
        'lang': lang,
        'note': note,
        'examples': examples.map((e) => e.toJson()).toList(),
        'daily': daily,
        'favorite': favorite,
        'box': box,
        'correct': correct,
        'wrong': wrong,
        'createdAt': createdAt,
        'nextReview': nextReview,
      };

  factory Word.fromJson(Map<String, dynamic> j) => Word(
        id: (j['id'] ?? '').toString(),
        word: (j['word'] ?? '').toString(),
        translation: (j['translation'] ?? '').toString(),
        lang: (j['lang'] ?? 'en').toString(),
        note: (j['note'] ?? '').toString(),
        examples: ((j['examples'] as List?) ?? const [])
            .map((e) => Example.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList(),
        daily: j['daily'] == true,
        favorite: j['favorite'] == true,
        box: (j['box'] as num?)?.toInt() ?? 0,
        correct: (j['correct'] as num?)?.toInt() ?? 0,
        wrong: (j['wrong'] as num?)?.toInt() ?? 0,
        createdAt: (j['createdAt'] as num?)?.toInt(),
        nextReview: (j['nextReview'] as num?)?.toInt() ?? 0,
      );
}

class ChatMsg {
  final String role; // user | assistant
  final String text;
  final bool error;
  final int ts;
  ChatMsg(this.role, this.text, {this.error = false, int? ts})
      : ts = ts ?? DateTime.now().millisecondsSinceEpoch;

  Map<String, dynamic> toJson() => {'r': role, 't': text, 'ts': ts};

  factory ChatMsg.fromJson(Map<String, dynamic> j) => ChatMsg(
        (j['r'] ?? 'user').toString(),
        (j['t'] ?? '').toString(),
        ts: (j['ts'] as num?)?.toInt(),
      );
}

class Settings {
  int themeMode; // 0 تلقائي، 1 فاتح، 2 داكن
  String defaultLang;
  bool autoExamples;
  bool useRv;
  double rate;
  bool notifyOn;
  int notifyHour;
  int notifyMinute;
  bool hideTranslation;
  bool askedNotifPermission;
  String hfToken;
  String hfModel;
  String hfModel2;
  int streak;
  int lastStudyDay;
  int ttsEngine; // 0 تلقائي، 1 Google، 2 ResponsiveVoice، 3 صوت الجهاز
  int dailyGoal;
  bool seenWelcome;

  Settings({
    this.themeMode = 0,
    this.defaultLang = 'en',
    this.autoExamples = true,
    this.useRv = true,
    this.rate = 0.9,
    this.notifyOn = true,
    this.notifyHour = 9,
    this.notifyMinute = 0,
    this.hideTranslation = false,
    this.askedNotifPermission = false,
    this.hfToken = '',
    this.hfModel = 'Qwen/Qwen2.5-72B-Instruct',
    this.hfModel2 = 'meta-llama/Llama-3.1-8B-Instruct',
    this.streak = 0,
    this.lastStudyDay = 0,
    this.ttsEngine = 0,
    this.dailyGoal = 10,
    this.seenWelcome = false,
  });

  Map<String, dynamic> toJson() => {
        'themeMode': themeMode,
        'defaultLang': defaultLang,
        'autoExamples': autoExamples,
        'useRv': useRv,
        'rate': rate,
        'notifyOn': notifyOn,
        'notifyHour': notifyHour,
        'notifyMinute': notifyMinute,
        'hideTranslation': hideTranslation,
        'askedNotifPermission': askedNotifPermission,
        'hfToken': hfToken,
        'hfModel': hfModel,
        'hfModel2': hfModel2,
        'streak': streak,
        'lastStudyDay': lastStudyDay,
        'ttsEngine': ttsEngine,
        'dailyGoal': dailyGoal,
        'seenWelcome': seenWelcome,
      };

  factory Settings.fromJson(Map<String, dynamic> j) {
    final d = Settings();
    return Settings(
      themeMode: (j['themeMode'] as num?)?.toInt() ?? d.themeMode,
      defaultLang: (j['defaultLang'] ?? d.defaultLang).toString(),
      autoExamples: j['autoExamples'] as bool? ?? d.autoExamples,
      useRv: j['useRv'] as bool? ?? d.useRv,
      rate: (j['rate'] as num?)?.toDouble() ?? d.rate,
      notifyOn: j['notifyOn'] as bool? ?? d.notifyOn,
      notifyHour: (j['notifyHour'] as num?)?.toInt() ?? d.notifyHour,
      notifyMinute: (j['notifyMinute'] as num?)?.toInt() ?? d.notifyMinute,
      hideTranslation: j['hideTranslation'] as bool? ?? d.hideTranslation,
      askedNotifPermission:
          j['askedNotifPermission'] as bool? ?? d.askedNotifPermission,
      hfToken: (j['hfToken'] ?? '').toString(),
      hfModel: (j['hfModel'] ?? d.hfModel).toString(),
      hfModel2: (j['hfModel2'] ?? d.hfModel2).toString(),
      streak: (j['streak'] as num?)?.toInt() ?? 0,
      lastStudyDay: (j['lastStudyDay'] as num?)?.toInt() ?? 0,
      ttsEngine: (j['ttsEngine'] as num?)?.toInt() ?? 0,
      dailyGoal: (j['dailyGoal'] as num?)?.toInt() ?? 10,
      // إصلاح: كان غير مُستعاد فتظهر الجولة التعريفية في كل تشغيل
      seenWelcome: j['seenWelcome'] as bool? ?? d.seenWelcome,
    );
  }
}

/// ملخص محفوظ (نص أو فيديو) في السجل.
class SummaryRec {
  final String id;
  final int ts;
  final String title;
  final String lang;
  final String source; // text | image | file | youtube
  final String summary;
  final List<String> points;
  final List<List<String>> words; // [word, translation, pos]

  SummaryRec({
    required this.id,
    required this.ts,
    required this.title,
    required this.lang,
    required this.source,
    required this.summary,
    required this.points,
    required this.words,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'ts': ts,
        'title': title,
        'lang': lang,
        'source': source,
        'summary': summary,
        'points': points,
        'words': words,
      };

  factory SummaryRec.fromJson(Map<String, dynamic> j) => SummaryRec(
        id: (j['id'] ?? '').toString(),
        ts: (j['ts'] as num?)?.toInt() ?? 0,
        title: (j['title'] ?? '').toString(),
        lang: (j['lang'] ?? 'en').toString(),
        source: (j['source'] ?? 'text').toString(),
        summary: (j['summary'] ?? '').toString(),
        points: [for (final p in (j['points'] as List? ?? const [])) p.toString()],
        words: [
          for (final w in (j['words'] as List? ?? const []))
            if (w is List) [for (final x in w) x.toString()]
        ],
      );
}

/// شجرة في الغابة (جلسة تركيز).
class ForestTree {
  final int ts; // وقت بدء الجلسة بالمللي ثانية
  final int minutes;
  final String kind;
  final bool alive;
  const ForestTree(this.ts, this.minutes, this.kind, this.alive);

  Map<String, dynamic> toJson() =>
      {'ts': ts, 'm': minutes, 'k': kind, 'a': alive};

  factory ForestTree.fromJson(Map<String, dynamic> j) => ForestTree(
        (j['ts'] as num?)?.toInt() ?? 0,
        (j['m'] as num?)?.toInt() ?? 0,
        (j['k'] ?? 'oak').toString(),
        j['a'] != false,
      );
}

/// سؤال اختيار من متعدد مولَّد بالذكاء الاصطناعي.
class QuizItem {
  final String q;
  final List<String> options;
  final int answer; // فهرس الخيار الصحيح
  final String explanation;
  const QuizItem(this.q, this.options, this.answer, this.explanation);

  Map<String, dynamic> toJson() =>
      {'q': q, 'o': options, 'a': answer, 'e': explanation};

  factory QuizItem.fromJson(Map<String, dynamic> j) => QuizItem(
        (j['q'] ?? '').toString(),
        [for (final o in (j['o'] as List? ?? const [])) o.toString()],
        (j['a'] as num?)?.toInt() ?? 0,
        (j['e'] ?? '').toString(),
      );
}

/// مسألة محلولة خطوة بخطوة.
class SolveItem {
  final String problem;
  final List<String> steps;
  final String answer;
  const SolveItem(this.problem, this.steps, this.answer);

  Map<String, dynamic> toJson() => {'p': problem, 's': steps, 'a': answer};

  factory SolveItem.fromJson(Map<String, dynamic> j) => SolveItem(
        (j['p'] ?? '').toString(),
        [for (final s in (j['s'] as List? ?? const [])) s.toString()],
        (j['a'] ?? '').toString(),
      );
}

/// مجموعة محفوظة في سجل الاختبارات: اختبار (mcq) أو مسائل محلولة (solve).
class QuizSet {
  final String id;
  final int ts;
  final String title;
  final String mode; // mcq | solve
  final List<QuizItem> items;
  final List<SolveItem> solves;
  final String? subjectId; // null = اختبار سريع غير مرتبط بمادة
  int lastScore; // آخر نتيجة بالمئة (-1 = لم يُحلّ)

  QuizSet({
    required this.id,
    required this.ts,
    required this.title,
    required this.mode,
    this.items = const [],
    this.solves = const [],
    this.subjectId,
    this.lastScore = -1,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'ts': ts,
        'title': title,
        'mode': mode,
        'items': items.map((e) => e.toJson()).toList(),
        'solves': solves.map((e) => e.toJson()).toList(),
        if (subjectId != null) 'sid': subjectId,
        'last': lastScore,
      };

  factory QuizSet.fromJson(Map<String, dynamic> j) => QuizSet(
        id: (j['id'] ?? '').toString(),
        ts: (j['ts'] as num?)?.toInt() ?? 0,
        title: (j['title'] ?? '').toString(),
        mode: (j['mode'] ?? 'mcq').toString(),
        items: [
          for (final e in (j['items'] as List? ?? const []))
            QuizItem.fromJson(Map<String, dynamic>.from(e as Map))
        ],
        solves: [
          for (final e in (j['solves'] as List? ?? const []))
            SolveItem.fromJson(Map<String, dynamic>.from(e as Map))
        ],
        subjectId: j['sid']?.toString(),
        lastScore: (j['last'] as num?)?.toInt() ?? -1,
      );
}

// ======================= قسم Study: المواد الدراسية =======================

/// أقصى طول لمادة نصية واحدة (حفاظاً على حجم التخزين وحدود النموذج).
const int kMaxMaterialChars = 30000;

/// أيقونات المقرّرات المتاحة.
const List<String> kSubjectEmojis = [
  '📚', '🧬', '🧪', '⚛️', '📐', '🧮', '🌍', '🏛️', '📜', '💻',
  '⚖️', '🩺', '🎨', '🎵', '✍️', '💰', '🗣️', '🔭',
];

/// مادة نصية داخل مقرّر (ملخص، فصل، صفحة مصوّرة…).
class StudyMaterial {
  final String id;
  String title;
  String text;
  final int ts;
  StudyMaterial({
    required this.id,
    required this.title,
    required this.text,
    int? ts,
  }) : ts = ts ?? DateTime.now().millisecondsSinceEpoch;

  Map<String, dynamic> toJson() =>
      {'id': id, 'title': title, 'text': text, 'ts': ts};

  factory StudyMaterial.fromJson(Map<String, dynamic> j) => StudyMaterial(
        id: (j['id'] ?? '').toString(),
        title: (j['title'] ?? '').toString(),
        text: (j['text'] ?? '').toString(),
        ts: (j['ts'] as num?)?.toInt(),
      );
}

/// مقرّر دراسي (مثل الأحياء) يحوي مواد تُولَّد منها الاختبارات.
class Subject {
  final String id;
  String title;
  String emoji;
  int color; // فهرس في kSubjectColors
  final int ts;
  List<StudyMaterial> materials;

  Subject({
    required this.id,
    required this.title,
    this.emoji = '📚',
    this.color = 0,
    int? ts,
    List<StudyMaterial>? materials,
  })  : ts = ts ?? DateTime.now().millisecondsSinceEpoch,
        materials = materials ?? [];

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'emoji': emoji,
        'color': color,
        'ts': ts,
        'materials': materials.map((m) => m.toJson()).toList(),
      };

  factory Subject.fromJson(Map<String, dynamic> j) => Subject(
        id: (j['id'] ?? '').toString(),
        title: (j['title'] ?? '').toString(),
        emoji: (j['emoji'] ?? '📚').toString(),
        color: (j['color'] as num?)?.toInt() ?? 0,
        ts: (j['ts'] as num?)?.toInt(),
        materials: [
          for (final e in (j['materials'] as List? ?? const []))
            StudyMaterial.fromJson(Map<String, dynamic>.from(e as Map))
        ],
      );
}
