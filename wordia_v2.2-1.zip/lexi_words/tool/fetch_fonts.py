#!/usr/bin/env python3
"""ينزّل الخطوط المستخدمة في التطبيق (Tajawal للعربية والنص، Lalezar وLilita One للعناوين)
من مستودع google/fonts إلى assets/fonts. يُشغَّل تلقائياً في GitHub Actions."""
import pathlib
import sys
import urllib.request

BASE = "https://raw.githubusercontent.com/google/fonts/main/ofl"
FILES = {
    "Tajawal-Regular.ttf": "tajawal",
    "Tajawal-Medium.ttf": "tajawal",
    "Tajawal-Bold.ttf": "tajawal",
    "Tajawal-ExtraBold.ttf": "tajawal",
    "Tajawal-Black.ttf": "tajawal",
    "Lalezar-Regular.ttf": "lalezar",
    "LilitaOne-Regular.ttf": "lilitaone",
}
out = pathlib.Path("assets/fonts")
out.mkdir(parents=True, exist_ok=True)
bad = 0
for name, folder in FILES.items():
    dest = out / name
    if dest.exists() and dest.stat().st_size > 10_000:
        continue
    url = f"{BASE}/{folder}/{name}"
    try:
        with urllib.request.urlopen(url, timeout=60) as r:
            dest.write_bytes(r.read())
        print("ok", name)
    except Exception as e:  # noqa: BLE001
        print("FAILED", name, e)
        bad += 1
sys.exit(1 if bad else 0)
